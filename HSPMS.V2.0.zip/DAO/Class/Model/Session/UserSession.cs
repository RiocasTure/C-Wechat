﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LEO.Project.WXProposal.Data.DAO;
using LEO.Project.WXProposal.Data.Entity;

namespace LEO.Project.WXProposal.Model.Session
{
    [Serializable]
    public class UserSession
    {
        public UserSession(int type)
        {
            this.UserType = type;
            this.UploadFilePaths = new List<string>();
        }
        public UserSession()
            : this(UserSessionType.DefaultType)
        {
        }
        public int UserType { get; set; }
        public string IPAddress { get; set; }
        public virtual string UserKey { get; set; }//WechatUser:OpenID,NTUser:Identity
        public virtual string JobNumber { get; set; }
        public List<string> UploadFilePaths { get; set; }
        public string SessionId { get; set; }
        /// <summary>
        /// Session创建时间
        /// </summary>
        public long createTime { get; set; }
        public long lastUpdate { get; set; }

        //以进入编写提案功能的时间戳作为提交提案的token
        public long tokenStart { get; set; }
    }

    [Serializable]
    public class NTUserSession : UserSession
    {
        private string uDomain;
        private string uAccount;
        public string UserDomain
        {
            get
            {
                return uDomain;
            }
        }
        public string UserAccount
        {
            get
            {
                return uAccount;
            }
        }
        public override string UserKey
        {
            get
            {
                return base.UserKey;
            }
            set
            {
                base.UserKey = value;
                if (!string.IsNullOrEmpty(base.UserKey))
                {
                    string[] arr = base.UserKey.Split('\\');
                    if (arr.Length > 0)
                    {
                        if (arr.Length > 1) this.uDomain = arr[arr.Length - 2];
                        if (arr.Length > 0) this.uAccount = arr[arr.Length - 1];
                    }
                }

            }
        }
        public NTUserSession()
            : base(UserSessionType.NTUser)
        {
        }
        public override string JobNumber
        {
            get
            {
                if (string.IsNullOrEmpty(base.JobNumber) && !string.IsNullOrEmpty(this.UserAccount))
                {
                    ADUser adu = ADUserDAO.instance.GetADUserByNTAccount(this.UserAccount);
                    if (adu != null) base.JobNumber = adu.JobNumber;
                    else base.JobNumber = "";
                }
                return base.JobNumber;
            }
            set
            {
                if (string.IsNullOrEmpty(base.JobNumber))
                    base.JobNumber = value;
            }
        }
    }

    [Serializable]
    public class WechatUserSession:UserSession
    {
        public WechatUserSession():base(UserSessionType.WechatUser)
        {
        }
        public string OpenID
        {
            get
            {
                return base.UserKey;
            }
        }
    }

    public class UserAction
    {
        public static readonly string ActionNext = "next";
        public static readonly string ActionQuery = "query";
        public static readonly string ActionSubmit = "submit";
    }

    public class UserSessionType
    {
        public static readonly int DefaultType = 0;
        public static readonly int WechatUser = 1;
        public static readonly int NTUser = 2;
    }
}
