﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LEO.Project.WXProposal.Validator;

namespace WebChatInterface.WS
{
    [Serializable]
    public class WSResult
    {
        public bool IsOK { get; set; }
        public int ErrCode { get; set; }
        public string SysMsg { get; set; }

        //[NonSerialized]
        public Object ResultObject { get; set; }


        public static WSResult Result(bool isOK, int errCode, string msg)
        {
            WSResult result = new WSResult();
            result.IsOK = isOK;
            result.ErrCode = errCode;
            result.SysMsg = msg;
            return result;
        }

        public static WSResult Result(ValidateResult vr)
        {
            WSResult result = new WSResult();
            result.IsOK = vr.IsOK;
            result.ErrCode = vr.ErrCode;
            result.SysMsg = vr.SysMsg;
            result.ResultObject = vr.ResultObject;
            return result;
        }
    }

}
