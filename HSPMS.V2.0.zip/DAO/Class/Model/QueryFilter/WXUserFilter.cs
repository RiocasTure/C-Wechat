﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LEO.Project.WXProposal.Model.QueryFilter
{
    public class WXUserFilter : BaseFilter
    {
        public string JobNumber { get; set; }
        public string FullName { get; set; }
        public string Mobile { get; set; }
        public string RegStatus { get; set; }
    }
}
