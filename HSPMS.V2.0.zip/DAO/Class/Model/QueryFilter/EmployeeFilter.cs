﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LEO.Project.WXProposal.Model.QueryFilter
{
    public class EmployeeFilter : BaseFilter
    {
        public string JobNumber { get; set; }
        public string FullName { get; set; }
        public string Category { get; set; }
        public string Status { get; set; }
        public string Company { get; set; }
        public string Organ { get; set; }
        public string Division { get; set; }
        public string Depart { get; set; }
        public string Group { get; set; }
        public string JobTitle { get; set; }
    }
}
