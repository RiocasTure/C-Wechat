﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LEO.Project.Tools;

namespace LEO.Project.WXProposal.Model.QueryFilter
{
    public class ProposalFilter:BaseFilter
    {
        public string JobNumber { get; set; }
        public string Company { get; set; }
        public string Organ { get; set; }
        public string Division { get; set; }
        public string Depart { get; set; }
        public string Group { get; set; }
        public string Category { get; set; }
        public string EmpCategory { get; set; }
        public string Number { get; set; }
        public string Status { get; set; }
        public string Audit { get; set; }
        public string DateBegin { get; set; }//按提案日期搜尋的起始值
        public string DateEnd { get; set; }//按提案日期搜尋的結束值
        public string AuditDateBegin { get; set; }//按審批日期搜尋的起始值
        public string AuditDateEnd { get; set; }//按審批日期搜尋的結束值
        public string FollowProgress { get; set; }

        private static readonly string webEmptyOption = "~";
        private string CheckWebEmptyOption(string val)
        {
            return string.IsNullOrEmpty(val) || val == webEmptyOption ? "" : val.Trim();
        }
        private string CheckWebDate(string dtstr)
        {
            DateTime? dt = DateTimeUtil.ParseDateTime(DateTimeUtil.FormatYMD, dtstr);
            return dt.HasValue ? dt.Value.ToString(DateTimeUtil.FormatYMD) : "";
        }

        public void WebFormOrganize()
        {
            this.JobNumber = CheckWebEmptyOption(this.JobNumber);
            this.Company = CheckWebEmptyOption(this.Company);
            this.Organ = CheckWebEmptyOption(this.Organ);
            this.Division = CheckWebEmptyOption(this.Division);
            this.Depart = CheckWebEmptyOption(this.Depart);
            this.Group = CheckWebEmptyOption(this.Group);
            this.EmpCategory = CheckWebEmptyOption(this.EmpCategory);
            this.FollowProgress = CheckWebEmptyOption(this.FollowProgress);
            this.Number = CheckWebEmptyOption(this.Number);
            this.Category = CheckWebEmptyOption(this.Category);
            this.Status = CheckWebEmptyOption(this.Status);
            this.Audit = CheckWebEmptyOption(this.Audit);
            this.DateBegin = CheckWebDate(this.DateBegin);
            this.DateEnd = CheckWebDate(this.DateEnd);
            this.AuditDateBegin = CheckWebDate(this.AuditDateBegin);
            this.AuditDateEnd = CheckWebDate(this.AuditDateEnd);
        }
    }
}
