﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LEO.Project.WXProposal.Data.Entity;
using System.Data;
using LEO.Project.WXProposal.Data.DAO;
using LEO.Project.Tools;
using DAO.HSPPWMaster;
using System.Text;

namespace LEO.Project.WXProposal.Data.Imports
{
    public class DataImporter
    {
        public static int ImportEmployeeData(string ExcelFile)
        {
            try
            {
                string excelFile = string.IsNullOrEmpty(ExcelFile) ? "D:/employee-contacts.xlsx" : ExcelFile;
                List<string> sheetNames = ExcelImporter.GetExcelSheetNameList(excelFile);
                List<Employee> employeeList = new List<Employee>();
                foreach (string sheetName in sheetNames)
                {
                    DataTable dt = ExcelImporter.ImportSheetData(excelFile, sheetName);
                    if (dt == null) continue;
                    if (dt.Rows.Count >= 3)
                    {
                        for (int r = 2; r < dt.Rows.Count; r++)
                        {
                            DataRow dr = dt.Rows[r];
                            Employee emp = new Employee();
                            /*
                            emp.Company = sheetName;
                            for (int i = 0; i < dr.ItemArray.Length; i++)
                            {
                                if (i == 0) emp.JobNumber = dr.ItemArray[i].ToString();
                                else if (i == 1) emp.FullName = dr.ItemArray[i].ToString();
                                else if (i == 2) emp.Organ = dr.ItemArray[i].ToString();
                                else if (i == 3) emp.Depart = StringUtils.ReplaceEndStr(dr.ItemArray[i].ToString(), ".", "");
                                else if (i == 4) emp.Category = dr.ItemArray[i].ToString();
                                else if (i == 5) emp.JobTitle = dr.ItemArray[i].ToString();
                                else if (i == 6) emp.EntryDate = dr.ItemArray[i].ToString();
                                else if (i == 7) emp.IDNumSuffix = dr.ItemArray[i].ToString();
                                else if (i == 8) emp.Gender = dr.ItemArray[i].ToString();
                            }
                            */
                            //emp.Company = sheetName;
                            for (int i = 0; i < dr.ItemArray.Length; i++)
                            {
                                if (i == 0) emp.Company = dr.ItemArray[i].ToString();//公司
                                else if (i == 1) emp.Organ = dr.ItemArray[i].ToString();//总部
                                else if (i == 2) emp.Division = dr.ItemArray[i].ToString();//事業部
                                else if (i == 3) emp.Depart = StringUtils.ReplaceEndStr(dr.ItemArray[i].ToString(), ".", "");//部
                                else if (i == 4) emp.Group = dr.ItemArray[i].ToString();//科
                                else if (i == 5) emp.JobNumber = dr.ItemArray[i].ToString();//工號
                                else if (i == 6) emp.FullName = dr.ItemArray[i].ToString();//姓名
                                else if (i == 7) emp.Category = dr.ItemArray[i].ToString();//員工類別
                                else if (i == 8) emp.JobTitle = dr.ItemArray[i].ToString();//職位
                                else if (i == 9) emp.EntryDate = dr.ItemArray[i].ToString();//入職日期
                                else if (i == 10) emp.IDNumSuffix = dr.ItemArray[i].ToString();//身份証後6位
                                else if (i == 11) emp.Gender = dr.ItemArray[i].ToString();//雇用類型、性别
                                else if (i == 3) emp.Depart = StringUtils.ReplaceEndStr(dr.ItemArray[i].ToString(), ".", "");//部
                                else if (i == 4) emp.Group = dr.ItemArray[i].ToString();//科
                            }
                            emp.Status = 1;
                            if (!string.IsNullOrEmpty(emp.JobNumber) && !string.IsNullOrEmpty(emp.FullName) &&
                                !string.IsNullOrEmpty(emp.Category) && !string.IsNullOrEmpty(emp.JobTitle) &&
                                !string.IsNullOrEmpty(emp.EntryDate) && !string.IsNullOrEmpty(emp.IDNumSuffix) &&
                                !string.IsNullOrEmpty(emp.Gender) && !string.IsNullOrEmpty(emp.Company))
                            {
                                if (string.IsNullOrEmpty(emp.Organ) || emp.Organ == "部") emp.Organ = "-";
                                if (string.IsNullOrEmpty(emp.Division) || emp.Organ == "部") emp.Organ = "-";
                                if (string.IsNullOrEmpty(emp.Depart) || emp.Organ == "部") emp.Depart = "-";
                                if (string.IsNullOrEmpty(emp.Group) || emp.Organ == "科") emp.Depart = "-";
                                employeeList.Add(emp);
                            }
                        }
                    }
                }
                if (employeeList.Count > 0)
                {
                    return EmployeeDAO.UpdateEmployeeList(employeeList);
                }
            }
            catch (Exception ex)
            {
                WriteLog.Error("ImportEmployeeData Exception:", ex);
            }
            return 0;
        }

        public static int ImportADUserData()
        {
            List<ADUser> aduLst = LDAPImporter.GetADUserList();
            if (aduLst != null && aduLst.Count > 0)
            {
                WriteLog.Info(aduLst.Count + " AD Users Loaded!");
                int res = ADUserDAO.instance.UpdateADUserList(aduLst);
                if (res > 0)
                {
                    WriteLog.Info(res + " AD Users Imported!");
                    return res;
                }
                else WriteLog.Info("AD User Save Failed!");
            }
            else WriteLog.Info("No AD User Loaded!");
            return 0;
        }

        private static string blank2Null(string val)
        {
            return string.IsNullOrEmpty(val) ? null : val.Trim();
        }

        public static int ImportStaffInfoData()
        {
            try
            {
                HSPPWMaster ws = new HSPPWMaster();
                ws.Timeout = 5000;//超過5秒則為超時
                DataTable dt = ws.GetPersonInformation(string.Empty);//不帶工號表示查詢全部
                Dictionary<string, StaffInfo> staffMap = new Dictionary<string,StaffInfo>();
                if (dt!=null && dt.Rows!=null && dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        StaffInfo stf = new StaffInfo();
                        stf.PersonNumber = blank2Null(Convert.ToString(row["PersonNumber"]));
                        stf.PersonName = blank2Null(Convert.ToString(row["PersonName"]));
                        stf.RoleName = blank2Null(Convert.ToString(row["RoleName"]));
                        stf.SectionChiefName = blank2Null(Convert.ToString(row["SectionChiefName"]));
                        stf.SectionChiefNumber = blank2Null(Convert.ToString(row["SectionChiefNumber"]));
                        stf.SupervisorName = blank2Null(Convert.ToString(row["SupervisorName"]));
                        stf.SupervisorNumber = blank2Null(Convert.ToString(row["SupervisorNumber"]));
                        stf.LeaderName = blank2Null(Convert.ToString(row["LeaderName"]));
                        stf.LeaderNumber = blank2Null(Convert.ToString(row["LeaderNumber"]));
                        stf.AreaName = blank2Null(Convert.ToString(row["AreaName"]));
                        stf.FloorName = blank2Null(Convert.ToString(row["FloorName"]));
                        stf.GroupName = blank2Null(Convert.ToString(row["GroupName"]));
                        stf.DivisionName = blank2Null(Convert.ToString(row["DivisionName"]));
                        stf.JoinDate = blank2Null(Convert.ToString(row["JoinDate"]));
                        stf.EmploymentName = blank2Null(Convert.ToString(row["EmploymentName"]));
                        stf.State = Convert.ToChar(row["State"]);
                        //stf.LastUpdate = Convert.ToDateTime(row["LastUpdate"]);
                        if (!staffMap.ContainsKey(stf.PersonNumber)) staffMap.Add(stf.PersonNumber, stf);
                        else WriteLog.Error("ImportStaffInfoData found duplicated PersonNumber:"+stf.PersonNumber,null);
                    }
                    dt.Clear();
                }
                if (staffMap.Count > 0)
                {
                    int updateCount = StaffInfoDAO.UpdateStaffInfoList(staffMap.Values.ToList());//staffMap.Count;
                    return updateCount;
                }
            }
            catch (Exception e)
            {
                WriteLog.Error("DataImporter.ImportStaffInfoData Exception", e);
            }
            return 0;
        }
    }
}
