﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LEO.Project.WXProposal.Data.Entity
{
    /**
     * 工場員工資料對象
     */
    public class StaffInfo
    {
        #region properties
        /// <summary>
        /// 员工工号
        /// </summary>
        public string PersonNumber { get; set; }
        /// <summary>
        /// 员工姓名
        /// </summary>
        public string PersonName { get; set; }
        /// <summary>
        /// 员工职能
        /// </summary>
        public string RoleName { get; set; }
        /// <summary>
        /// 直属科长姓名；多個以分號(;)分隔
        /// </summary>
        public string SectionChiefName { get; set; }
        /// <summary>
        /// 直属科长工号；多個以分號(;)分隔
        /// </summary>
        public string SectionChiefNumber { get; set; }
        /// <summary>
        /// 督导姓名；多個以分號(;)分隔
        /// </summary>
        public string SupervisorName { get; set; }
        /// <summary>
        /// 督导工号；多個以分號(;)分隔
        /// </summary>
        public string SupervisorNumber { get; set; }
        /// <summary>
        /// 主管姓名；多個以分號(;)分隔
        /// </summary>
        public string LeaderName { get; set; }
        /// <summary>
        /// 主管工号；多個以分號(;)分隔
        /// </summary>
        public string LeaderNumber { get; set; }
        /// <summary>
        /// 所在期数
        /// </summary>
        public string AreaName { get; set; }
        /// <summary>
        /// 所在楼层
        /// </summary>
        public string FloorName { get; set; }
        /// <summary>
        /// 所在组别
        /// </summary>
        public string GroupName { get; set; }
        /// <summary>
        /// 所在科组
        /// </summary>
        public string DivisionName { get; set; }
        /// <summary>
        /// 入厂日期
        /// </summary>
        public string JoinDate { get; set; }
        /// <summary>
        /// 雇用类型
        /// </summary>
        public string EmploymentName { get; set; }
        /// <summary>
        /// 员工状态
        /// </summary>
        public char State { get; set; }
        /// <summary>
        /// 最后更新
        /// </summary>
        public DateTime? LastUpdate { get; set; }
        #endregion
    }
}
