﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LEO.Project.WXProposal.Data.Entity
{
    public class EventLog
    {
        public int Id { get; set; }
        public string JobNumber { get; set; }
        public string AccountName { get; set; }
        public DateTime? Timestamp { get; set; }
        public string Type { get; set; }
        public string Operation { get; set; }
        public string RelatedKey { get; set; }
        public string IP { get; set; }

        public static EventLog WXUserAccessEvent(string LogIP, string JobNumber, string WXOpenId, string SessionID)
        {
            EventLog el = new EventLog();
            el.IP = LogIP;
            el.JobNumber = JobNumber;
            el.AccountName = WXOpenId;
            el.RelatedKey = LogIP;
            el.Type = Event_Type.WXUserAccess;
            el.Operation = Event_Operation.Log;
            return el;
        }
        public static EventLog WXUserSessionEvent(string LogIP, string JobNumber, string WXOpenId, string SessionID)
        {
            EventLog el = new EventLog();
            el.IP = LogIP;
            el.JobNumber = JobNumber;
            el.AccountName = WXOpenId;
            el.RelatedKey = LogIP;
            el.Type = Event_Type.WXUserSession;
            el.Operation = Event_Operation.Log;
            return el;
        }
        public static EventLog NTUserSessionEvent(string LogIP, string JobNumber, string NTAccount, string SessionID)
        {
            EventLog el = new EventLog();
            el.IP = LogIP;
            el.JobNumber = JobNumber;
            el.AccountName = NTAccount;
            el.RelatedKey = LogIP;
            el.Type = Event_Type.NTUserSession;
            el.Operation = Event_Operation.Log;
            return el;
        }
        public static EventLog UserSessionEvent(string LogIP, string JobNumber, string UserKey, string SessionID)
        {
            EventLog el = new EventLog();
            el.IP = LogIP;
            el.JobNumber = JobNumber;
            el.AccountName = UserKey;
            el.RelatedKey = LogIP;
            el.Type = Event_Type.UserSession;
            el.Operation = Event_Operation.Log;
            return el;
        }
        public static EventLog ProposalAddEvent(string LogIP, string JobNumber, string AccountName, string pNumber)
        {
            EventLog el = new EventLog();
            el.IP = LogIP;
            el.JobNumber = JobNumber;
            el.AccountName = AccountName;
            el.RelatedKey = pNumber;
            el.Type = Event_Type.Proposal;
            el.Operation = Event_Operation.Add;
            return el;
        }
        public static EventLog ProposalModEvent(string LogIP, string JobNumber, string AccountName, string pNumber)
        {
            EventLog el = new EventLog();
            el.IP = LogIP;
            el.JobNumber = JobNumber;
            el.AccountName = AccountName;
            el.RelatedKey = pNumber;
            el.Type = Event_Type.Proposal;
            el.Operation = Event_Operation.Mod;
            return el;
        }
        public static EventLog ProposalGetEvent(string LogIP, string JobNumber, string AccountName, string pNumber)
        {
            EventLog el = new EventLog();
            el.IP = LogIP;
            el.JobNumber = JobNumber;
            el.AccountName = AccountName;
            el.RelatedKey = pNumber;
            el.Type = Event_Type.Proposal;
            el.Operation = Event_Operation.Get;
            return el;
        }
        public static EventLog WXUserInfoDelEvent(string LogIP, string JobNumber, string AccountName, string openId)
        {
            EventLog el = new EventLog();
            el.IP = LogIP;
            el.JobNumber = JobNumber;
            el.AccountName = AccountName;
            el.RelatedKey = openId;
            el.Type = Event_Type.WXUserInfo;
            el.Operation = Event_Operation.Del;
            return el;
        }
    }

    public class Event_Type
    {
        public static readonly string Proposal = "Proposal";
        public static readonly string WXUserInfo = "WXUserInfo";
        public static readonly string WXUserAccess = "WXUserAccess";
        public static readonly string WXUserSession = "WXUserSession";
        public static readonly string NTUserSession = "NTUserSession";
        public static readonly string UserSession = "UserSession";
        public static readonly string Employee = "Employee";
    }
    public class Event_Operation
    {
        public static readonly string Add = "Add";
        public static readonly string Del = "Del";
        public static readonly string Mod = "Mod";
        public static readonly string Get = "Get";
        public static readonly string Log = "Log";
    }
}
