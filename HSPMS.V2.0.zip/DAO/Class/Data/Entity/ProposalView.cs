﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LEO.Project.WXProposal.Data.Entity;

namespace JsonView
{
    public class ProposalView
    {
        public string Number { get; set; }
        public string JobNumber { get; set; }
        public string Author { get; set; }
        public string FormDate { get; set; }
        public string SubmitTime { get; set; }
        public string Status { get; set; }
        public string Category { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Advice { get; set; }
        public string OrganAuditDesc { get; set; }
        public string FollowProgress { get; set; }

        public string SONum { get; set; }
        public string ItemName { get; set; }
        public string OrderQty { get; set; }
        public string EQID { get; set; }
        public string EQName { get; set; }
        public string ImprvWorkersNow { get; set; }
        public string ImprvWorkers { get; set; }
        public string ImprvEffNow { get; set; }
        public string ImprvEff { get; set; }
        public string ImprvDPRateNow { get; set; }
        public string ImprvDPRate { get; set; }
        public string ImprvOther { get; set; }

        public static ProposalView Copy(ProposalInfo pi)
        {
            if (pi == null) return null;
            ProposalView pv = new ProposalView();
            pv.Number = pi.Number;
            pv.JobNumber = pi.AuthorJobNumber;
            pv.FormDate = (pi.FormDate != null && pi.FormDate.HasValue) ? pi.FormDate.Value.ToString("yyyy-MM-dd") : "";//yyyyMMddHHmmss
            pv.SubmitTime = (pi.SubmitTime != null && pi.SubmitTime.HasValue) ? pi.SubmitTime.Value.ToString("MM-dd HH:mm") : "";
            pv.Status = pi.Status;
            pv.Category = pi.Category;
            pv.Title = pi.Title;
            pv.Description = pi.Description;
            pv.Advice = pi.Advice;
            if (pi.YieldingInfo != null)
            {
                pv.SONum = pi.YieldingInfo.SONum;
                pv.ItemName = pi.YieldingInfo.ItemName;
                pv.OrderQty = pi.YieldingInfo.OrderQty.ToString();
                pv.EQID = pi.YieldingInfo.EQID;
                pv.EQName = pi.YieldingInfo.EQName;
                pv.ImprvWorkersNow = pi.YieldingInfo.WorkersNow;
                pv.ImprvWorkers = pi.YieldingInfo.WorkersOptimized;
                pv.ImprvEffNow = pi.YieldingInfo.EffNow;
                pv.ImprvEff = pi.YieldingInfo.EffOptimized;
                pv.ImprvDPRateNow = pi.YieldingInfo.DPRateNow;
                pv.ImprvDPRate = pi.YieldingInfo.DPRateOptimized;
                pv.ImprvOther = pi.YieldingInfo.OtherResult;
            }
            if (pi.AuditInfo != null)
            {
                pv.FollowProgress = pi.AuditInfo.FollowProgress;
            }
            pv.OrganAuditDesc = (pi.AuditInfo != null) ? pi.AuditInfo.OrganAuditDesc : string.Empty;
            return pv;
        }
    }
}
