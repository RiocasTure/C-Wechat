﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LEO.Project.WXProposal.Data.Entity
{
    public class ProposalSummary
    {
        public string JobNumber { get; set; }
        public string FullName { get; set; }
        public string Mobile { get; set; }
        public string Company { get; set; }
        public string Organ { get; set; }
        public string Division { get; set; }
        public string Depart { get; set; }
        public string Group { get; set; }
        public string EmpCategory { get; set; }
        public int Total { get; set; }
        public double SumTotal { get; set; }
        //public int SubmitCount { get; set; } //已提交
        //public int ReceivedCount { get; set; }  //審核中
        public double ReceivedCount { get; set; }  //審核中
        public string ReceivedNums { get; set; }//提案编号清单 - 審核中
        //public int AuditedCount { get; set; }   //已審核
        public double AuditedCount { get; set; }   //已審核
        public string AuditedNums { get; set; }//提案编号清单 - 已審核
        //public int AcceptCount { get; set; }    //採用
        public double AcceptCount { get; set; }    //採用
        public string AcceptNums { get; set; }//提案编号清单 - 採用
        //public int RejectCount { get; set; }    //不採用
        public double RejectCount { get; set; }    //不採用
        public string RejectNums { get; set; }//提案编号清单 - 不採用
        //public int BonusCount { get; set; }   //獎金已發放
    }
}
