﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LEO.Project.WXProposal.Data.Entity
{
    public class UserRole
    {
        //public string AccountName { get; set; }
        public string UserID { get; set; }
        public string IDType { get; set; }
        public string RoleName { get; set; }
        public string SecureCode { get; set; }

        public List<CompanyOrganOperator> OrganOperators { get; set; }

        public bool CheckSecureCode(string code)
        {
            return !string.IsNullOrEmpty(this.SecureCode) && this.SecureCode == code;
        }

        public static readonly string Role_Super = "Super";
        public static readonly string Role_Admin = "Admin";
        public static readonly string Role_Operator = "Operator";
        public static readonly string Role_DBA = "DBA";
        public static readonly string Role_None = "None";

        public static readonly string IDType_AD = "AD";
        public static readonly string IDType_JobNum = "ID";

        public static readonly char RoleSplit = '|';

        //检查用户是否属于该角色权限
        public static bool CheckRole(string userRoles, string sysRole)
        {
            if (string.IsNullOrEmpty(userRoles) || string.IsNullOrEmpty(sysRole)) return false;
            return userRoles.Split(RoleSplit).Contains(sysRole);
        }

        /// <summary>
        /// 检查用户权限是否有列表中的其中一个
        /// </summary>
        /// <param name="userRoles"></param>
        /// <param name="sysRoles"></param>
        /// <returns></returns>
        public static bool CheckRoleIntersection(string userRoles, string[] sysRoles)
        {
            if (string.IsNullOrEmpty(userRoles) || sysRoles==null || sysRoles.Length==0) return false;
            return sysRoles.Intersect(userRoles.Split(RoleSplit)).ToArray().Length > 0;
        }
    }

    public class CompanyOrganOperator
    {
        public string UserID { get; set; }
        public string IDType { get; set; }
        public string Company { get; set; }
        public string Organ { get; set; }
        public string Division { get; set; }
        public string Depart { get; set; }
        public string Group { get; set; }
    }
}
