﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LEO.Project.WXProposal.Data.Entity
{
    public class ProposalInfo
    {
        public string Number { get; set; }
        public string AuthorJobNumber { get; set; }
        public string SubmitJobNumber { get; set; }
        public DateTime? FormDate { get; set; }
        public DateTime? SubmitTime { get; set; }
        public string Status { get; set; }
        public string Category { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Advice { get; set; }
        public string WXOpenID { get; set; }
        public int SubmittersCount { get; set; }

        public ProposalYielding YieldingInfo;
        public ProposalAudit AuditInfo;
        public WXUserInfo WXUser;

        public List<EmployeeView> Submitters;
        public List<AttachmentInfo> Attachments;

        public void CopyBase(ProposalInfo pi)
        {
            if (pi == null) return;
            this.Number = pi.Number;
            this.AuthorJobNumber = pi.AuthorJobNumber;
            this.SubmitJobNumber = pi.SubmitJobNumber;
            this.FormDate = pi.FormDate;
            this.SubmittersCount = pi.SubmittersCount;
            this.SubmitTime = pi.SubmitTime;
            this.Status = pi.Status;
            this.Category = pi.Category;
            this.Title = pi.Title;
            this.Description = pi.Description;
            this.Advice = pi.Advice;
            this.WXOpenID = pi.WXOpenID;
        }

    }

    public class ProposalStatus
    {
        public static readonly string Submit = "已提交";
        public static readonly string Received = "審核中";
        public static readonly string Audited = "已審核";
        public static readonly string Accepted = "採用";
        public static readonly string Reject = "不採用";
        public static readonly string Bonus = "獎金已派發";
    }
    public class ProposalCategory
    {
        public static readonly string[] Categories = {
            "生产性向上","机台设备","品质","5S",
            "供应商","资讯系统","环境物料","物料","节能","安全","其他"
        };
        public static bool CategoryExist(string category)
        {
            if (string.IsNullOrEmpty(category)) return false;
            int idx = Array.IndexOf(Categories, category);
            return idx >= 0;
        }
    }
}
