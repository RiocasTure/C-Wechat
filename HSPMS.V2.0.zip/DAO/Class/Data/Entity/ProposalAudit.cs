﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LEO.Project.WXProposal.Data.Entity
{
    public class ProposalAudit
    {
        public string Number { get; set; }
        //20160324 delete by jimyli
        /*
        public string HeaderCfm { get; set; }
        public string HeaderCfmDate { get; set; }
        public string HeaderAudit { get; set; }
        */
        public string MajorAudit { get; set; }
        public string MajorAuditDesc { get; set; }
        public string MajorCfm { get; set; }
        public string MajorCfmDate { get; set; }
        public string FollowCharger { get; set; }
        public string FollowProgress { get; set; }
        public string FollowDesc { get; set; }
        public string FollowPlan { get; set; }
        public string FollowPlanBD { get; set; }
        public string FollowPlanED { get; set; }
        public string FollowPlanFD { get; set; }
        public string OrganAudit { get; set; }
        public string OrganCfmDate { get; set; }
        public string OrganAuditDesc { get; set; }
        public string OrganEffAmount { get; set; }
        public string OrganEffDesc { get; set; }
        public string OrganBonusMonth { get; set; }

        public void CopyOrganInfo(ProposalAudit pa)
        {
            if (pa == null) return;
            this.OrganAudit = pa.OrganAudit;
            this.OrganCfmDate = pa.OrganCfmDate;
            this.OrganAuditDesc = pa.OrganAuditDesc;
            this.OrganEffAmount = pa.OrganEffAmount;
            this.OrganEffDesc = pa.OrganEffDesc;
            this.OrganBonusMonth = pa.OrganBonusMonth;
        }
        public void CopyAuditInfo(ProposalAudit pa)
        {
            if (pa == null) return;
            this.Number = pa.Number;
            this.FollowProgress = pa.FollowProgress;
            this.MajorAudit = pa.MajorAudit;
            this.MajorAuditDesc = pa.MajorAuditDesc;
            this.MajorCfm = pa.MajorCfm;
            this.MajorCfmDate = pa.MajorCfmDate;
            this.FollowCharger = pa.FollowCharger;
            this.FollowDesc = pa.FollowDesc;
            this.FollowPlan = pa.FollowPlan;
            this.FollowPlanBD = pa.FollowPlanBD;
            this.FollowPlanED = pa.FollowPlanED;
            this.FollowPlanFD = pa.FollowPlanFD;
        }
    }
}
