﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LEO.Project.WXProposal.Data.Entity;

namespace JsonView
{
    /*
    public class Organization
    {
        public List<string> Companies;
        public List<string> Organs;
        public List<string> Divisions;
        public List<string> Departs;
        public List<string> Groups;
        public List<string> JobTitles;

        public List<string> GetListByStructName(string structName)
        {
            return null;
        }
        public Organization()
        {
            Companies = new List<string>();
            Organs = new List<string>();
            Divisions = new List<string>();
            Departs = new List<string>();
            Groups = new List<string>();
            JobTitles = new List<string>();
        }
    }
    */

    public class OrganizationTree
    {
        public List<TreeNode> Companies;

        public OrganizationTree()
        {
            Companies = new List<TreeNode>();
        }
    }
}
