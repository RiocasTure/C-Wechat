﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LEO.Project.WXProposal.Data.Entity
{
    public class ProposalYielding
    {
        public string SONum { get; set; }
        public string ItemName { get; set; }
        public string OrderQty { get; set; }
        public string EQID { get; set; }
        public string EQName { get; set; }
        public string WorkersNow { get; set; }
        public string WorkersOptimized { get; set; }
        public string EffNow { get; set; }
        public string EffOptimized { get; set; }
        public string DPRateNow { get; set; }
        public string DPRateOptimized { get; set; }
        public string CalEffAmount { get; set; }
        public string OtherResult { get; set; }

        public void Copy(ProposalYielding py)
        {
            if (py == null) return;
            this.SONum = py.SONum;
            this.ItemName = py.ItemName;
            this.OrderQty = py.OrderQty;
            this.EQID = py.EQID;
            this.EQName = py.EQName;
            this.WorkersNow = py.WorkersNow;
            this.WorkersOptimized = py.WorkersOptimized;
            this.EffNow = py.EffNow;
            this.EffOptimized = py.EffOptimized;
            this.DPRateNow = py.DPRateNow;
            this.DPRateOptimized = py.DPRateOptimized;
            this.CalEffAmount = py.CalEffAmount;
            this.OtherResult = py.OtherResult;
        }

    }
}
