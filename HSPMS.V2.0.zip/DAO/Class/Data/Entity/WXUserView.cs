﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LEO.Project.WXProposal.Data.Entity
{
    public class WXUserView
    {
        public string OpenID { get; set; }
        public string NickName { get; set; }
        public string Region { get; set; }
        public string LastUpdate { get; set; }
        public string JobNumber { get; set; }
        public string FullName { get; set; }
        public string Mobile { get; set; }
        public int ProposalCount { get; set; }
    }
}
