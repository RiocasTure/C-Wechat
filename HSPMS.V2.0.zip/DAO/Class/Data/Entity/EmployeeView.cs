﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LEO.Project.WXProposal.Data.Entity
{
    public class EmployeeView:Employee
    {
        //所在提案權重
        public string ProposalWeight { get; set; }
        public List<WXUserInfo> WXUserList { get; set; }
    }
}
