﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LEO.Project.WXProposal.Data.Entity
{
    public class Employee
    {
        #region properties
        public string JobNumber { get; set; }
        public string FullName { get; set; }
        public string IDNumSuffix { get; set; }
        public string Mobile { get; set; }
        public DateTime? LastUpdate { get; set; }

        /// <summary>
        /// 0=无效,1=在职,2=离职
        /// </summary>
        public byte Status { get; set; }

        public string Company { get; set; }
        public string Organ { get; set; }
        public string Depart { get; set; }
        public string Category { get; set; }
        public string JobTitle { get; set; }
        public string EntryDate { get; set; }
        public string Gender { get; set; }
        public string SectionChiefName { get; set; }
        /// <summary>
        /// 事业部
        /// </summary>
        public string Division { get; set; }
        /// <summary>
        /// 科组
        /// </summary>
        public string Group { get; set; }

        #endregion

    }
    public class EmployeeStatus
    {
        public static readonly int Invalid = 0;
        public static readonly int Valid = 1;
        public static readonly int Resigned = 2;
    }
}
