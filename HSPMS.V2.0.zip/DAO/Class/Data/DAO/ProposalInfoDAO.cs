﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using JsonView;
using LEO.Project.WXProposal.Data.Entity;
using LEO.Project.WXProposal.Model.Pagination;
using LEO.Project.Tools;
using LEO.Project.WXProposal.Model.QueryFilter;
using System.IO;

namespace LEO.Project.WXProposal.Data.DAO
{
    public class ProposalInfoDAO
    {
        //private static string monthStr = null;
        //private static int monthSerial = 0;
        /// <summary>
        /// 自動生成月內提案編號（格式：S+2位年份+2位月份+4位當月流水號）
        /// </summary>
        /// <returns></returns>
        public static string GenerateSerialNumber()
        {
            string monthStr = null;
            int monthSerial = 0;
            string mStr = DateTime.Now.ToString("yyMM");
            if (monthStr == null || monthSerial == 0)
            {
                //string strSQL = "select max(PPS_Number) as maxnum from TA_Proposal where PPS_Number like 'S" + mStr + "____'";
                string strSQL = "select max(right(PPS_Number,8)) as maxnum from TA_Proposal where right(PPS_Number,8) like '" + mStr + "____'";
                DataSet data = SqlHelper.ExecuteDataset(strSQL);
                if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                {
                    DataRow row = data.Tables[0].Rows[0];
                    string maxnum = Convert.ToString(data.Tables[0].Rows[0]["maxnum"]);
                    data.Clear();
                    if (maxnum != null && maxnum.Length == 8)//if (maxnum != null && maxnum.Length == 9)
                    {
                        maxnum = maxnum.Substring(maxnum.Length - 4);
                        try
                        {
                            monthSerial = Int32.Parse(maxnum);
                            monthStr = mStr;
                        }
                        catch (Exception)
                        {
                            monthSerial = 0;
                        }
                    }
                }

            }
            //S（取提案英文單Suggestion第1個字母+2位年份+2位月份+4位流水號
            if (monthStr != mStr)
            {
                monthStr = mStr;
                monthSerial = 1;
            }
            else monthSerial += 1;
            return String.Format("T{0}{1:0000}", monthStr, monthSerial);
        }

        /// <summary>
        /// 計算成效金額(單位時間-小時)
        /// </summary>
        /// <param name="wn">改善前人數</param>
        /// <param name="wo">改善後人數</param>
        /// <param name="en">改善前效率</param>
        /// <param name="eo">改善後效率</param>
        /// <param name="oq">訂單數量</param>
        /// <returns>成效金額(單位時間-小時)</returns>
        public static string CalculateEffAmount(string wn, string wo, string en, string eo, string oq)
        {
            double d_wn = StringUtils.ConvertToInt(wn);
            double d_wo = StringUtils.ConvertToInt(wo);
            int i_en = StringUtils.ConvertToInt(en);
            int i_eo = StringUtils.ConvertToInt(eo);
            int i_oq = StringUtils.ConvertToInt(oq);
            return (i_en > 0 && i_eo > 0) ? string.Format("{0:#,###}", (60 * (d_wn / i_en - d_wo / i_eo) * i_oq * 0.1)) : "";
        }

        /// <summary>
        /// 根據提案編號獲取數據生成提案對象 for detail
        /// </summary>
        /// <param name="number">提案編號</param>
        /// <returns>提案對象</returns>
        public static ProposalInfo GetProposalByNumber(string number)
        {
            if (string.IsNullOrEmpty(number)) return null;
            ProposalInfo pi = null;
            try
            {
                string strSQL = "SELECT TOP 1 * FROM dbo.TA_Proposal WHERE PPS_Number=@Number";
                List<SqlParameter> list = new List<SqlParameter>();
                list.Add(SqlHelper.MakeInParam("@Number", SqlDbType.VarChar, 16, number));
                DataSet data = SqlHelper.ExecuteDataset(strSQL, list.ToArray());
                if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                {
                    DataRow row = data.Tables[0].Rows[0];
                    pi = new ProposalInfo();
                    pi.Number = Convert.ToString(row["PPS_Number"]);
                    pi.AuthorJobNumber = Convert.ToString(row["PPS_Author_JobNumber"]);
                    pi.SubmitJobNumber = Convert.ToString(row["PPS_Submit_JobNumber"]);
                    pi.FormDate = Convert.ToDateTime(row["PPS_Form_Date"]);
                    pi.SubmitTime = Convert.ToDateTime(row["PPS_Submit_Time"]);
                    pi.Status = Convert.ToString(row["PPS_Status"]);
                    pi.Category = Convert.ToString(row["PPS_Category"]);
                    pi.Title = Convert.ToString(row["PPS_Title"]);
                    pi.Description = Convert.ToString(row["PPS_Description"]);
                    pi.Advice = Convert.ToString(row["PPS_Advice"]);
                    pi.WXOpenID = Convert.ToString(row["PPS_WX_OpenID"]);
                    data.Clear();
                }
                if (pi != null)
                {
                    strSQL = "SELECT TOP 1 * FROM dbo.TA_Proposal_Addition WHERE PPA_Number=@Number";
                    data = SqlHelper.ExecuteDataset(strSQL, list.ToArray());
                    if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                    {
                        DataRow row = data.Tables[0].Rows[0];
                        ProposalYielding py = new ProposalYielding();
                        py.SONum = Convert.ToString(row["PPA_SONum"]);
                        py.ItemName = Convert.ToString(row["PPA_ItemName"]);
                        py.OrderQty = Convert.ToString(row["PPA_OrderQty"]);
                        py.EQID = Convert.ToString(row["PPA_EQID"]);
                        py.EQName = Convert.ToString(row["PPA_EQName"]);
                        py.WorkersNow = Convert.ToString(row["PPA_Workers_Now"]);
                        py.WorkersOptimized = Convert.ToString(row["PPA_Workers_Optimized"]);
                        py.EffNow = Convert.ToString(row["PPA_Eff_Now"]);
                        py.EffOptimized = Convert.ToString(row["PPA_Eff_Optimized"]);
                        py.DPRateNow = Convert.ToString(row["PPA_DPRate_Now"]);
                        py.DPRateOptimized = Convert.ToString(row["PPA_DPRate_Optimized"]);
                        py.OtherResult = Convert.ToString(row["PPA_Other_Result"]);
                        data.Clear();
                        pi.YieldingInfo = py;
                    }
                    strSQL = "SELECT TOP 1 * FROM dbo.TA_Proposal_Audit WHERE PPA_Number=@Number";
                    data = SqlHelper.ExecuteDataset(strSQL, list.ToArray());
                    if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                    {
                        DataRow row = data.Tables[0].Rows[0];
                        ProposalAudit pa = new ProposalAudit();
                        //pa.Number = Convert.ToString(row["PPA_Number"]);
                        //20160324 delete by jimyli
                        /*
                        pa.HeaderCfm = Convert.ToString(row["PPA_HeaderCfm"]);
                        pa.HeaderCfmDate = Convert.ToString(row["PPA_HeaderCfmDate"]);
                        pa.HeaderAudit = Convert.ToString(row["PPA_HeaderAudit"]);
                        */
                        pa.MajorAudit = Convert.ToString(row["PPA_MajorAudit"]);
                        pa.MajorAuditDesc = Convert.ToString(row["PPA_MajorAuditDesc"]);
                        pa.MajorCfm = Convert.ToString(row["PPA_MajorCfm"]);
                        pa.MajorCfmDate = Convert.ToString(row["PPA_MajorCfmDate"]);
                        pa.FollowCharger = Convert.ToString(row["PPA_FollowCharger"]);
                        pa.FollowProgress = Convert.ToString(row["PPA_FollowProgress"]);
                        pa.FollowDesc = Convert.ToString(row["PPA_FollowDesc"]);
                        pa.FollowPlan = Convert.ToString(row["PPA_FollowPlan"]);
                        pa.FollowPlanBD = Convert.ToString(row["PPA_FollowPlanBD"]);
                        pa.FollowPlanED = Convert.ToString(row["PPA_FollowPlanED"]);
                        pa.FollowPlanFD = Convert.ToString(row["PPA_FollowPlanFD"]);
                        pa.OrganAudit = Convert.ToString(row["PPA_OrganAudit"]);
                        pa.OrganAuditDesc = Convert.ToString(row["PPA_OrganAuditDesc"]);
                        pa.OrganCfmDate = Convert.ToString(row["PPA_OrganCfmDate"]);
                        pa.OrganEffAmount = Convert.ToString(row["PPA_OrganEffAmount"]);
                        pa.OrganEffDesc = Convert.ToString(row["PPA_OrganEffDesc"]);
                        pa.OrganBonusMonth = Convert.ToString(row["PPA_OrganBonusMonth"]);
                        data.Clear();
                        pi.AuditInfo = pa;
                    }
                    strSQL = "SELECT e.*,t.STF_SectionChiefName FROM dbo.TA_Submitter AS s "
                        + "LEFT JOIN dbo.TA_Employee AS e ON e.EMP_JobNumber=s.PPS_JobNumber "
                        + "LEFT JOIN dbo.TA_StaffInfo AS t ON t.STF_PersonNumber=s.PPS_JobNumber "
                        + "WHERE PPS_Number=@Number";
                    data = SqlHelper.ExecuteDataset(strSQL, list.ToArray());
                    if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                    {
                        pi.Submitters = new List<EmployeeView>();
                        foreach (DataRow row in data.Tables[0].Rows)
                        {
                            EmployeeView e = new EmployeeView();
                            e.JobNumber = Convert.ToString(row["EMP_JobNumber"]);
                            e.FullName = Convert.ToString(row["EMP_FullName"]);
                            e.Status = Convert.ToByte(row["EMP_Status"]);
                            e.Company = Convert.ToString(row["EMP_Company"]);
                            e.Organ = Convert.ToString(row["EMP_Organ"]);
                            e.Division = Convert.ToString(row["EMP_Division"]);
                            e.Depart = Convert.ToString(row["EMP_Depart"]);
                            e.Group = Convert.ToString(row["EMP_Group"]);
                            e.Category = Convert.ToString(row["EMP_Category"]);
                            e.SectionChiefName = Convert.ToString(row["STF_SectionChiefName"]);
                            e.WXUserList = WXUserInfoDAO.GetWXUserListByJobNumber(e.JobNumber);
                            pi.Submitters.Add(e);
                        }
                        data.Clear();
                    }
                    pi.Attachments = ProposalFileDAO.GetListByProposalNumber(pi.Number);
                }
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("Get ProposalInfo error: number={0}", number), e);
            }
            return pi;
        }

        /// <summary>
        /// 獲取指定工號職員工今日已提交的提案數（用以限制每人每日提案數）
        /// 具體上限見Web.config中的SysConfig.MaxProposalCountByDaily設置值
        /// </summary>
        /// <param name="JobNumber">職員工工號</param>
        /// <returns>指定工號職員工今日已提交的提案數</returns>
        public static int GetTodayProposalCountByJobNumber(string JobNumber)
        {
            if (string.IsNullOrEmpty(JobNumber)) return -1;
            int pCount = 0;
            try
            {
                string strSQL = "SELECT COUNT(1) AS today_count FROM ta_proposal " +
                    "WHERE pps_author_jobnumber=@JobNumber AND DATEDIFF(day,pps_submit_time,GETDATE())=0";
                List<SqlParameter> list = new List<SqlParameter>();
                list.Add(SqlHelper.MakeInParam("@JobNumber", SqlDbType.VarChar, 16, JobNumber));
                DataSet data = SqlHelper.ExecuteDataset(strSQL, list.ToArray());
                if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                {
                    DataRow row = data.Tables[0].Rows[0];
                    pCount = Convert.ToInt32(row[0]);
                    data.Clear();
                }
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("Get GetTodayProposalCountByJobNumber error: JobNumber={0}", JobNumber), e);
            }
            return pCount;
        }

        /// <summary>
        /// 保存提案對象到數據庫表（新增或修改）
        /// 如數據庫記錄不存在，則新增(insert)，否則作修改(update)
        /// </summary>
        /// <param name="pi">提案對象</param>
        /// <returns>提案表數據更改記錄數，1為成功，否則為失敗</returns>
        public static int SaveProposalInfo(ProposalInfo pi)
        {
            SqlConnection con = null;
            if (pi == null) return 0;
            SqlTransaction trans = null;
            int result = -1;
            try
            {
                con = SqlHelper.GetConnection();
                if (con == null) return -2;
                trans = SqlHelper.BeginTransaction(con);
                if (trans != null)
                {
                    string strUpdateSQL = "UPDATE dbo.TA_Proposal SET "
                        + "PPS_Author_JobNumber=@AuthorJobNum,PPS_Submit_JobNumber=@SubmitJobNum,"
                        + "PPS_Form_Date=@FormDate,PPS_Submit_Time=@SubmitTime,PPS_Status=@Status,"
                        + "PPS_Category=@Category,PPS_Title=@Title,PPS_Description=@Description,"
                        + "PPS_Advice=@Advice,PPS_WX_OpenID=@WXOpenID WHERE PPS_Number=@Number";
                    string strInsertSQL = "INSERT INTO dbo.TA_Proposal("
                        + "PPS_Number,PPS_Author_JobNumber,PPS_Submit_JobNumber,PPS_Form_Date,PPS_Submit_Time,"
                        + "PPS_Status,PPS_Category,PPS_Title,PPS_Description,PPS_Advice,PPS_WX_OpenID"
                        + ") VALUES (@Number,@AuthorJobNum,@SubmitJobNum,@FormDate,@SubmitTime,@Status,"
                        + "@Category,@Title,@Description,@Advice,@WXOpenID)";
                    List<SqlParameter> list = new List<SqlParameter>();
                    list.Add(SqlHelper.MakeInParam("@Number", SqlDbType.VarChar, 16, pi.Number));
                    list.Add(SqlHelper.MakeInParam("@AuthorJobNum", SqlDbType.VarChar, 8, pi.AuthorJobNumber));
                    list.Add(SqlHelper.MakeInParam("@SubmitJobNum", SqlDbType.VarChar, 8, pi.SubmitJobNumber));
                    list.Add(SqlHelper.MakeInParam("@FormDate", SqlDbType.DateTime, 0, pi.FormDate));
                    list.Add(SqlHelper.MakeInParam("@SubmitTime", SqlDbType.DateTime, 0, pi.SubmitTime));
                    list.Add(SqlHelper.MakeInParam("@Status", SqlDbType.NVarChar, 8, pi.Status));
                    list.Add(SqlHelper.MakeInParam("@Category", SqlDbType.NVarChar, 8, pi.Category));
                    list.Add(SqlHelper.MakeInParam("@Title ", SqlDbType.NVarChar, 32, pi.Title));
                    list.Add(SqlHelper.MakeInParam("@Description ", SqlDbType.NVarChar, 256, pi.Description));
                    list.Add(SqlHelper.MakeInParam("@Advice", SqlDbType.NVarChar, 256, pi.Advice));
                    list.Add(SqlHelper.MakeInParam("@WXOpenID", SqlDbType.VarChar, 32, pi.WXOpenID));
                    int rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strUpdateSQL, list.ToArray()));
                    if (rowsAffected==0)
                        rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strInsertSQL, list.ToArray()));
                    if (rowsAffected > 0 && pi.YieldingInfo!=null)
                    {
                        strUpdateSQL = "UPDATE dbo.TA_Proposal_Addition SET "
                            + "PPA_SONum=@SONum,PPA_ItemName=@ItemName,PPA_OrderQty=@OrderQty,PPA_EQID=@EQID,"
                            + "PPA_EQName=@EQName,PPA_Workers_Now=@WorkersNow,PPA_Workers_Optimized=@WorkersOptimized,"
                            + "PPA_Eff_Now=@EffNow,PPA_Eff_Optimized=@EffOptimized,PPA_DPRate_Now=@DPRateNow,"
                            + "PPA_DPRate_Optimized=@DPRateOptimized,PPA_Other_Result=@OtherResult WHERE PPA_Number=@Number";
                        strInsertSQL = "INSERT INTO dbo.TA_Proposal_Addition(PPA_Number,PPA_SONum,PPA_ItemName,"
                            + "PPA_OrderQty,PPA_EQID,PPA_EQName,PPA_Workers_Now,PPA_Workers_Optimized,PPA_Eff_Now,"
                            + "PPA_Eff_Optimized,PPA_DPRate_Now,PPA_DPRate_Optimized,PPA_Other_Result"
                            + ") VALUES (@Number,@SONum,@ItemName,@OrderQty,@EQID,@EQName,@WorkersNow,@WorkersOptimized,"
                            + "@EffNow,@EffOptimized,@DPRateNow,@DPRateOptimized,@OtherResult)";
                        list.Clear();
                        list.Add(SqlHelper.MakeInParam("@Number", SqlDbType.VarChar, 16, pi.Number));
                        list.Add(SqlHelper.MakeInParam("@SONum", SqlDbType.NVarChar, 8, pi.YieldingInfo.SONum));
                        list.Add(SqlHelper.MakeInParam("@ItemName", SqlDbType.NVarChar, 64, pi.YieldingInfo.ItemName));
                        list.Add(SqlHelper.MakeInParam("@OrderQty", SqlDbType.VarChar, 16, pi.YieldingInfo.OrderQty));
                        list.Add(SqlHelper.MakeInParam("@EQID", SqlDbType.NVarChar, 32, pi.YieldingInfo.EQID));
                        list.Add(SqlHelper.MakeInParam("@EQName", SqlDbType.NVarChar, 64, pi.YieldingInfo.EQName));
                        list.Add(SqlHelper.MakeInParam("@WorkersNow", SqlDbType.NVarChar, 8, pi.YieldingInfo.WorkersNow));
                        list.Add(SqlHelper.MakeInParam("@WorkersOptimized", SqlDbType.NVarChar, 8, pi.YieldingInfo.WorkersOptimized));
                        list.Add(SqlHelper.MakeInParam("@EffNow", SqlDbType.NVarChar, 8, pi.YieldingInfo.EffNow));
                        list.Add(SqlHelper.MakeInParam("@EffOptimized", SqlDbType.NVarChar, 8, pi.YieldingInfo.EffOptimized));
                        list.Add(SqlHelper.MakeInParam("@DPRateNow", SqlDbType.NVarChar, 8, pi.YieldingInfo.DPRateNow));
                        list.Add(SqlHelper.MakeInParam("@DPRateOptimized", SqlDbType.NVarChar, 8, pi.YieldingInfo.DPRateOptimized));
                        list.Add(SqlHelper.MakeInParam("@OtherResult", SqlDbType.NVarChar, 64, pi.YieldingInfo.OtherResult));
                        rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strUpdateSQL, list.ToArray()));
                        if (rowsAffected == 0)
                            rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strInsertSQL, list.ToArray()));
                    }
                    if (rowsAffected > 0 && pi.AuditInfo!=null)
                    {
                        strUpdateSQL = "UPDATE dbo.TA_Proposal_Audit SET "
                            //+ "PPA_HeaderCfm=@HeaderCfm,PPA_HeaderCfmDate=@HeaderCfmDate,PPA_HeaderAudit=@HeaderAudit,"
                            + "PPA_MajorAudit=@MajorAudit,PPA_MajorAuditDesc=@MajorAuditDesc,PPA_MajorCfm=@MajorCfm,PPA_MajorCfmDate=@MajorCfmDate,"
                            + "PPA_FollowCharger=@FollowCharger,PPA_FollowProgress=@FollowProgress,PPA_FollowDesc=@FollowDesc,"
                            + "PPA_FollowPlan=@FollowPlan,PPA_FollowPlanBD=@FollowPlanBD,PPA_FollowPlanED=@FollowPlanED,"
                            + "PPA_FollowPlanFD=@FollowPlanFD,PPA_OrganAudit=@OrganAudit,PPA_OrganCfmDate=@OrganCfmDate,"
                            + "PPA_OrganAuditDesc=@OrganAuditDesc,PPA_OrganEffAmount=@OrganEffAmount,PPA_OrganEffDesc=@OrganEffDesc,"
                            + "PPA_OrganBonusMonth=@OrganBonusMonth WHERE PPA_Number=@Number";
                        strInsertSQL = "INSERT INTO dbo.TA_Proposal_Audit("
                            + "PPA_Number,"
                            //+ "PPA_HeaderCfm,PPA_HeaderCfmDate,PPA_HeaderAudit,"
                            + "PPA_MajorAudit,PPA_MajorAuditDesc,"
                            + "PPA_MajorCfm,PPA_MajorCfmDate,PPA_FollowCharger,PPA_FollowProgress,PPA_FollowDesc,PPA_FollowPlan,"
                            + "PPA_FollowPlanBD,PPA_FollowPlanED,PPA_FollowPlanFD,PPA_OrganAudit,PPA_OrganCfmDate,PPA_OrganAuditDesc,"
                            + "PPA_OrganEffAmount,PPA_OrganEffDesc,PPA_OrganBonusMonth"
                            + ") VALUES ("
                            + "@Number," 
                            //+ "@HeaderCfm,@HeaderCfmDate,@HeaderAudit," 
                            + "@MajorAudit,@MajorAuditDesc,@MajorCfm,@MajorCfmDate,"
                            + "@FollowCharger,@FollowProgress,@FollowDesc,@FollowPlan,@FollowPlanBD,@FollowPlanED,@FollowPlanFD,"
                            + "@OrganAudit,@OrganCfmDate,@OrganAuditDesc,@OrganEffAmount,@OrganEffDesc,@OrganBonusMonth"
                            + ")";
                        list.Clear();
                        list.Add(SqlHelper.MakeInParam("@Number", SqlDbType.VarChar, 16, pi.Number));
                        list.Add(SqlHelper.MakeInParam("@MajorAudit", SqlDbType.NVarChar, 8, pi.AuditInfo.MajorAudit));
                        list.Add(SqlHelper.MakeInParam("@MajorAuditDesc", SqlDbType.NVarChar, 64, pi.AuditInfo.MajorAuditDesc));
                        list.Add(SqlHelper.MakeInParam("@MajorCfm", SqlDbType.NVarChar, 16, pi.AuditInfo.MajorCfm));
                        list.Add(SqlHelper.MakeInParam("@MajorCfmDate", SqlDbType.VarChar, 16, pi.AuditInfo.MajorCfmDate));
                        list.Add(SqlHelper.MakeInParam("@FollowCharger", SqlDbType.NVarChar, 16, pi.AuditInfo.FollowCharger));
                        list.Add(SqlHelper.MakeInParam("@FollowProgress", SqlDbType.NVarChar, 8, pi.AuditInfo.FollowProgress));
                        list.Add(SqlHelper.MakeInParam("@FollowDesc", SqlDbType.NVarChar, 256, pi.AuditInfo.FollowDesc));
                        list.Add(SqlHelper.MakeInParam("@FollowPlan", SqlDbType.NVarChar, 256, pi.AuditInfo.FollowPlan));
                        list.Add(SqlHelper.MakeInParam("@FollowPlanBD", SqlDbType.VarChar, 16, pi.AuditInfo.FollowPlanBD));
                        list.Add(SqlHelper.MakeInParam("@FollowPlanED", SqlDbType.VarChar, 16, pi.AuditInfo.FollowPlanED));
                        list.Add(SqlHelper.MakeInParam("@FollowPlanFD", SqlDbType.VarChar, 16, pi.AuditInfo.FollowPlanFD));
                        list.Add(SqlHelper.MakeInParam("@OrganAudit", SqlDbType.NVarChar, 8, pi.AuditInfo.OrganAudit));
                        list.Add(SqlHelper.MakeInParam("@OrganCfmDate", SqlDbType.VarChar, 16, pi.AuditInfo.OrganCfmDate));
                        list.Add(SqlHelper.MakeInParam("@OrganAuditDesc", SqlDbType.NVarChar, 64, pi.AuditInfo.OrganAuditDesc));
                        list.Add(SqlHelper.MakeInParam("@OrganEffAmount", SqlDbType.NVarChar, 8, pi.AuditInfo.OrganEffAmount));
                        list.Add(SqlHelper.MakeInParam("@OrganEffDesc", SqlDbType.NVarChar, 256, pi.AuditInfo.OrganEffDesc));
                        list.Add(SqlHelper.MakeInParam("@OrganBonusMonth", SqlDbType.VarChar, 8, pi.AuditInfo.OrganBonusMonth));
                        rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strUpdateSQL, list.ToArray()));
                        if (rowsAffected == 0)
                            rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strInsertSQL, list.ToArray()));
                    }

                    string strDeleteSQL = "DELETE FROM dbo.TA_Submitter WHERE PPS_Number=@Number";
                    list.Clear();
                    list.Add(SqlHelper.MakeInParam("@Number", SqlDbType.VarChar, 16, pi.Number));
                    int delCount = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strDeleteSQL, list.ToArray()));
                    if (rowsAffected > 0 && pi.Submitters != null && pi.Submitters.Count > 0)
                    {
                        strInsertSQL = "INSERT INTO dbo.TA_Submitter(PPS_Number,PPS_JobNumber) VALUES (@Number,@JobNumber)";
                        for (int i = 0; rowsAffected > 0 && i < pi.Submitters.Count; i++)
                        {
                            Employee emp = pi.Submitters[i];
                            if (emp!=null && !string.IsNullOrEmpty(emp.JobNumber))
                            {
                                list.Clear();
                                list.Add(SqlHelper.MakeInParam("@Number", SqlDbType.VarChar, 16, pi.Number));
                                list.Add(SqlHelper.MakeInParam("@JobNumber", SqlDbType.VarChar, 8, emp.JobNumber));
                                rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strInsertSQL, list.ToArray()));
                            }
                        }
                    }
                    if (rowsAffected > 0)
                    {
                        int updtCount = ProposalFileDAO.TransDeleteByRelatedKey(pi.Number, trans);
                        if (pi.Attachments != null && pi.Attachments.Count > 0)
                        {
                            for (int i = 0; rowsAffected > 0 && i < pi.Attachments.Count; i++)
                            {
                                pi.Attachments[i].RelatedKey = pi.Number;
                                rowsAffected = ProposalFileDAO.TransSave(pi.Attachments[i], trans);
                            }
                        }
                    }
                    if (rowsAffected > 0) result = 1;
                }
            }
            catch (Exception e)
            {
                WriteLog.Error("Insert ProposalInfo error", e);
            }
            finally
            {
                try
                {
                    if (trans != null)
                    {
                        if (result > 0) SqlHelper.CommitTransaction(trans);
                        else SqlHelper.RollbackTransaction(trans);
                    }
                    if (con != null)
                    {
                        SqlHelper.ReleaseConnection(con);
                    }
                }
                catch(Exception ex)
                {
                    WriteLog.Error("Commit/Rollback/Release Connection Error", ex);
                }
            }
            return result;
        }

        /// <summary>
        /// 根據指定的職員工工號及微信ID获取并返回对应的提案对象列表
        /// </summary>
        /// <param name="keyword">查询关键字（搜索标题、问题描述、建议）</param>
        /// <param name="jobNumber">職員工工號</param>
        /// <param name="openId">微信ID</param>
        /// <param name="frmDateBegin">提案日期开始日期</param>
        /// <param name="frmDateEnd">提案日期结束日期</param>
        /// <param name="status">提案流程状态</param>
        /// <param name="pl">已初始化的分页对象，结果将技术分页参数并将当前页数据加入PageData的列表属性中</param>
        public static void PaginationQuery(string keyword, string jobNumber, string openId, string frmDateBegin, string frmDateEnd, string status, PageList pl)
        {
            pl.PageData = new List<object>();
            if (pl.PageSize <= 0 || pl.PageIndex <= 0) return;
            try
            {
                string strFROM = "FROM dbo.TA_Proposal as a";
                string strWHERE = " WHERE 1=1"
                    + (string.IsNullOrEmpty(jobNumber) ? "" : " AND a.PPS_Author_JobNumber=@jobNumber")
                    + (string.IsNullOrEmpty(openId) ? "" : " AND a.PPS_WX_OpenID=@openId")
                    + (string.IsNullOrEmpty(frmDateBegin) ? "" : " AND a.PPS_Form_Date>=CAST(@dateBegin AS SMALLDATETIME)")
                    + (string.IsNullOrEmpty(frmDateEnd) ? "" : " AND a.PPS_Form_Date<=CAST(@dateEnd AS SMALLDATETIME)")
                    + (string.IsNullOrEmpty(status) ? "" : " AND a.PPS_Status=@status")
                    + (string.IsNullOrEmpty(keyword) ? "" : " AND (a.PPS_Title LIKE @keyword OR a.PPS_Description LIKE @keyword OR a.PPS_Advice LIKE @keyword)");
                string strCountSQL = "SELECT COUNT(1) " + strFROM + strWHERE;
                List<SqlParameter> list = new List<SqlParameter>();
                if (!string.IsNullOrEmpty(jobNumber))
                    list.Add(SqlHelper.MakeInParam("@jobNumber", SqlDbType.VarChar, 16, jobNumber));
                if (!string.IsNullOrEmpty(openId))
                    list.Add(SqlHelper.MakeInParam("@openId", SqlDbType.VarChar, 32, openId));
                if (!string.IsNullOrEmpty(frmDateBegin))
                    list.Add(SqlHelper.MakeInParam("@dateBegin", SqlDbType.VarChar, 16, frmDateBegin+" 00:00"));
                if (!string.IsNullOrEmpty(frmDateEnd))
                    list.Add(SqlHelper.MakeInParam("@dateEnd", SqlDbType.VarChar, 16, frmDateEnd + " 23:59"));
                if (!string.IsNullOrEmpty(status))
                    list.Add(SqlHelper.MakeInParam("@status", SqlDbType.NVarChar, 8, status));
                if (!string.IsNullOrEmpty(keyword))
                    list.Add(SqlHelper.MakeInParam("@keyword", SqlDbType.NVarChar, 16, "%" + keyword + "%"));
                DataSet data = SqlHelper.ExecuteDataset(strCountSQL, list.ToArray());
                pl.RowsCount = (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0) ? Convert.ToInt32(data.Tables[0].Rows[0][0]) : 0;
                pl.Calulate();
                pl.PageData.Clear();
                if (pl.RowsCount > 0)
                {
                    int start = (pl.PageIndex - 1) * pl.PageSize + 1;
                    int end = start + pl.PageSize - 1;
                    string strSQL = "select * from ("
                        + "SELECT ROW_NUMBER() OVER(ORDER BY a.PPS_Form_Date DESC,a.PPS_Number DESC) AS NUMBER,a.*,b.*"
                        + ",c.PPA_OrganAudit,c.PPA_OrganAuditDesc " + strFROM
                        + " LEFT JOIN TA_Proposal_Addition as b on b.PPA_Number=a.PPS_Number "
                        + " LEFT JOIN TA_Proposal_Audit as c on c.PPA_Number=a.PPS_Number "
                        + strWHERE
                        //+ " ORDER BY a.PPS_Form_Date" //over关键字中已经有order by，这里添加会导致运行出错
                        + ") AS t where t.NUMBER BETWEEN " + start + " AND "+end;
                    data = SqlHelper.ExecuteDataset(strSQL, list.ToArray());
                    if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow row in data.Tables[0].Rows)
                        {
                            ProposalInfo pi = new ProposalInfo();
                            pi.Number = Convert.ToString(row["PPS_Number"]);
                            pi.AuthorJobNumber = Convert.ToString(row["PPS_Author_JobNumber"]);
                            pi.SubmitJobNumber = Convert.ToString(row["PPS_Submit_JobNumber"]);
                            pi.FormDate = Convert.ToDateTime(row["PPS_Form_Date"]);
                            pi.SubmitTime = Convert.ToDateTime(row["PPS_Submit_Time"]);
                            pi.Status = Convert.ToString(row["PPS_Status"]);
                            pi.Category = Convert.ToString(row["PPS_Category"]);
                            pi.Title = Convert.ToString(row["PPS_Title"]);
                            pi.Description = Convert.ToString(row["PPS_Description"]);
                            pi.Advice = Convert.ToString(row["PPS_Advice"]);
                            pi.WXOpenID = Convert.ToString(row["PPS_WX_OpenID"]);
                            pi.YieldingInfo = new ProposalYielding();
                            pi.YieldingInfo.SONum = Convert.ToString(row["PPA_SONum"]);
                            pi.YieldingInfo.ItemName = Convert.ToString(row["PPA_ItemName"]);
                            pi.YieldingInfo.OrderQty = Convert.ToString(row["PPA_OrderQty"]);
                            pi.YieldingInfo.EQID = Convert.ToString(row["PPA_EQID"]);
                            pi.YieldingInfo.EQName = Convert.ToString(row["PPA_EQName"]);
                            pi.YieldingInfo.WorkersNow = Convert.ToString(row["PPA_Workers_Now"]);
                            pi.YieldingInfo.WorkersOptimized = Convert.ToString(row["PPA_Workers_Optimized"]);
                            pi.YieldingInfo.EffNow = Convert.ToString(row["PPA_Eff_Now"]);
                            pi.YieldingInfo.EffOptimized = Convert.ToString(row["PPA_Eff_Optimized"]);
                            pi.YieldingInfo.DPRateNow = Convert.ToString(row["PPA_DPRate_Now"]);
                            pi.YieldingInfo.DPRateOptimized = Convert.ToString(row["PPA_DPRate_Optimized"]);
                            pi.AuditInfo = new ProposalAudit();
                            pi.AuditInfo.OrganAudit = Convert.ToString(row["PPA_OrganAudit"]);
                            pi.AuditInfo.OrganAuditDesc = Convert.ToString(row["PPA_OrganAuditDesc"]);
                            pl.PageData.Add(pi);
                        }
                        data.Clear();
                    }
                }
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("PaginationQuery error:keyword={0}, jobNumber={1}, openId={2}, frmDateBegin={3}, frmDateEnd={4}, status={5}, pageSize={6}, pageIndex={7}", keyword, jobNumber, openId, frmDateBegin, frmDateEnd, status, pl.PageSize, pl.PageIndex), e);
            }
        }

        /// <summary>
        /// 分页查询提案列表（后台管理）
        /// </summary>
        /// <param name="ur">当前登录的用户权限，如果为null时则返回空列表</param>
        /// <param name="fl">提案查询过滤条件</param>
        /// <param name="pl">分页对象</param>
        /// <param name="isDetail">是否查看明细</param>
        public static void PaginationQueryForAdmin(UserRole ur, ProposalFilter fl, PageList pl, bool isDetail)
        {
            pl.PageData = new List<object>();
            if (pl.PageSize < 0 || pl.PageIndex <= 0) return;
            string strSQL =
                //"FROM TA_Proposal AS p " +
                "FROM TA_Submitter as s " +
                "INNER JOIN TA_Proposal AS p on s.PPS_Number=p.PPS_Number " +
                "LEFT JOIN (select pps_number,count(1) as PPS_SumitersCount from ta_submitter group by pps_number) as c on c.PPS_Number=p.PPS_Number "+
                "LEFT JOIN dbo.TA_Proposal_Audit AS a ON a.PPA_Number=p.PPS_Number " +
                "LEFT JOIN dbo.TA_Proposal_Addition as b on b.PPA_Number=p.PPS_Number " +
                //"LEFT JOIN dbo.TA_Employee AS emp ON emp.EMP_JobNumber=p.PPS_Author_JobNumber " +
                "LEFT JOIN dbo.TA_Employee AS emp ON emp.EMP_JobNumber=s.PPS_JobNumber " +
                "LEFT JOIN dbo.TA_StaffInfo AS stf ON stf.STF_PersonNumber=p.PPS_Author_JobNumber " +
                "LEFT JOIN dbo.TA_WXUserInfo as w on w.WXU_OpenID=p.PPS_WX_OpenID " +
                "WHERE 1=1 " +
                (string.IsNullOrEmpty(fl.JobNumber) && string.IsNullOrEmpty(fl.Company) && string.IsNullOrEmpty(fl.Organ) && string.IsNullOrEmpty(fl.Division) && string.IsNullOrEmpty(fl.Depart) && string.IsNullOrEmpty(fl.Group) && string.IsNullOrEmpty(fl.EmpCategory) ? "" : (
                "AND ((" +
                (string.IsNullOrEmpty(fl.JobNumber) ? "" : "AND emp.emp_JobNumber=@JobNumber ") +
                (string.IsNullOrEmpty(fl.Company) ? "" : "AND emp.emp_Company=@Company ") +
                (string.IsNullOrEmpty(fl.Organ) ? "" : "AND emp.emp_Organ=@Organ ") +
                (string.IsNullOrEmpty(fl.Division) ? "" : "AND emp.emp_Division=@Division ") +
                (string.IsNullOrEmpty(fl.Depart) ? "" : "AND emp.emp_Depart=@Depart ") +
                (string.IsNullOrEmpty(fl.Group) ? "" : "AND emp.emp_Group=@Group ") +
                (string.IsNullOrEmpty(fl.EmpCategory) ? "" : "AND emp.emp_Category=@EmpCategory ") +
                //") OR EXISTS(" +
                //"SELECT TOP 1 * FROM ta_submitter AS s " +
                //"LEFT JOIN ta_employee e ON e.emp_jobnumber=s.PPS_JobNumber " +
                //"WHERE s.PPS_Number=p.PPS_Number " +
                //(string.IsNullOrEmpty(fl.JobNumber) ? "" : "AND e.emp_JobNumber=@JobNumber ") +
                //(string.IsNullOrEmpty(fl.Company) ? "" : "AND e.emp_Company=@Company ") +
                //(string.IsNullOrEmpty(fl.Organ) ? "" : "AND e.emp_Organ=@Organ ") +
                //(string.IsNullOrEmpty(fl.Division) ? "" : "AND e.emp_Division=@Division ") +
                //(string.IsNullOrEmpty(fl.Depart) ? "" : "AND e.emp_Depart=@Depart ") +
                //(string.IsNullOrEmpty(fl.Group) ? "" : "AND e.emp_Group=@Group ") +
                //(string.IsNullOrEmpty(fl.EmpCategory) ? "" : "AND e.emp_Category=@EmpCategory ") +
                ")) ")) +
                (string.IsNullOrEmpty(fl.Number) ? "" : "AND p.PPS_Number=@Number ") +
                (string.IsNullOrEmpty(fl.Category) ? "" : "AND p.PPS_Category=@Category ") +
                (string.IsNullOrEmpty(fl.Status) ? "" : "AND p.PPS_Status=@Status ") +
                (string.IsNullOrEmpty(fl.DateBegin) ? "" : "AND p.PPS_Form_Date>=CAST(@DateBegin AS SMALLDATETIME) ") +
                (string.IsNullOrEmpty(fl.DateEnd) ? "" : "AND p.PPS_Form_Date<=CAST(@DateEnd AS SMALLDATETIME) ") +
                (string.IsNullOrEmpty(fl.AuditDateBegin) ? "" : "AND a.PPA_OrganCfmDate>=@AuditDateBegin ") +
                (string.IsNullOrEmpty(fl.AuditDateEnd) ? "" : "AND a.PPA_OrganCfmDate<=@AuditDateEnd ") +
                (string.IsNullOrEmpty(fl.FollowProgress) ? "" : "AND a.PPA_FollowProgress=@FollowProgress ") +
                (string.IsNullOrEmpty(fl.Audit) ? "" : "AND a.PPA_MajorAudit=@Audit ");
            string tmp = "((AND ";//
            int idx = strSQL.IndexOf(tmp);
            if (idx >= 0) strSQL = strSQL.Substring(0, idx + 2) + strSQL.Substring(idx + tmp.Length);

            try
            {
                List<SqlParameter> list = new List<SqlParameter>();
                if (!string.IsNullOrEmpty(fl.JobNumber))
                    list.Add(SqlHelper.MakeInParam("@JobNumber", SqlDbType.VarChar, 8, fl.JobNumber));
                if (!string.IsNullOrEmpty(fl.Company))
                    list.Add(SqlHelper.MakeInParam("@Company", SqlDbType.NVarChar, 16, fl.Company));
                if (!string.IsNullOrEmpty(fl.Organ))
                    list.Add(SqlHelper.MakeInParam("@Organ", SqlDbType.NVarChar, 16, fl.Organ));
                if (!string.IsNullOrEmpty(fl.Division))
                    list.Add(SqlHelper.MakeInParam("@Division", SqlDbType.NVarChar, 16, fl.Division));
                if (!string.IsNullOrEmpty(fl.Depart))
                    list.Add(SqlHelper.MakeInParam("@Depart", SqlDbType.NVarChar, 16, fl.Depart));
                if (!string.IsNullOrEmpty(fl.Group))
                    list.Add(SqlHelper.MakeInParam("@Group", SqlDbType.NVarChar, 16, fl.Group));
                if (!string.IsNullOrEmpty(fl.EmpCategory))
                    list.Add(SqlHelper.MakeInParam("@EmpCategory", SqlDbType.NVarChar, 4, fl.EmpCategory));
                if (!string.IsNullOrEmpty(fl.Number))
                    list.Add(SqlHelper.MakeInParam("@Number", SqlDbType.VarChar, 16, fl.Number));
                if (!string.IsNullOrEmpty(fl.Category))
                    list.Add(SqlHelper.MakeInParam("@Category", SqlDbType.NVarChar, 8, fl.Category));
                if (!string.IsNullOrEmpty(fl.Status))
                    list.Add(SqlHelper.MakeInParam("@Status", SqlDbType.NVarChar, 8, fl.Status));
                if (!string.IsNullOrEmpty(fl.DateBegin))
                    list.Add(SqlHelper.MakeInParam("@DateBegin", SqlDbType.VarChar, 23, fl.DateBegin + " 00:00"));
                if (!string.IsNullOrEmpty(fl.DateEnd))
                    list.Add(SqlHelper.MakeInParam("@DateEnd", SqlDbType.VarChar, 23, fl.DateEnd + " 23:59"));
                if (!string.IsNullOrEmpty(fl.AuditDateBegin))
                    list.Add(SqlHelper.MakeInParam("@AuditDateBegin", SqlDbType.VarChar, 16, fl.AuditDateBegin));
                if (!string.IsNullOrEmpty(fl.AuditDateEnd))
                    list.Add(SqlHelper.MakeInParam("@AuditDateEnd", SqlDbType.VarChar, 16, fl.AuditDateEnd));
                if (!string.IsNullOrEmpty(fl.FollowProgress))
                    list.Add(SqlHelper.MakeInParam("@FollowProgress", SqlDbType.NVarChar, 8, fl.FollowProgress));
                if (!string.IsNullOrEmpty(fl.Audit))
                    list.Add(SqlHelper.MakeInParam("@Audit", SqlDbType.NVarChar, 8, fl.Audit));

                /** 根据事业部管理员所辖的事业部生成过滤条件  **/
                if (ur != null && ur.OrganOperators != null && ur.OrganOperators.Count > 0)
                {
                    strSQL += "AND (";
                    for (int i = 0; i < ur.OrganOperators.Count; i++)
                    {
                        CompanyOrganOperator coo = ur.OrganOperators[i];
                        if (i > 0) strSQL += " OR ";
                        strSQL += "(emp.emp_Company=@Company" + i +
                            (string.IsNullOrEmpty(coo.Organ) ? "" : (" AND emp.emp_Organ=@Organ" + i)) +
                            (string.IsNullOrEmpty(coo.Division) ? "" : (" AND emp.emp_Division=@Division" + i)) +
                            (string.IsNullOrEmpty(coo.Depart) ? "" : (" AND emp.emp_Depart like @Depart" + i)) +
                            (string.IsNullOrEmpty(coo.Group) ? "" : (" AND emp.emp_Group like @Group" + i)) +
                            ")";
                        list.Add(SqlHelper.MakeInParam("@Company" + i, SqlDbType.NVarChar, 16, coo.Company));
                        if (!string.IsNullOrEmpty(coo.Organ))
                            list.Add(SqlHelper.MakeInParam("@Organ" + i, SqlDbType.NVarChar, 16, coo.Organ));
                        if (!string.IsNullOrEmpty(coo.Division))
                            list.Add(SqlHelper.MakeInParam("@Division" + i, SqlDbType.NVarChar, 16, coo.Division));
                        if (!string.IsNullOrEmpty(coo.Depart))
                            list.Add(SqlHelper.MakeInParam("@Depart" + i, SqlDbType.NVarChar, 16, coo.Depart + "%"));
                        if (!string.IsNullOrEmpty(coo.Group))
                            list.Add(SqlHelper.MakeInParam("@Group" + i, SqlDbType.NVarChar, 16, coo.Group + "%"));
                    }
                    strSQL += ")";
                }
                /** **/

                DataSet data = null;
                if (pl.PageSize > 0)
                {
                    string strCountSQL = "SELECT COUNT(1) AS reccount " + strSQL;
                    data = SqlHelper.ExecuteDataset(strCountSQL, list.ToArray());
                    //WriteLog.Info(strCountSQL);
                    pl.RowsCount = (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0) ? Convert.ToInt32(data.Tables[0].Rows[0][0]) : 0;
                }
                pl.PageData.Clear();
                if (pl.PageSize==0||pl.RowsCount > 0)
                {
                    int start = (pl.PageIndex - 1) * pl.PageSize + 1;
                    int end = start + pl.PageSize - 1;
                    //string strOrderBy = "ORDER BY p.PPS_Form_Date DESC,p.PPS_Number DESC";
                    string strOrderBy = "ORDER BY p.PPS_Number DESC";
                    string strPagingSQL = "SELECT "
                        + (pl.PageSize>0?("* FROM (SELECT ROW_NUMBER() OVER(" + strOrderBy + ") AS NUMBER,"):"")
                        //+ "p.PPS_Number,p.PPS_Form_Date,p.PPS_Category,p.PPS_Title,p.PPS_Status,p.PPS_Author_JobNumber,emp.EMP_FullName "
                        + "p.*,a.*,s.PPS_JobNumber,c.PPS_SumitersCount,b.PPA_SONum,b.PPA_ItemName,b.PPA_OrderQty,b.PPA_EQID,b.PPA_EQName,b.PPA_Workers_Now,b.PPA_Workers_Optimized,b.PPA_Eff_Now,b.PPA_Eff_Optimized,b.PPA_DPRate_Now,b.PPA_DPRate_Optimized,b.PPA_Other_Result,stf.STF_SectionChiefName,emp.*,w.* "
                        + strSQL+(pl.PageSize==0&&!string.IsNullOrEmpty(strOrderBy)?(" "+strOrderBy):"")
                        + (pl.PageSize>0?(") AS t WHERE t.NUMBER BETWEEN " + start + " AND " + end):"");
                    //WriteLog.Info(strPagingSQL);
                    data = SqlHelper.ExecuteDataset(strPagingSQL, list.ToArray());
                    if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow row in data.Tables[0].Rows)
                        {
                            if (isDetail)
                            {
                                ProposalInfo pi = new ProposalInfo();
                                pi.Number = Convert.ToString(row["PPS_Number"]);
                                pi.AuthorJobNumber = Convert.ToString(row["PPS_Author_JobNumber"]);
                                pi.SubmitJobNumber = Convert.ToString(row["PPS_Submit_JobNumber"]);
                                pi.FormDate = Convert.ToDateTime(row["PPS_Form_Date"]);
                                pi.SubmitTime = Convert.ToDateTime(row["PPS_Submit_Time"]);
                                pi.Status = Convert.ToString(row["PPS_Status"]);
                                pi.Category = Convert.ToString(row["PPS_Category"]);
                                pi.Title = Convert.ToString(row["PPS_Title"]);
                                pi.Description = Convert.ToString(row["PPS_Description"]);
                                pi.Advice = Convert.ToString(row["PPS_Advice"]);
                                pi.WXOpenID = Convert.ToString(row["PPS_WX_OpenID"]);
                                pi.SubmittersCount = Convert.ToInt32(row["PPS_SumitersCount"]);
                                ProposalYielding py = new ProposalYielding();
                                py.SONum = Convert.ToString(row["PPA_SONum"]);
                                py.ItemName = Convert.ToString(row["PPA_ItemName"]);
                                py.OrderQty = Convert.ToString(row["PPA_OrderQty"]);
                                py.EQID = Convert.ToString(row["PPA_EQID"]);
                                py.EQName = Convert.ToString(row["PPA_EQName"]);
                                py.WorkersNow = Convert.ToString(row["PPA_Workers_Now"]);
                                py.WorkersOptimized = Convert.ToString(row["PPA_Workers_Optimized"]);
                                py.EffNow = Convert.ToString(row["PPA_Eff_Now"]);
                                py.EffOptimized = Convert.ToString(row["PPA_Eff_Optimized"]);
                                py.DPRateNow = Convert.ToString(row["PPA_DPRate_Now"]);
                                py.DPRateOptimized = Convert.ToString(row["PPA_DPRate_Optimized"]);
                                py.OtherResult = Convert.ToString(row["PPA_Other_Result"]);
                                py.CalEffAmount = CalculateEffAmount(py.WorkersNow, py.WorkersOptimized, py.EffNow, py.EffOptimized, py.OrderQty);
                                pi.YieldingInfo = py;
                                ProposalAudit pa = new ProposalAudit();
                                pa.Number = Convert.ToString(row["PPA_Number"]);
                                pa.MajorAudit = Convert.ToString(row["PPA_MajorAudit"]);
                                pa.MajorAuditDesc = Convert.ToString(row["PPA_MajorAuditDesc"]);
                                pa.MajorCfm = Convert.ToString(row["PPA_MajorCfm"]);
                                pa.MajorCfmDate = Convert.ToString(row["PPA_MajorCfmDate"]);
                                pa.FollowCharger = Convert.ToString(row["PPA_FollowCharger"]);
                                pa.FollowProgress = Convert.ToString(row["PPA_FollowProgress"]);
                                pa.FollowDesc = Convert.ToString(row["PPA_FollowDesc"]);
                                pa.FollowPlan = Convert.ToString(row["PPA_FollowPlan"]);
                                pa.FollowPlanBD = Convert.ToString(row["PPA_FollowPlanBD"]);
                                pa.FollowPlanED = Convert.ToString(row["PPA_FollowPlanED"]);
                                pa.FollowPlanFD = Convert.ToString(row["PPA_FollowPlanFD"]);
                                pa.OrganAudit = Convert.ToString(row["PPA_OrganAudit"]);
                                pa.OrganAuditDesc = Convert.ToString(row["PPA_OrganAuditDesc"]);
                                pa.OrganCfmDate = Convert.ToString(row["PPA_OrganCfmDate"]);
                                pa.OrganEffAmount = Convert.ToString(row["PPA_OrganEffAmount"]);
                                pa.OrganEffDesc = Convert.ToString(row["PPA_OrganEffDesc"]);
                                pa.OrganBonusMonth = Convert.ToString(row["PPA_OrganBonusMonth"]);
                                pi.AuditInfo = pa;
                                WXUserInfo wxu = new WXUserInfo();
                                wxu.OpenID = Convert.ToString(row["WXU_OpenID"]);
                                wxu.NickName = Convert.ToString(row["WXU_NickName"]);
                                //wxu.JobNumber = Convert.ToString(row["EWL_JobNumber"]);
                                pi.WXUser = wxu;
                                pi.Submitters = new List<EmployeeView>();
                                EmployeeView e = new EmployeeView();
                                e.JobNumber = Convert.ToString(row["EMP_JobNumber"]);
                                e.FullName = Convert.ToString(row["EMP_FullName"]);
                                e.Mobile = Convert.ToString(row["EMP_Mobile"]);
                                e.Status = Convert.ToByte(row["EMP_Status"]);
                                e.Company = Convert.ToString(row["EMP_Company"]);
                                e.Organ = Convert.ToString(row["EMP_Organ"]);
                                e.Division = Convert.ToString(row["EMP_Division"]);
                                e.Depart = Convert.ToString(row["EMP_Depart"]);
                                e.Group = Convert.ToString(row["EMP_Group"]);
                                e.Category = Convert.ToString(row["EMP_Category"]);
                                e.SectionChiefName = Convert.ToString(row["STF_SectionChiefName"]);
                                e.ProposalWeight = string.Format("{0:0.#}", pi.SubmittersCount > 0 ? (1.0 / (double)pi.SubmittersCount) : 0);
                                pi.Submitters.Add(e);
                                //e.WXUserList = WXUserInfoDAO.GetWXUserListByJobNumber(e.JobNumber);
                                pl.PageData.Add(pi);
                            }
                            else
                            {
                                ProposalView pv = new ProposalView();
                                pv.Number = Convert.ToString(row["PPS_Number"]);
                                //pv.JobNumber = Convert.ToString(row["PPS_Author_JobNumber"]);
                                pv.JobNumber = Convert.ToString(row["PPS_JobNumber"]);
                                pv.Author = Convert.ToString(row["EMP_FullName"]);
                                DateTime? dt = Convert.ToDateTime(row["PPS_Form_Date"]);
                                pv.FormDate = (dt.HasValue) ? dt.Value.ToString("yyyy-MM-dd HH:mm") : "";
                                dt = Convert.ToDateTime(row["PPS_Submit_Time"]);
                                pv.SubmitTime = (dt.HasValue) ? dt.Value.ToString("MM-dd HH:mm") : "";
                                pv.Status = Convert.ToString(row["PPS_Status"]);
                                pv.Category = Convert.ToString(row["PPS_Category"]);
                                pv.Title = Convert.ToString(row["PPS_Title"]);
                                pl.PageData.Add(pv);
                            }
                        }
                        data.Clear();
                    }
                    pl.Calulate();

                }
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("PaginationQueryForAdmin Error: eJobNumber={0}, eCompany={1}, eOrgan={2}, eDivision={3}, eDepart={4}, eGroup={5}, eCategory={6}, pNumber={7}, pCategory={8}, pStatus={9}, pAudit={10}, pDateBegin={11}, pDateEnd={12}, pageSize={13}, pageIndex={14}", fl.JobNumber, fl.Company, fl.Organ, fl.Division, fl.Depart, fl.Group, fl.EmpCategory, fl.Number, fl.Category, fl.Status, fl.Audit, fl.DateBegin, fl.DateEnd, pl.PageSize, pl.PageIndex), e);
            }
        }

        private static string GenProposalStatusWeightSumSql(string status, string dateBegin, string dateEnd)
        {
            return
                "SELECT " +
                "sa.pps_jobnumber,sum(sa.pps_weight) AS pps_count " +
                "FROM (" +
                "SELECT " +
                "ta.pps_jobnumber,ta.pps_number,tc.pps_weight " +
                "FROM ta_proposal AS tb,ta_submitter AS ta " +
                "LEFT JOIN (" +
                "SELECT " +
                "pa.pps_number,1/cast(COUNT(1) as float) AS pps_weight " +
                "FROM ta_submitter AS pa,ta_proposal AS pb " +
                "WHERE pa.pps_number=pb.pps_number AND pb.pps_status=N'" + status + "' " +
                (string.IsNullOrEmpty(dateBegin) ? "" : "AND pb.PPS_Form_Date>=CAST(@DateBegin AS SMALLDATETIME) ") +
                (string.IsNullOrEmpty(dateEnd) ? "" : "AND pb.PPS_Form_Date<=CAST(@DateEnd AS SMALLDATETIME) ") +
                "GROUP BY pa.pps_number" +
                ") AS tc ON tc.pps_number=ta.pps_number " +
                "WHERE ta.pps_number=tb.pps_number AND tb.pps_status=N'" + status + "' " +
                ") AS sa " +
                "GROUP BY sa.pps_jobnumber";
        }

        public static void PaginationQueryProposalEmpSummaryForAdmin(UserRole ur, ProposalFilter fl, PageList pl)
        {
            pl.PageData = new List<object>();
            if (pl.PageSize < 0 || pl.PageIndex <= 0) return;
            string strCountSelect = "SELECT COUNT(1) AS reccount ";
            string strOrderBy = "ORDER BY ep.pps_total DESC";
            string strSelect = "SELECT "
                + (pl.PageSize > 0 ? ("ROW_NUMBER() OVER(" + strOrderBy + ") AS NUMBER,") : "")
                + "ep.pps_jobnumber,e.emp_fullname,e.emp_company,e.emp_organ,e.emp_division,"
                + "e.emp_depart,e.emp_group,ISNULL(e.emp_category,'') AS emp_empcategory"
                + ",ISNULL(e.emp_mobile,'') AS emp_mobile,ep.pps_total"
                + ",ISNULL(c1.pps_count, 0) AS pps_receive_count"
                + ",ISNULL(c2.pps_count, 0) AS pps_audited_count"
                + ",ISNULL(c3.pps_count, 0) AS pps_accept_count"
                + ",ISNULL(c4.pps_count, 0) AS pps_reject_count"
                //+ ",ISNULL(c5.pps_count, 0) AS pps_bonus_count"
                + " ";
            string strFrom =
                "FROM ta_employee AS e,(SELECT ps.pps_jobnumber,COUNT(1) AS pps_total FROM ta_submitter AS ps " +
                ((string.IsNullOrEmpty(fl.DateBegin)&&string.IsNullOrEmpty(fl.DateEnd))?"":(
                ",ta_proposal AS pp " +
                "WHERE ps.pps_number=pp.pps_number " +
                (string.IsNullOrEmpty(fl.DateBegin) ? "" : "AND pp.PPS_Form_Date>=CAST(@DateBegin AS SMALLDATETIME) ") +
                (string.IsNullOrEmpty(fl.DateEnd) ? "" : "AND pp.PPS_Form_Date<=CAST(@DateEnd AS SMALLDATETIME) "))) +
                "GROUP BY pps_jobnumber) AS ep ";
            string strLeftJoin =
                "LEFT JOIN (" +
                GenProposalStatusWeightSumSql(ProposalStatus.Received, fl.DateBegin, fl.DateEnd) +
                ") AS c1 ON c1.pps_jobnumber=ep.pps_jobnumber " +
                "LEFT JOIN (" +
                GenProposalStatusWeightSumSql(ProposalStatus.Audited, fl.DateBegin, fl.DateEnd) +
                ") AS c2 ON c2.pps_jobnumber=ep.pps_jobnumber " +
                "LEFT JOIN (" +
                GenProposalStatusWeightSumSql(ProposalStatus.Accepted, fl.DateBegin, fl.DateEnd) +
                ") AS c3 ON c3.pps_jobnumber=ep.pps_jobnumber " +
                "LEFT JOIN (" +
                GenProposalStatusWeightSumSql(ProposalStatus.Reject, fl.DateBegin, fl.DateEnd) +
                ") AS c4 ON c4.pps_jobnumber=ep.pps_jobnumber ";
            string strWhere = 
                "WHERE e.emp_jobnumber=ep.pps_jobnumber " +
                (string.IsNullOrEmpty(fl.JobNumber)?"":"AND ep.pps_jobnumber=@JobNumber ") +
                (string.IsNullOrEmpty(fl.Company)?"":"AND e.emp_company=@Company ") +
                (string.IsNullOrEmpty(fl.Organ) ? "" : "AND e.emp_organ=@Organ ") +
                (string.IsNullOrEmpty(fl.Division) ? "" : "AND e.emp_division=@Division ") +
                (string.IsNullOrEmpty(fl.Depart) ? "" : "AND e.emp_depart=@Depart ") +
                (string.IsNullOrEmpty(fl.Group) ? "" : "AND e.emp_group=@Group ") +
                (string.IsNullOrEmpty(fl.EmpCategory) ? "" : "AND e.emp_category=@EmpCategory ");
            try
            {
                List<SqlParameter> list = new List<SqlParameter>();
                if (!string.IsNullOrEmpty(fl.JobNumber))
                    list.Add(SqlHelper.MakeInParam("@JobNumber", SqlDbType.VarChar, 8, fl.JobNumber));
                if (!string.IsNullOrEmpty(fl.Company))
                    list.Add(SqlHelper.MakeInParam("@Company", SqlDbType.NVarChar, 16, fl.Company));
                if (!string.IsNullOrEmpty(fl.Organ))
                    list.Add(SqlHelper.MakeInParam("@Organ", SqlDbType.NVarChar, 16, fl.Organ));
                if (!string.IsNullOrEmpty(fl.Division))
                    list.Add(SqlHelper.MakeInParam("@Division", SqlDbType.NVarChar, 16, fl.Division));
                if (!string.IsNullOrEmpty(fl.Depart))
                    list.Add(SqlHelper.MakeInParam("@Depart", SqlDbType.NVarChar, 16, fl.Depart));
                if (!string.IsNullOrEmpty(fl.Group))
                    list.Add(SqlHelper.MakeInParam("@Group", SqlDbType.NVarChar, 16, fl.Group));
                if (!string.IsNullOrEmpty(fl.EmpCategory))
                    list.Add(SqlHelper.MakeInParam("@EmpCategory", SqlDbType.NVarChar, 4, fl.EmpCategory));
                if (!string.IsNullOrEmpty(fl.DateBegin))
                    list.Add(SqlHelper.MakeInParam("@DateBegin", SqlDbType.VarChar, 23, fl.DateBegin + " 00:00"));
                if (!string.IsNullOrEmpty(fl.DateEnd))
                    list.Add(SqlHelper.MakeInParam("@DateEnd", SqlDbType.VarChar, 23, fl.DateEnd + " 23:59"));

                /** 根据事业部管理员所辖的事业部生成过滤条件  **/
                if (ur != null && ur.OrganOperators != null && ur.OrganOperators.Count > 0)
                {
                    strWhere += "AND (";
                    for (int i = 0; i < ur.OrganOperators.Count; i++)
                    {
                        CompanyOrganOperator coo = ur.OrganOperators[i];
                        if (i > 0) strWhere += " OR ";
                        strWhere += "(emp_Company=@Company" + i +
                            (string.IsNullOrEmpty(coo.Organ) ? "" : (" AND emp_Organ=@Organ" + i)) +
                            (string.IsNullOrEmpty(coo.Division) ? "" : (" AND emp_Division=@Division" + i)) +
                            (string.IsNullOrEmpty(coo.Depart) ? "" : (" AND emp_Depart=@Depart" + i)) +
                            (string.IsNullOrEmpty(coo.Group) ? "" : (" AND emp_Group=@Group" + i)) + ")";
                        list.Add(SqlHelper.MakeInParam("@Company" + i, SqlDbType.NVarChar, 16, coo.Company));
                        if (!string.IsNullOrEmpty(coo.Organ))
                            list.Add(SqlHelper.MakeInParam("@Organ" + i, SqlDbType.NVarChar, 16, coo.Organ));
                        if (!string.IsNullOrEmpty(coo.Division))
                            list.Add(SqlHelper.MakeInParam("@Division" + i, SqlDbType.NVarChar, 16, coo.Division));
                        if (!string.IsNullOrEmpty(coo.Depart))
                            list.Add(SqlHelper.MakeInParam("@Depart" + i, SqlDbType.NVarChar, 16, coo.Depart));
                        if (!string.IsNullOrEmpty(coo.Group))
                            list.Add(SqlHelper.MakeInParam("@Group" + i, SqlDbType.NVarChar, 16, coo.Group));
                    }
                    strWhere += ")";
                }
                /** **/

                DataSet data = null;
                if (pl.PageSize > 0)
                {
                    string strCountSQL = strCountSelect + strFrom + strWhere;
                    data = SqlHelper.ExecuteDataset(strCountSQL, list.ToArray());
                    pl.RowsCount = (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0) ? Convert.ToInt32(data.Tables[0].Rows[0][0]) : 0;
                }
                pl.PageData.Clear();
                if (pl.PageSize==0 || pl.RowsCount > 0)
                {
                    int start = (pl.PageIndex - 1) * pl.PageSize + 1;
                    int end = start + pl.PageSize - 1;
                    string strPagingSQL = 
                        (pl.PageSize>0?"SELECT * FROM (":"")+
                        strSelect+strFrom+strLeftJoin+strWhere+
                        (pl.PageSize > 0 ? (") AS t WHERE t.NUMBER BETWEEN " + start + " AND " + end) : strOrderBy);
                    data = SqlHelper.ExecuteDataset(strPagingSQL, list.ToArray());
                    if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow row in data.Tables[0].Rows)
                        {
                            ProposalSummary ps = new ProposalSummary();
                            ps.JobNumber = Convert.ToString(row["pps_jobnumber"]);
                            ps.FullName = Convert.ToString(row["emp_fullname"]);
                            ps.Mobile = Convert.ToString(row["emp_mobile"]);
                            ps.Company = Convert.ToString(row["emp_company"]);
                            ps.Organ = Convert.ToString(row["emp_organ"]);
                            ps.Division = Convert.ToString(row["emp_division"]);
                            ps.Depart = Convert.ToString(row["emp_depart"]);
                            ps.Group = Convert.ToString(row["emp_group"]);
                            ps.EmpCategory = Convert.ToString(row["emp_empcategory"]);
                            ps.Total = Convert.ToInt32(row["pps_total"]);
                            ps.ReceivedCount = Convert.ToDouble(row["pps_receive_count"]);
                            ps.AuditedCount = Convert.ToDouble(row["pps_audited_count"]);
                            ps.AcceptCount = Convert.ToDouble(row["pps_accept_count"]);
                            ps.RejectCount = Convert.ToDouble(row["pps_reject_count"]);
                            ps.SumTotal = ps.ReceivedCount + ps.AuditedCount + ps.AcceptCount + ps.RejectCount;
                            /*
                            ps.ReceivedCount = Convert.ToInt32(row["pps_receive_count"]);
                            ps.AuditedCount = Convert.ToInt32(row["pps_audited_count"]);
                            ps.AcceptCount = Convert.ToInt32(row["pps_accept_count"]);
                            ps.RejectCount = Convert.ToInt32(row["pps_reject_count"]);
                            */
                            //ps.BonusCount = Convert.ToInt32(row["pps_bonus_count"]);
                            pl.PageData.Add(ps);
                        }
                        data.Clear();
                    }
                }
                pl.Calulate();
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("PaginationQueryProposalEmpSummaryForAdmin Error : eJobNumber={0}, eCompany={1}, eOrgan={2}, eDivision={3}, eDepart={4}, eGroup={5}, eCategory={6}, pDateBegin={7}, pDateEnd={8}, pageSize={9}, pageIndex={10}", fl.JobNumber, fl.Company, fl.Organ, fl.Division, fl.Depart, fl.Group, fl.EmpCategory, fl.DateBegin, fl.DateEnd, pl.PageSize, pl.PageIndex), e);
            }
        }

        public static void FillProposalEmpSumNumsForAdmin(UserRole ur, ProposalFilter fl, PageList pl)
        {
            if (pl.PageData.Count == 0) return;

            string strOrderBy = "ORDER BY s.pps_jobnumber,p.pps_status DESC";
            string strSelect = "SELECT s.pps_jobnumber,s.pps_number,p.pps_status ";
            string strFrom = "FROM ta_submitter AS s,ta_proposal AS p,ta_employee AS e ";
            string strWhere =
                "WHERE s.pps_number=p.pps_number AND s.pps_jobnumber=e.emp_jobnumber " +
                (string.IsNullOrEmpty(fl.DateBegin) ? "" : "AND p.PPS_Form_Date>=CAST(@DateBegin AS SMALLDATETIME) ") +
                (string.IsNullOrEmpty(fl.DateEnd) ? "" : "AND p.PPS_Form_Date<=CAST(@DateEnd AS SMALLDATETIME) ") +
                (string.IsNullOrEmpty(fl.JobNumber) ? "" : "AND s.pps_jobnumber=@JobNumber ") +
                //(string.IsNullOrEmpty(fl.JobNumber) ? "" : "AND e.emp_jobnumber=@JobNumber ") +
                (string.IsNullOrEmpty(fl.Company) ? "" : "AND e.emp_company=@Company ") +
                (string.IsNullOrEmpty(fl.Organ) ? "" : "AND e.emp_organ=@Organ ") +
                (string.IsNullOrEmpty(fl.Division) ? "" : "AND e.emp_division=@Division ") +
                (string.IsNullOrEmpty(fl.Depart) ? "" : "AND e.emp_depart=@Depart ") +
                (string.IsNullOrEmpty(fl.Group) ? "" : "AND e.emp_group=@Group ") +
                (string.IsNullOrEmpty(fl.EmpCategory) ? "" : "AND e.emp_category=@EmpCategory ");
            try
            {
                List<SqlParameter> list = new List<SqlParameter>();
                if (!string.IsNullOrEmpty(fl.JobNumber))
                    list.Add(SqlHelper.MakeInParam("@JobNumber", SqlDbType.VarChar, 8, fl.JobNumber));
                if (!string.IsNullOrEmpty(fl.Company))
                    list.Add(SqlHelper.MakeInParam("@Company", SqlDbType.NVarChar, 16, fl.Company));
                if (!string.IsNullOrEmpty(fl.Organ))
                    list.Add(SqlHelper.MakeInParam("@Organ", SqlDbType.NVarChar, 16, fl.Organ));
                if (!string.IsNullOrEmpty(fl.Division))
                    list.Add(SqlHelper.MakeInParam("@Division", SqlDbType.NVarChar, 16, fl.Division));
                if (!string.IsNullOrEmpty(fl.Depart))
                    list.Add(SqlHelper.MakeInParam("@Depart", SqlDbType.NVarChar, 16, fl.Depart));
                if (!string.IsNullOrEmpty(fl.Group))
                    list.Add(SqlHelper.MakeInParam("@Group", SqlDbType.NVarChar, 16, fl.Group));
                if (!string.IsNullOrEmpty(fl.EmpCategory))
                    list.Add(SqlHelper.MakeInParam("@EmpCategory", SqlDbType.NVarChar, 4, fl.EmpCategory));
                if (!string.IsNullOrEmpty(fl.DateBegin))
                    list.Add(SqlHelper.MakeInParam("@DateBegin", SqlDbType.VarChar, 23, fl.DateBegin + " 00:00"));
                if (!string.IsNullOrEmpty(fl.DateEnd))
                    list.Add(SqlHelper.MakeInParam("@DateEnd", SqlDbType.VarChar, 23, fl.DateEnd + " 23:59"));

                /** 根据事业部管理员所辖的事业部生成过滤条件  **/
                if (ur != null && ur.OrganOperators != null && ur.OrganOperators.Count > 0)
                {
                    strWhere += "AND (";
                    for (int i = 0; i < ur.OrganOperators.Count; i++)
                    {
                        CompanyOrganOperator coo = ur.OrganOperators[i];
                        if (i > 0) strWhere += " OR ";
                        strWhere += "(emp_Company=@Company" + i +
                            (string.IsNullOrEmpty(coo.Organ) ? "" : (" AND emp_Organ=@Organ" + i)) +
                            (string.IsNullOrEmpty(coo.Division) ? "" : (" AND emp_Division=@Division" + i)) +
                            (string.IsNullOrEmpty(coo.Depart) ? "" : (" AND emp_Depart=@Depart" + i)) +
                            (string.IsNullOrEmpty(coo.Group) ? "" : (" AND emp_Group=@Group" + i)) + ")";
                        list.Add(SqlHelper.MakeInParam("@Company" + i, SqlDbType.NVarChar, 16, coo.Company));
                        if (!string.IsNullOrEmpty(coo.Organ))
                            list.Add(SqlHelper.MakeInParam("@Organ" + i, SqlDbType.NVarChar, 16, coo.Organ));
                        if (!string.IsNullOrEmpty(coo.Division))
                            list.Add(SqlHelper.MakeInParam("@Division" + i, SqlDbType.NVarChar, 16, coo.Division));
                        if (!string.IsNullOrEmpty(coo.Depart))
                            list.Add(SqlHelper.MakeInParam("@Depart" + i, SqlDbType.NVarChar, 16, coo.Depart));
                        if (!string.IsNullOrEmpty(coo.Group))
                            list.Add(SqlHelper.MakeInParam("@Group" + i, SqlDbType.NVarChar, 16, coo.Group));
                    }
                    strWhere += ")";
                }
                /** **/

                if (string.IsNullOrEmpty(fl.JobNumber) && pl.PageSize > 0 && pl.PageData.Count <= pl.PageSize)
                {
                    string strWhereIn = "";
                    for (int i = 0; i < pl.PageData.Count; i++)
                    {
                        if (pl.PageData[i] is ProposalSummary)
                        {
                            ProposalSummary ps = (ProposalSummary)(pl.PageData[i]);
                            strWhereIn += (string.IsNullOrEmpty(strWhereIn) ? "" : ",") + ("@JobNum" + i);
                            list.Add(SqlHelper.MakeInParam("@JobNum"+i, SqlDbType.VarChar, 8, ps.JobNumber));
                        }
                    }
                    if (!string.IsNullOrEmpty(strWhereIn)) strWhere += "AND s.pps_jobnumber IN (" + strWhereIn + ") ";
                }
                DataSet data = SqlHelper.ExecuteDataset(strSelect + strFrom + strWhere + strOrderBy, list.ToArray());
                if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                {
                    string key = null;
                    Dictionary<string, string> jnStPnMap = new Dictionary<string, string>();
                    foreach (DataRow row in data.Tables[0].Rows)
                    {
                        key = Convert.ToString(row["pps_jobnumber"]) + "_" + Convert.ToString(row["pps_status"]);
                        jnStPnMap[key] = (jnStPnMap.ContainsKey(key) ? (jnStPnMap[key] + ",") : "") + Convert.ToString(row["pps_number"]);
                    }
                    data.Clear();
                    for (int i = 0; i < pl.PageData.Count; i++)
                    {
                        if (pl.PageData[i] is ProposalSummary)
                        {
                            ProposalSummary ps = (ProposalSummary)(pl.PageData[i]);
                            key = ps.JobNumber + "_" + ProposalStatus.Received;
                            ps.ReceivedNums = jnStPnMap.ContainsKey(key)?jnStPnMap[key]:"";
                            key = ps.JobNumber + "_" + ProposalStatus.Audited;
                            ps.AuditedNums = jnStPnMap.ContainsKey(key) ? jnStPnMap[key] : "";
                            key = ps.JobNumber + "_" + ProposalStatus.Accepted;
                            ps.AcceptNums = jnStPnMap.ContainsKey(key) ? jnStPnMap[key] : "";
                            key = ps.JobNumber + "_" + ProposalStatus.Reject;
                            ps.RejectNums = jnStPnMap.ContainsKey(key) ? jnStPnMap[key] : "";
                        }
                    }
                }

            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("FillProposalEmpSumNumsForAdmin Error : eJobNumber={0}, eCompany={1}, eOrgan={2}, eDivision={3}, eDepart={4}, eGroup={5}, eCategory={6}, pDateBegin={7}, pDateEnd={8}, pageSize={9}, pageIndex={10}", fl.JobNumber, fl.Company, fl.Organ, fl.Division, fl.Depart, fl.Group, fl.EmpCategory, fl.DateBegin, fl.DateEnd, pl.PageSize, pl.PageIndex), e);
            }
        }

        /// <summary>
        /// 所有提案概要统计
        /// </summary>
        /// <returns></returns>
        public static Dictionary<string, string> Summary()
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            try
            {
                string strSQL =
                    "select count(1) as p_count_today from dbo.ta_proposal where CONVERT(VARCHAR(8),pps_submit_time,112)=CONVERT(VARCHAR(8),GETDATE(),112)" //今日提案
                    + ";select count(1) as p_count_total from dbo.ta_proposal;" //總提案數
                    + ";select count(1) as p_count_received from dbo.ta_proposal where pps_status=N'" + ProposalStatus.Received + "'" //審批中
                    + ";select count(1) as p_count_audited from dbo.ta_proposal where pps_status=N'" + ProposalStatus.Audited + "'" //已審批
                    + ";select count(1) as p_count_accept from dbo.ta_proposal where pps_status=N'" + ProposalStatus.Accepted + "'" //採用
                    + ";select count(1) as p_count_reject from dbo.ta_proposal where pps_status=N'" + ProposalStatus.Reject + "'" //不採用
                    //+ ";select count(1) as p_count_bonus from dbo.ta_proposal where pps_status=N'" + ProposalStatus.Bonus + "'"//獎金已發放
                    + ";";
                DataSet data = SqlHelper.ExecuteDataset(strSQL);
                if (data.Tables.Count > 0)
                {
                    if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0) dic.Add("p_count_today", Convert.ToString(data.Tables[0].Rows[0]["p_count_today"]));
                    if (data.Tables.Count > 1 && data.Tables[1].Rows.Count > 0) dic.Add("p_count_total", Convert.ToString(data.Tables[1].Rows[0]["p_count_total"]));
                    if (data.Tables.Count > 2 && data.Tables[2].Rows.Count > 0) dic.Add("p_count_received", Convert.ToString(data.Tables[2].Rows[0]["p_count_received"]));
                    if (data.Tables.Count > 3 && data.Tables[3].Rows.Count > 0) dic.Add("p_count_audited", Convert.ToString(data.Tables[3].Rows[0]["p_count_audited"]));
                    if (data.Tables.Count > 4 && data.Tables[4].Rows.Count > 0) dic.Add("p_count_accept", Convert.ToString(data.Tables[4].Rows[0]["p_count_accept"]));
                    if (data.Tables.Count > 5 && data.Tables[5].Rows.Count > 0) dic.Add("p_count_reject", Convert.ToString(data.Tables[5].Rows[0]["p_count_reject"]));
                    //if (data.Tables.Count > 6 && data.Tables[6].Rows.Count > 0) dic.Add("p_count_bonus", Convert.ToString(data.Tables[6].Rows[0]["p_count_bonus"]));
                    data.Clear();
                }
            }
            catch (Exception e)
            {
                WriteLog.Error("Proposal Admin Summary error:", e);
            }
            return dic;
        }

        /// <summary>
        /// 事业部提案管理员提案概要统计
        /// </summary>
        /// <param name="organList"></param>
        /// <returns></returns>
        public static Dictionary<string, string> Summary(List<CompanyOrganOperator> organList)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            int organCount = organList != null ? organList.Count : 0;
            dic.Add("organ_count", organCount.ToString());
            for (int i = 0; i < organCount; i++)
            {
                string organFilter
                    = "left join ta_employee as e on e.emp_jobnumber=p.pps_author_jobnumber "
                    + "where e.emp_company=@Company" + i;

                organFilter +=
                    (string.IsNullOrEmpty(organList[i].Organ) ? "" : (" AND e.emp_Organ=@Organ" + i)) +
                    (string.IsNullOrEmpty(organList[i].Division) ? "" : (" AND e.emp_Division=@Division" + i)) +
                    (string.IsNullOrEmpty(organList[i].Depart) ? "" : (" AND e.emp_Depart=@Depart" + i)) +
                    (string.IsNullOrEmpty(organList[i].Group) ? "" : (" AND e.emp_Group=@Group" + i));
                List<SqlParameter> list = new List<SqlParameter>();
                list.Add(SqlHelper.MakeInParam("@Company" + i, SqlDbType.NVarChar, 16, organList[i].Company));
                if (!string.IsNullOrEmpty(organList[i].Organ))
                    list.Add(SqlHelper.MakeInParam("@Organ" + i, SqlDbType.NVarChar, 16, organList[i].Organ));
                if (!string.IsNullOrEmpty(organList[i].Division))
                    list.Add(SqlHelper.MakeInParam("@Division" + i, SqlDbType.NVarChar, 16, organList[i].Division));
                if (!string.IsNullOrEmpty(organList[i].Depart))
                    list.Add(SqlHelper.MakeInParam("@Depart" + i, SqlDbType.NVarChar, 16, organList[i].Depart));
                if (!string.IsNullOrEmpty(organList[i].Group))
                    list.Add(SqlHelper.MakeInParam("@Group" + i, SqlDbType.NVarChar, 16, organList[i].Group));

                //string departFilter = (string.IsNullOrEmpty(organList[i].Depart)) ? "" : " and e.emp_depart like @Depart";
                //List<SqlParameter> qParams = new List<SqlParameter>();
                //qParams.Add(SqlHelper.MakeInParam("@Company", SqlDbType.NVarChar, 16, organList[i].Company));
                //qParams.Add(SqlHelper.MakeInParam("@Organ", SqlDbType.NVarChar, 16, organList[i].Organ));
                //if (!string.IsNullOrEmpty(departFilter))
                //qParams.Add(SqlHelper.MakeInParam("@Depart", SqlDbType.NVarChar, 16, organList[i].Depart + "%"));
                dic.Add("p_sum_company_" + i, organList[i].Company);
                dic.Add("p_sum_organ_" + i, organList[i].Organ + 
                    (string.IsNullOrEmpty(organList[i].Division) ? "" : " . " + organList[i].Division) +
                    (string.IsNullOrEmpty(organList[i].Depart) ? "" : " . " + organList[i].Depart) +
                    (string.IsNullOrEmpty(organList[i].Group) ? "" : " . " + organList[i].Group));
                try
                {
                    string strSQL =
                        "select count(1) as p_count_today from dbo.ta_proposal as p " + organFilter + " AND CONVERT(VARCHAR(8),p.pps_submit_time,112)=CONVERT(VARCHAR(8),GETDATE(),112)" //今日提案
                        + ";select count(1) as p_count_total from dbo.ta_proposal as p " + organFilter + ";" //總提案數
                        + ";select count(1) as p_count_received from dbo.ta_proposal as p " + organFilter + " AND pps_status=N'" + ProposalStatus.Received + "'" //審批中
                        + ";select count(1) as p_count_audited from dbo.ta_proposal as p " + organFilter + " AND pps_status=N'" + ProposalStatus.Audited + "'" //已審批
                        + ";select count(1) as p_count_accept from dbo.ta_proposal as p " + organFilter + " AND pps_status=N'" + ProposalStatus.Accepted + "'" //採用
                        + ";select count(1) as p_count_reject from dbo.ta_proposal as p " + organFilter + " AND pps_status=N'" + ProposalStatus.Reject + "'" //不採用
                        //+ ";select count(1) as p_count_bonus from dbo.ta_proposal where pps_status=N'" + ProposalStatus.Bonus + "'"//獎金已發放
                        + ";";
                    DataSet data = SqlHelper.ExecuteDataset(strSQL, list.ToArray());
                    if (data.Tables.Count > 0)
                    {
                        if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0) dic.Add("p_count_today_" + i, Convert.ToString(data.Tables[0].Rows[0]["p_count_today"]));
                        if (data.Tables.Count > 1 && data.Tables[1].Rows.Count > 0) dic.Add("p_count_total_" + i, Convert.ToString(data.Tables[1].Rows[0]["p_count_total"]));
                        if (data.Tables.Count > 2 && data.Tables[2].Rows.Count > 0) dic.Add("p_count_received_" + i, Convert.ToString(data.Tables[2].Rows[0]["p_count_received"]));
                        if (data.Tables.Count > 3 && data.Tables[3].Rows.Count > 0) dic.Add("p_count_audited_" + i, Convert.ToString(data.Tables[3].Rows[0]["p_count_audited"]));
                        if (data.Tables.Count > 4 && data.Tables[4].Rows.Count > 0) dic.Add("p_count_accept_" + i, Convert.ToString(data.Tables[4].Rows[0]["p_count_accept"]));
                        if (data.Tables.Count > 5 && data.Tables[5].Rows.Count > 0) dic.Add("p_count_reject_" + i, Convert.ToString(data.Tables[5].Rows[0]["p_count_reject"]));
                        data.Clear();
                    }
                }
                catch (Exception e)
                {
                    WriteLog.Error("Proposal OrganAdmin Summary error:", e);
                }
            }
            return dic;
        }

        /// <summary>
        /// 个人提案概要统计
        /// </summary>
        /// <param name="jobNumber"></param>
        /// <returns></returns>
        public static Dictionary<string, string> UserSummary(string jobNumber)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            string empFilter
                = "left join ta_employee as e on e.emp_jobnumber=p.pps_author_jobnumber "
                + "where e.EMP_JobNumber=@JobNum";
            List<SqlParameter> qParams = new List<SqlParameter>();
            qParams.Add(SqlHelper.MakeInParam("@JobNum", SqlDbType.VarChar, 16, jobNumber));
            try
            {
                string strSQL =
                    "select count(1) as p_count_today from dbo.ta_proposal as p " + empFilter + " AND CONVERT(VARCHAR(8),p.pps_submit_time,112)=CONVERT(VARCHAR(8),GETDATE(),112)" //今日提案
                    + ";select count(1) as p_count_total from dbo.ta_proposal as p " + empFilter + ";" //總提案數
                    + ";select count(1) as p_count_received from dbo.ta_proposal as p " + empFilter + " AND pps_status=N'" + ProposalStatus.Received + "'" //審批中
                    + ";select count(1) as p_count_audited from dbo.ta_proposal as p " + empFilter + " AND pps_status=N'" + ProposalStatus.Audited + "'" //已審批
                    + ";select count(1) as p_count_accept from dbo.ta_proposal as p " + empFilter + " AND pps_status=N'" + ProposalStatus.Accepted + "'" //採用
                    + ";select count(1) as p_count_reject from dbo.ta_proposal as p " + empFilter + " AND pps_status=N'" + ProposalStatus.Reject + "'" //不採用
                    + ";";
                DataSet data = SqlHelper.ExecuteDataset(strSQL, qParams.ToArray());
                if (data.Tables.Count > 0)
                {
                    if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0) dic.Add("p_count_today", Convert.ToString(data.Tables[0].Rows[0]["p_count_today"]));
                    if (data.Tables.Count > 1 && data.Tables[1].Rows.Count > 0) dic.Add("p_count_total", Convert.ToString(data.Tables[1].Rows[0]["p_count_total"]));
                    if (data.Tables.Count > 2 && data.Tables[2].Rows.Count > 0) dic.Add("p_count_received", Convert.ToString(data.Tables[2].Rows[0]["p_count_received"]));
                    if (data.Tables.Count > 3 && data.Tables[3].Rows.Count > 0) dic.Add("p_count_audited", Convert.ToString(data.Tables[3].Rows[0]["p_count_audited"]));
                    if (data.Tables.Count > 4 && data.Tables[4].Rows.Count > 0) dic.Add("p_count_accept", Convert.ToString(data.Tables[4].Rows[0]["p_count_accept"]));
                    if (data.Tables.Count > 5 && data.Tables[5].Rows.Count > 0) dic.Add("p_count_reject", Convert.ToString(data.Tables[5].Rows[0]["p_count_reject"]));
                    data.Clear();
                }
            }
            catch (Exception e)
            {
                WriteLog.Error("Proposal UserSummary error:", e);
            }
            return dic;
        }

    }
}
