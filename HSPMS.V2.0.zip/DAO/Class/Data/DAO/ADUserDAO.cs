﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using LEO.Project.Tools;
using LEO.Project.WXProposal.Data.Entity;

namespace LEO.Project.WXProposal.Data.DAO
{
    public class ADUserDAO
    {
        private static ADUserDAO _instance;
        public static ADUserDAO instance
        {
            get
            {
                if (_instance == null) _instance = new ADUserDAO();
                return _instance;
            }
        }

        public int InsertADUser(ADUser adu)
        {
            SqlConnection con = SqlHelper.GetConnection();
            if (con == null) return -2;
            SqlTransaction trans = SqlHelper.BeginTransaction(con);
            int result = -1;
            if (trans != null)
            {
                string strInsertSQL = "INSERT INTO dbo.TA_AD_Account("
                    + "AD_GUID,AD_JobNumber,AD_AccountName,AD_CNName,AD_Tel,AD_Department,AD_Branch,AD_JobTitle,AD_Status,AD_LastUpdate"
                    + ") VALUES (@GUID,@JobNumber,@AccountName,@CNName,@Tel,@Department,@Branch,@JobTitle,@Status,@LastUpdate)";
                adu.Status = 1;
                adu.LastUpdate = DateTime.Now;
                List<SqlParameter> list = new List<SqlParameter>();
                list.Add(SqlHelper.MakeInParam("@GUID", SqlDbType.Binary, 16, adu.Guid));
                list.Add(SqlHelper.MakeInParam("@JobNumber", SqlDbType.VarChar, 8, adu.JobNumber));
                list.Add(SqlHelper.MakeInParam("@AccountName", SqlDbType.NVarChar, 32, adu.AccountName));
                list.Add(SqlHelper.MakeInParam("@CNName", SqlDbType.NVarChar, 32, adu.CNName));
                list.Add(SqlHelper.MakeInParam("@Tel", SqlDbType.NVarChar, 32, adu.Tel));
                list.Add(SqlHelper.MakeInParam("@Department", SqlDbType.NVarChar, 32, adu.Department));
                list.Add(SqlHelper.MakeInParam("@Branch", SqlDbType.NVarChar, 32, adu.Branch));
                list.Add(SqlHelper.MakeInParam("@JobTitle", SqlDbType.NVarChar, 16, adu.JobTitle));
                list.Add(SqlHelper.MakeInParam("@Status", SqlDbType.TinyInt, 0, adu.Status));
                list.Add(SqlHelper.MakeInParam("@LastUpdate", SqlDbType.DateTime, 0, adu.LastUpdate));
                int rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strInsertSQL, list.ToArray()));
                if (rowsAffected > 0) result = 1;
                if (result > 0) SqlHelper.CommitTransaction(trans);
                else SqlHelper.RollbackTransaction(trans);
            }
            SqlHelper.ReleaseConnection(con);

            return result;
        }

        public ADUser GetADUserByJobNumber(string jobNumber)
        {
            if (string.IsNullOrEmpty(jobNumber)) return null;
            try
            {
                string strSQL = "SELECT TOP 1 * FROM dbo.TA_AD_Account WHERE AD_JobNumber=@JobNumber";
                List<SqlParameter> list = new List<SqlParameter>();
                list.Add(SqlHelper.MakeInParam("@JobNumber", SqlDbType.VarChar, 8, jobNumber));
                DataSet data = SqlHelper.ExecuteDataset(strSQL, list.ToArray());
                if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                {
                    DataRow row = data.Tables[0].Rows[0];
                    ADUser adu = new ADUser();
                    adu.Guid = (byte[])row["AD_GUID"];
                    adu.JobNumber = Convert.ToString(row["AD_JobNumber"]);
                    adu.AccountName = Convert.ToString(row["AD_AccountName"]);
                    adu.CNName = Convert.ToString(row["AD_CNName"]);
                    adu.Tel = Convert.ToString(row["AD_Tel"]);
                    adu.Department = Convert.ToString(row["AD_Department"]);
                    adu.Branch = Convert.ToString(row["AD_Branch"]);
                    adu.JobTitle = Convert.ToString(row["AD_JobTitle"]);
                    adu.Status = Convert.ToByte(row["AD_Status"]);
                    adu.LastUpdate = row["AD_LastUpdate"] != null ? Convert.ToDateTime(row["AD_LastUpdate"]) : ((DateTime?)null);
                    data.Clear();
                    return adu;
                }
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("GetADUserByJobNumber error: job number={0}", jobNumber), e);
            }
            return null;
        }

        public ADUser GetADUserByNTAccount(string account)
        {
            if (string.IsNullOrEmpty(account)) return null;
            try
            {
                /*
                string strSQL = "SELECT TOP 1 * FROM dbo.TA_AD_Account WHERE AD_AccountName=@AccountName";
                List<SqlParameter> list = new List<SqlParameter>();
                list.Add(SqlHelper.MakeInParam("@AccountName", SqlDbType.NVarChar, 32, account));
                DataSet data = SqlHelper.ExecuteDataset(strSQL, list.ToArray());
                */
                DataSet data = SqlHelper.ExecuteDataset("SELECT TOP 1 * FROM dbo.TA_AD_Account WHERE AD_AccountName='" + account + "'");
                if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                {
                    DataRow row = data.Tables[0].Rows[0];
                    ADUser adu = new ADUser();
                    if (!Convert.IsDBNull(row["AD_GUID"])) adu.Guid = (byte[])row["AD_GUID"];
                    adu.JobNumber = Convert.ToString(row["AD_JobNumber"]);
                    adu.AccountName = Convert.ToString(row["AD_AccountName"]);
                    adu.CNName = Convert.ToString(row["AD_CNName"]);
                    adu.Tel = Convert.ToString(row["AD_Tel"]);
                    adu.Department = Convert.ToString(row["AD_Department"]);
                    adu.Branch = Convert.ToString(row["AD_Branch"]);
                    adu.JobTitle = Convert.ToString(row["AD_JobTitle"]);
                    adu.Status = Convert.ToByte(row["AD_Status"]);
                    adu.LastUpdate = row["AD_LastUpdate"] != null ? Convert.ToDateTime(row["AD_LastUpdate"]) : ((DateTime?)null);
                    data.Clear();
                    return adu;
                }
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("GetADUserByNTAccount error: account={0}", account), e);
            }
            return null;
        }

        public int UpdateADUserList(List<ADUser> adUserList)
        {
            SqlConnection con = SqlHelper.GetConnection();
            if (con == null) return -2;
            SqlTransaction trans = SqlHelper.BeginTransaction(con);
            int result = -1;
            if (trans != null)
            {
                string strSQL = "UPDATE dbo.TA_AD_Account set AD_Status=0"; //0=无效
                int rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strSQL));
                if (rowsAffected >= 0)
                {
                    string strUpdateSQL = "UPDATE dbo.TA_AD_Account set "
                        + "AD_GUID=@GUID,AD_JobNumber=@JobNumber,AD_CNName=@CNName,AD_Tel=@Tel,AD_Department=@Department,"
                        + "AD_Branch=@Branch,AD_JobTitle=@JobTitle,AD_Status=@Status,AD_LastUpdate=@LastUpdate "
                        + "WHERE AD_AccountName=@AccountName";
                    string strInsertSQL = "INSERT INTO dbo.TA_AD_Account("
                        + "AD_GUID,AD_JobNumber,AD_AccountName,AD_CNName,AD_Tel,AD_Department,AD_Branch,AD_JobTitle,AD_Status,AD_LastUpdate"
                        + ") VALUES (@GUID,@JobNumber,@AccountName,@CNName,@Tel,@Department,@Branch,@JobTitle,@Status,@LastUpdate)";
                    int updateCount = 0;
                    foreach (ADUser adu in adUserList)
                    {
                        adu.Status = 1;
                        adu.LastUpdate = DateTime.Now;
                        List<SqlParameter> list = new List<SqlParameter>();
                        list.Add(SqlHelper.MakeInParam("@GUID", SqlDbType.Binary, 16, adu.Guid));
                        list.Add(SqlHelper.MakeInParam("@JobNumber", SqlDbType.VarChar, 8, adu.JobNumber));
                        list.Add(SqlHelper.MakeInParam("@AccountName", SqlDbType.NVarChar, 32, adu.AccountName));
                        list.Add(SqlHelper.MakeInParam("@CNName", SqlDbType.NVarChar, 32, adu.CNName));
                        list.Add(SqlHelper.MakeInParam("@Tel", SqlDbType.NVarChar, 32, adu.Tel));
                        list.Add(SqlHelper.MakeInParam("@Department", SqlDbType.NVarChar, 32, adu.Department));
                        list.Add(SqlHelper.MakeInParam("@Branch", SqlDbType.NVarChar, 32, adu.Branch));
                        list.Add(SqlHelper.MakeInParam("@JobTitle", SqlDbType.NVarChar, 16, adu.JobTitle));
                        list.Add(SqlHelper.MakeInParam("@Status", SqlDbType.TinyInt, 0, adu.Status));
                        list.Add(SqlHelper.MakeInParam("@LastUpdate", SqlDbType.DateTime, 0, adu.LastUpdate));
                        rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strUpdateSQL, list.ToArray()));
                        if (rowsAffected == 0)
                        {
                            rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strInsertSQL, list.ToArray()));
                        }
                        if (rowsAffected <= 0) break;
                        else updateCount += rowsAffected;
                    }
                    if (rowsAffected > 0) result = updateCount;
                }
                if (result > 0) SqlHelper.CommitTransaction(trans);
                else SqlHelper.RollbackTransaction(trans);
            }
            SqlHelper.ReleaseConnection(con);

            return result;
        }

    }
}
