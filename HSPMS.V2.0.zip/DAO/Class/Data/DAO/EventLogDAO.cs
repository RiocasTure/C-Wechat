﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LEO.Project.WXProposal.Data.Entity;
using System.Data.SqlClient;
using System.Data;
using LEO.Project.Tools;

namespace LEO.Project.WXProposal.Data.DAO
{
    public class EventLogDAO
    {
        public static int InsertEventLog(EventLog log)
        {
            try
            {
                SqlConnection con = SqlHelper.GetConnection();
                if (con == null) return -2;
                SqlTransaction trans = SqlHelper.BeginTransaction(con);
                if (trans != null)
                {
                    string strInsertSQL = "INSERT INTO dbo.TA_Event_Log("
                        + "LOG_JobNumber,LOG_AccountName,LOG_Timestamp,LOG_Type,LOG_Operation,LOG_Related_Key,LOG_IP"
                        + ") VALUES (@JobNumber,@AccountName,@Timestamp,@Type,@Operation,@Related_Key,@IP);"
                        + "SELECT SCOPE_IDENTITY() AS log_id;";
                    log.Timestamp = DateTime.Now;
                    List<SqlParameter> list = new List<SqlParameter>();
                    list.Add(SqlHelper.MakeInParam("@JobNumber", SqlDbType.VarChar, 16, log.JobNumber));
                    list.Add(SqlHelper.MakeInParam("@AccountName", SqlDbType.NVarChar, 32, log.AccountName));
                    list.Add(SqlHelper.MakeInParam("@Timestamp", SqlDbType.DateTime, 0, log.Timestamp));
                    list.Add(SqlHelper.MakeInParam("@Type", SqlDbType.VarChar, 16, log.Type));
                    list.Add(SqlHelper.MakeInParam("@Operation", SqlDbType.VarChar, 16, log.Operation));
                    list.Add(SqlHelper.MakeInParam("@Related_Key", SqlDbType.VarChar, 32, log.RelatedKey));
                    list.Add(SqlHelper.MakeInParam("@IP", SqlDbType.VarChar, 16, log.IP));
                    object logId = SqlHelper.ExecuteScalar(trans, strInsertSQL, list.ToArray());
                    log.Id = Convert.ToInt32(logId);
                    if (log.Id > 0) SqlHelper.CommitTransaction(trans);
                    else SqlHelper.RollbackTransaction(trans);
                }
                SqlHelper.ReleaseConnection(con);
            }
            catch (Exception ex)
            {
                WriteLog.Error(string.Format("InsertEventLog error: EventLog={0}", JsonUtil<EventLog>.JsonSerializerObject(log)), ex);
            }
            return log.Id>0?1:0;
        }
        public static int BatchInsertEventLogs(List<EventLog> loglst)
        {
            int updateCount = 0;
            try
            {
                SqlConnection con = SqlHelper.GetConnection();
                if (con == null) return -2;
                SqlTransaction trans = SqlHelper.BeginTransaction(con);
                if (trans != null)
                {
                    string strInsertSQL = "INSERT INTO dbo.TA_Event_Log("
                        + "LOG_JobNumber,LOG_AccountName,LOG_Timestamp,LOG_Type,LOG_Operation,LOG_Related_Key"
                        + ") VALUES (@JobNumber,@AccountName,@Timestamp,@Type,@Operation,@Related_Key,@IP)";
                    int rowsAffected = 0;
                    foreach (EventLog log in loglst)
                    {
                        log.Timestamp = DateTime.Now;
                        List<SqlParameter> list = new List<SqlParameter>();
                        list.Add(SqlHelper.MakeInParam("@JobNumber", SqlDbType.VarChar, 16, log.JobNumber));
                        list.Add(SqlHelper.MakeInParam("@AccountName", SqlDbType.NVarChar, 32, log.AccountName));
                        list.Add(SqlHelper.MakeInParam("@Timestamp", SqlDbType.DateTime, 0, log.Timestamp));
                        list.Add(SqlHelper.MakeInParam("@Type", SqlDbType.VarChar, 16, log.Type));
                        list.Add(SqlHelper.MakeInParam("@Operation", SqlDbType.VarChar, 16, log.Operation));
                        list.Add(SqlHelper.MakeInParam("@Related_Key", SqlDbType.VarChar, 32, log.RelatedKey));
                        list.Add(SqlHelper.MakeInParam("@IP", SqlDbType.VarChar, 16, log.IP));
                        rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strInsertSQL, list.ToArray()));
                        if (rowsAffected <= 0) break;
                        else updateCount += rowsAffected;
                    }
                    if (rowsAffected > 0) SqlHelper.CommitTransaction(trans);
                    else SqlHelper.RollbackTransaction(trans);
                }
                SqlHelper.ReleaseConnection(con);
            }
            catch (Exception ex)
            {
                WriteLog.Error(string.Format("BatchInsertEventLogs error: EventLog Count={0}", loglst == null ? "null" : (loglst.Count+"")), ex);
            }
            return updateCount;
        }
    }
}
