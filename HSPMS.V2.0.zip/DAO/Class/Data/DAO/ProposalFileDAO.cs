﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LEO.Project.WXProposal.Data.Entity;
using LEO.Project.Tools;
using System.Data;
using LEO.Project.WXProposal.Data.DAO;
using System.Data.SqlClient;

namespace LEO.Project.WXProposal.Data.DAO
{
    public class ProposalFileDAO
    {
        public static AttachmentInfo GetByFilePath(string filePath)
        {
            if (string.IsNullOrEmpty(filePath)) return null;
            try
            {
                string strSQL = "SELECT TOP 1 * FROM dbo.TA_Proposal_File WHERE PPF_FilePath=@FilePath";
                List<SqlParameter> list = new List<SqlParameter>();
                list.Add(SqlHelper.MakeInParam("@FilePath", SqlDbType.NVarChar, 64, filePath));
                DataSet data = SqlHelper.ExecuteDataset(strSQL, list.ToArray());
                if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                {
                    DataRow row = data.Tables[0].Rows[0];
                    AttachmentInfo fi = new AttachmentInfo();
                    fi.RelatedKey = Convert.ToString(row["PPF_Number"]);
                    fi.FilePath = Convert.ToString(row["PPF_FilePath"]);
                    fi.FileName = Convert.ToString(row["PPF_FileName"]);
                    fi.FileDate = Convert.ToDateTime(row["PPF_FileDate"]);
                    data.Clear();
                    return fi;
                }
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("GetByFilePath error: filePath={0}", filePath), e);
            }
            return null;
        }

        public static List<AttachmentInfo> GetTodayProposalAttachListByJobNumber(string JobNumber)
        {
            if (string.IsNullOrEmpty(JobNumber)) return null;
            List<AttachmentInfo> attlst = new List<AttachmentInfo>();
            try
            {
                string strSQL = 
                    "SELECT a.* FROM ta_proposal_file AS a,ta_proposal AS b " +
                    "WHERE a.ppf_number=b.pps_number " +
                    "AND b.pps_author_jobnumber=@JobNumber " +
                    "AND DATEDIFF(day,b.pps_submit_time,GETDATE())=0";
                List<SqlParameter> list = new List<SqlParameter>();
                list.Add(SqlHelper.MakeInParam("@JobNumber", SqlDbType.VarChar, 16, JobNumber));
                DataSet data = SqlHelper.ExecuteDataset(strSQL, list.ToArray());
                if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in data.Tables[0].Rows)
                    {
                        AttachmentInfo att = new AttachmentInfo();
                        att.RelatedKey = Convert.ToString(row["PPF_Number"]);
                        att.FilePath = Convert.ToString(row["PPF_FilePath"]);
                        att.FileName = Convert.ToString(row["PPF_FileName"]);
                        att.FileDate = Convert.ToDateTime(row["PPF_FileDate"]);
                        attlst.Add(att);
                    }
                    data.Clear();
                }
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("Get GetTodayProposalAttachListByJobNumber error: JobNumber={0}", JobNumber), e);
            }
            return attlst;
        }


        public static List<AttachmentInfo> GetListByProposalNumber(string number)
        {
            if (string.IsNullOrEmpty(number)) return null;
            try
            {
                string strSQL = "SELECT * FROM dbo.TA_Proposal_File WHERE PPF_Number=@Number";
                List<SqlParameter> list = new List<SqlParameter>();
                list.Add(SqlHelper.MakeInParam("@Number", SqlDbType.VarChar, 16, number));
                DataSet data = SqlHelper.ExecuteDataset(strSQL, list.ToArray());
                if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                {
                    List<AttachmentInfo> attlst = new List<AttachmentInfo>();
                    foreach (DataRow row in data.Tables[0].Rows)
                    {
                        AttachmentInfo fi = new AttachmentInfo();
                        fi.RelatedKey = number;
                        fi.FilePath = Convert.ToString(row["PPF_FilePath"]);
                        fi.FileName = Convert.ToString(row["PPF_FileName"]);
                        fi.FileDate = Convert.ToDateTime(row["PPF_FileDate"]);
                        attlst.Add(fi);
                    }
                    data.Clear();
                    return attlst;
                }
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("GetListByProposalNumber error: number={0}", number), e);
            }
            return null;
        }

        public static int Insert(AttachmentInfo att)
        {
            if (att == null) return 0;
            SqlConnection con = null;
            SqlTransaction trans = null;
            int rowsAffected = 0;
            try
            {
                con = SqlHelper.GetConnection();
                if (con == null) return -2;
                trans = SqlHelper.BeginTransaction(con);
                if (trans != null)
                {
                    string strInsertSQL = "INSERT INTO dbo.TA_Proposal_File(PPF_Number,PPF_FilePath,PPF_FileName,PPF_FileDate" +
                        ") VALUES (@Number,@FilePath,@FileName,@FileDate)";
                    List<SqlParameter> list = new List<SqlParameter>();
                    list.Add(SqlHelper.MakeInParam("@Number", SqlDbType.VarChar, 16, att.RelatedKey));
                    list.Add(SqlHelper.MakeInParam("@FilePath", SqlDbType.NVarChar, 64, att.FilePath));
                    list.Add(SqlHelper.MakeInParam("@FileName", SqlDbType.NVarChar, 64, att.FileName));
                    list.Add(SqlHelper.MakeInParam("@FileDate", SqlDbType.DateTime, 0, att.FileDate));
                    rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strInsertSQL, list.ToArray()));
                }
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("Insert AttachmentInfo error: att={0}", JsonUtil<AttachmentInfo>.JsonSerializerObject(att)), e);
                rowsAffected = -1;
            }
            finally
            {
                try
                {
                    if (trans != null)
                    {
                        if (rowsAffected > 0) SqlHelper.CommitTransaction(trans);
                        else SqlHelper.RollbackTransaction(trans);
                    }
                    if (con != null) SqlHelper.ReleaseConnection(con);
                }
                catch (Exception ex)
                {
                    WriteLog.Error("Error while release connection.", ex);
                }
            }
            return rowsAffected;
        }

        public static int TransDeleteByRelatedKey(string relatedKey, SqlTransaction trans)
        {
            if (string.IsNullOrEmpty(relatedKey) || trans == null) return 0;
            try
            {
                //string strUpdateSQL = "DELETE FROM dbo.TA_Proposal_File WHERE PPF_Number=@Number";
                string strUpdateSQL = "UPDATE dbo.TA_Proposal_File SET PPF_Number=NULL WHERE PPF_Number=@Number";
                List<SqlParameter> list = new List<SqlParameter>();
                list.Add(SqlHelper.MakeInParam("@Number", SqlDbType.VarChar, 16, relatedKey));
                return Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strUpdateSQL, list.ToArray()));
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("TransDeleteByRelatedKey error: relatedKey={0}", relatedKey), e);
                return -1;
            }
        }

        public static int TransSave(AttachmentInfo att, SqlTransaction trans)
        {
            if (att == null || trans == null) return 0;
            try
            {
                List<SqlParameter> list = new List<SqlParameter>();
                list.Add(SqlHelper.MakeInParam("@Number", SqlDbType.VarChar, 16, att.RelatedKey));
                list.Add(SqlHelper.MakeInParam("@FilePath", SqlDbType.NVarChar, 64, att.FilePath));
                list.Add(SqlHelper.MakeInParam("@FileName", SqlDbType.NVarChar, 64, att.FileName));
                string strUpdateSQL = "UPDATE dbo.TA_Proposal_File SET PPF_Number=@Number,PPF_FileName=@FileName WHERE PPF_FilePath=@FilePath";
                int updateCount = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strUpdateSQL, list.ToArray()));
                if (updateCount == 0)
                {
                    list.Add(SqlHelper.MakeInParam("@FileDate", SqlDbType.DateTime, 0, att.FileDate));
                    string strInsertSQL = "INSERT INTO dbo.TA_Proposal_File(PPF_Number,PPF_FilePath,PPF_FileName,PPF_FileDate" +
                        ") VALUES (@Number,@FilePath,@FileName,@FileDate)";
                    updateCount = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strInsertSQL, list.ToArray()));
                }
                return updateCount;
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("TransInsert AttachmentInfo error: att={0}", JsonUtil<AttachmentInfo>.JsonSerializerObject(att)), e);
                return -1;
            }
        }

    }
}
