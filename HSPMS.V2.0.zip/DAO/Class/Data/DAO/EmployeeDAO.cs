﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using JsonView;
using LEO.Project.WXProposal.Data.Entity;
using LEO.Project.WXProposal.Model.QueryFilter;
using LEO.Project.WXProposal.Model.Pagination;
using LEO.Project.Tools;

namespace LEO.Project.WXProposal.Data.DAO
{
    public class EmployeeDAO
    {

        public static Employee GetEmployeeByJobNumber(string jobNumber)
        {
            if (string.IsNullOrEmpty(jobNumber)) return null;
            try
            {
                string strSQL = "SELECT TOP 1 * FROM dbo.TA_Employee WHERE EMP_JobNumber=@JobNumber";
                List<SqlParameter> list = new List<SqlParameter>();
                list.Add(SqlHelper.MakeInParam("@JobNumber", SqlDbType.VarChar, 8, jobNumber));
                DataSet data = SqlHelper.ExecuteDataset(strSQL, list.ToArray());
                if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                {
                    DataRow row = data.Tables[0].Rows[0];
                    Employee emp = new Employee();
                    emp.JobNumber = Convert.ToString(row["EMP_JobNumber"]);
                    emp.FullName = Convert.ToString(row["EMP_FullName"]);
                    emp.IDNumSuffix = Convert.ToString(row["EMP_IDNumSuffix"]);
                    emp.Mobile = Convert.ToString(row["EMP_Mobile"]);
                    emp.LastUpdate = Convert.ToDateTime(row["EMP_LastUpdate"]);
                    emp.Status = Convert.ToByte(row["EMP_Status"]);
                    emp.Company = Convert.ToString(row["EMP_Company"]);
                    emp.Organ = Convert.ToString(row["EMP_Organ"]);
                    emp.Depart = Convert.ToString(row["EMP_Depart"]);
                    emp.Category = Convert.ToString(row["EMP_Category"]);
                    emp.JobTitle = Convert.ToString(row["EMP_JobTitle"]);
                    emp.EntryDate = Convert.ToString(row["EMP_EntryDate"]);
                    emp.Gender = Convert.ToString(row["EMP_Gender"]);
                    emp.Division = Convert.ToString(row["EMP_Division"]);
                    emp.Group = Convert.ToString(row["EMP_Group"]);
                    data.Clear();
                    return emp;
                }
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("GetEmployeeByJobNumber error: job number={0}", jobNumber), e);
            }
            return null;
        }

        public static EmployeeView GetEmployeeWXUserByJobNumber(string jobNumber)
        {
            if (string.IsNullOrEmpty(jobNumber)) return null;
            try
            {
                string strSQL = "SELECT TOP 1 * FROM dbo.TA_Employee WHERE EMP_JobNumber=@JobNumber";
                List<SqlParameter> list = new List<SqlParameter>();
                list.Add(SqlHelper.MakeInParam("@JobNumber", SqlDbType.VarChar, 8, jobNumber));
                DataSet data = SqlHelper.ExecuteDataset(strSQL, list.ToArray());
                if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                {
                    DataRow row = data.Tables[0].Rows[0];
                    EmployeeView emp = new EmployeeView();
                    emp.JobNumber = Convert.ToString(row["EMP_JobNumber"]);
                    emp.FullName = Convert.ToString(row["EMP_FullName"]);
                    emp.IDNumSuffix = Convert.ToString(row["EMP_IDNumSuffix"]);
                    emp.Mobile = Convert.ToString(row["EMP_Mobile"]);
                    emp.LastUpdate = Convert.ToDateTime(row["EMP_LastUpdate"]);
                    emp.Status = Convert.ToByte(row["EMP_Status"]);
                    emp.Company = Convert.ToString(row["EMP_Company"]);
                    emp.Organ = Convert.ToString(row["EMP_Organ"]);
                    emp.Depart = Convert.ToString(row["EMP_Depart"]);
                    emp.Category = Convert.ToString(row["EMP_Category"]);
                    emp.JobTitle = Convert.ToString(row["EMP_JobTitle"]);
                    emp.EntryDate = Convert.ToString(row["EMP_EntryDate"]);
                    emp.Gender = Convert.ToString(row["EMP_Gender"]);
                    emp.Division = Convert.ToString(row["EMP_Division"]);
                    emp.Group = Convert.ToString(row["EMP_Group"]);
                    data.Clear();
                    emp.WXUserList = WXUserInfoDAO.GetWXUserListByJobNumber(jobNumber);
                    return emp;
                }
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("GetEmployeeWXUserByJobNumber error: job number={0}", jobNumber), e);
            }
            return null;
        }

        public static int UpdateEmployeeList(List<Employee> employeeList)
        {
            SqlConnection con = SqlHelper.GetConnection();
            if (con == null) return -2;
            SqlTransaction trans = SqlHelper.BeginTransaction(con);
            int result = -1;
            if (trans != null)
            {
                string strSQL = "UPDATE dbo.TA_Employee set EMP_Status=2,EMP_LastUpdate=GETDATE() WHERE EMP_Status=1"; //2=离职
                int rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strSQL));
                if (rowsAffected >= 0)
                {
                    string strUpdateSQL = "UPDATE dbo.TA_Employee set "
                        + "EMP_FullName=@FullName,EMP_IDNumSuffix=@Suffix,EMP_Mobile=@Mobile,"
                        + "EMP_LastUpdate=@LastUpdate,EMP_Status=@Status,EMP_Company=@Company,"
                        + "EMP_Organ=@Organ,EMP_Depart=@Depart,EMP_Division=@Division,"
                        + "EMP_Group=@Group,EMP_Category=@Category,EMP_JobTitle=@JobTitle,"
                        + "EMP_EntryDate=@EntryDate,EMP_Gender=@Gender "
                        + "WHERE EMP_JobNumber=@JobNum";
                    string strInsertSQL = "INSERT INTO dbo.TA_Employee("
                        + "EMP_JobNumber,EMP_FullName,EMP_IDNumSuffix,EMP_Mobile,EMP_LastUpdate,"
                        + "EMP_AddTime,EMP_Status,EMP_Company,EMP_Organ,EMP_Depart,EMP_Division,"
                        + "EMP_Group,EMP_Category,EMP_JobTitle,EMP_EntryDate,EMP_Gender"
                        + ") VALUES (@JobNum,@FullName,@Suffix,@Mobile,@LastUpdate,@LastUpdate,"
                        + "@Status,@Company,@Organ,@Depart,@Division,@Group,@Category,@JobTitle,"
                        + "@EntryDate,@Gender)";
                    int updateCount = 0;
                    foreach (Employee emp in employeeList)
                    {
                        List<SqlParameter> list = new List<SqlParameter>();
                        list.Add(SqlHelper.MakeInParam("@FullName", SqlDbType.NVarChar, 16, emp.FullName));
                        list.Add(SqlHelper.MakeInParam("@Suffix", SqlDbType.VarChar, 8, emp.IDNumSuffix));
                        list.Add(SqlHelper.MakeInParam("@Mobile", SqlDbType.VarChar, 16, emp.Mobile));
                        list.Add(SqlHelper.MakeInParam("@LastUpdate", SqlDbType.DateTime, 0, DateTime.Now));
                        list.Add(SqlHelper.MakeInParam("@Status", SqlDbType.TinyInt, 0, 1));//1=在職
                        list.Add(SqlHelper.MakeInParam("@JobNum", SqlDbType.VarChar, 8, emp.JobNumber));
                        list.Add(SqlHelper.MakeInParam("@Company", SqlDbType.NVarChar, 16, emp.Company));
                        list.Add(SqlHelper.MakeInParam("@Organ", SqlDbType.NVarChar, 16, emp.Organ));
                        list.Add(SqlHelper.MakeInParam("@Depart", SqlDbType.NVarChar, 16, emp.Depart));
                        list.Add(SqlHelper.MakeInParam("@Division", SqlDbType.NVarChar, 16, emp.Division));
                        list.Add(SqlHelper.MakeInParam("@Group", SqlDbType.NVarChar, 16, emp.Group));
                        list.Add(SqlHelper.MakeInParam("@Category", SqlDbType.NVarChar, 4, emp.Category));
                        list.Add(SqlHelper.MakeInParam("@JobTitle", SqlDbType.NVarChar, 16, emp.JobTitle));
                        list.Add(SqlHelper.MakeInParam("@EntryDate", SqlDbType.VarChar, 16, emp.EntryDate));
                        list.Add(SqlHelper.MakeInParam("@Gender", SqlDbType.NVarChar, 2, emp.Gender));
                        rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strUpdateSQL, list.ToArray()));
                        if (rowsAffected == 0)
                        {
                            rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strInsertSQL, list.ToArray()));
                        }
                        if (rowsAffected <= 0) break;
                        else updateCount += rowsAffected;
                    }
                    if (rowsAffected > 0) result = updateCount;
                }
                if (result > 0) SqlHelper.CommitTransaction(trans);
                else SqlHelper.RollbackTransaction(trans);
            }
            SqlHelper.ReleaseConnection(con);

            return result;
        }

        /*
        public static Organization GetEmployeeOrganization(UserRole ur, int Level)
        {
            Organization ognz = new Organization();
            if (Level < 1) return ognz;
            try
            {
                //根据事业部管理员所辖的事业部生成过滤条件
                List<SqlParameter> list = null;
                string organFilter = "";
                if (ur != null && ur.OrganOperators != null && ur.OrganOperators.Count > 0)
                {
                    list = new List<SqlParameter>();
                    organFilter += "WHERE (";
                    for (int i = 0; i < ur.OrganOperators.Count; i++)
                    {
                        CompanyOrganOperator coo = ur.OrganOperators[i];
                        if (i > 0) organFilter += " OR ";
                        organFilter += "(emp_Company=@Company" + i + " AND emp_Organ=@Organ" + i +
                            (string.IsNullOrEmpty(coo.Division) ? "" : (" AND emp_Division like @Division" + i)) +
                            (string.IsNullOrEmpty(coo.Depart) ? "" : (" AND emp_Depart like @Depart" + i)) +
                            (string.IsNullOrEmpty(coo.Group) ? "" : (" AND emp_Group like @Group" + i)) + ")";
                        list.Add(SqlHelper.MakeInParam("@Company" + i, SqlDbType.NVarChar, 16, coo.Company));
                        list.Add(SqlHelper.MakeInParam("@Organ" + i, SqlDbType.NVarChar, 16, coo.Organ));
                        if (!string.IsNullOrEmpty(coo.Depart))
                            list.Add(SqlHelper.MakeInParam("@Division" + i, SqlDbType.NVarChar, 16, coo.Division + "%"));
                        if (!string.IsNullOrEmpty(coo.Depart))
                            list.Add(SqlHelper.MakeInParam("@Depart" + i, SqlDbType.NVarChar, 16, coo.Depart + "%"));
                        if (!string.IsNullOrEmpty(coo.Depart))
                            list.Add(SqlHelper.MakeInParam("@Group" + i, SqlDbType.NVarChar, 16, coo.Group + "%"));
                    }
                    organFilter += ") ";
                }
                //if (!string.IsNullOrEmpty(organFilter)) strSQL += organFilter;
                string strSQL =
                    (Level >= 1 ? "select emp_company from ta_employee " + organFilter + "group by emp_company order by emp_company;" : "") +
                    (Level >= 2 ? "select emp_organ from ta_employee " + organFilter + "group by emp_organ order by emp_organ;" : "") +
                    (Level >= 3 ? "select emp_division from ta_employee " + organFilter + "group by emp_division order by emp_division;" : "") +
                    (Level >= 4 ? "select emp_depart from ta_employee " + organFilter + "group by emp_depart order by emp_depart;" : "") +
                    (Level >= 5 ? "select emp_group from ta_employee " + organFilter + "group by emp_group order by emp_group;" : "") +
                    (Level >= 6 ? "select emp_jobtitle from ta_employee " + organFilter + "group by emp_jobtitle order by emp_jobtitle;" : "");
                DataSet data = SqlHelper.ExecuteDataset(strSQL, list != null ? list.ToArray() : null);
                if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in data.Tables[0].Rows)
                    {
                        if (!string.IsNullOrEmpty(Convert.ToString(row[0]))) ognz.Companies.Add(Convert.ToString(row[0]));
                    }
                }
                if (data.Tables.Count > 1 && data.Tables[1].Rows.Count > 0)
                {
                    foreach (DataRow row in data.Tables[1].Rows)
                    {
                        if (!string.IsNullOrEmpty(Convert.ToString(row[0]))) ognz.Organs.Add(Convert.ToString(row[0]));
                    }
                }
                if (data.Tables.Count > 2 && data.Tables[2].Rows.Count > 0)
                {
                    foreach (DataRow row in data.Tables[2].Rows)
                    {
                        if (!string.IsNullOrEmpty(Convert.ToString(row[0]))) ognz.Divisions.Add(Convert.ToString(row[0]));
                    }
                }
                if (data.Tables.Count > 3 && data.Tables[3].Rows.Count > 0)
                {
                    foreach (DataRow row in data.Tables[3].Rows)
                    {
                        if (!string.IsNullOrEmpty(Convert.ToString(row[0]))) ognz.Departs.Add(Convert.ToString(row[0]));
                    }
                }
                if (data.Tables.Count > 4 && data.Tables[4].Rows.Count > 0)
                {
                    foreach (DataRow row in data.Tables[4].Rows)
                    {
                        if (!string.IsNullOrEmpty(Convert.ToString(row[0]))) ognz.Groups.Add(Convert.ToString(row[0]));
                    }
                }
                if (data.Tables.Count > 5 && data.Tables[5].Rows.Count > 0)
                {
                    foreach (DataRow row in data.Tables[5].Rows)
                    {
                        if (!string.IsNullOrEmpty(Convert.ToString(row[0]))) ognz.JobTitles.Add(Convert.ToString(row[0]));
                    }
                }
            }
            catch (Exception e)
            {
                WriteLog.Error("GetEmployeeOrganization Error:", e);
            }
            return ognz;
        }
        */

        public static OrganizationTree GetEmployeeOrganizationTree(UserRole ur, int level)
        {
            OrganizationTree tree = new OrganizationTree();
            string[] nodeArr = { "emp_company", "emp_organ", "emp_division", "emp_depart", "emp_group", "emp_jobtitle" };
            //string[] nodeArr = { "Company", "Organ", "Division", "Depart", "Group", "JobTitle" };
            if (level > nodeArr.Length || level < 1) return tree;
            string[] arr = nodeArr.Take(level).ToArray();
            string[] vals = new string[arr.Length];
            bool[] news = new bool[arr.Length];
            for (int i = 0; i < news.Length; i++) news[i] = false;
            TreeNode[] nodes = new TreeNode[arr.Length];
            for (int i = 0; i < nodes.Length; i++) nodes[i] = null;
            string fields = string.Join(",", arr);
            try
            {
                string strSQL =
                    "SELECT " + fields + " " +
                    "FROM dbo.TA_Employee WHERE EMP_Status="+EmployeeStatus.Valid;
                for (int i = 0; i < arr.Length; i++)
                    //strSQL += (i == 0 ? "WHERE " : "AND ") + arr[i] + " IS NOT NULL ";
                    strSQL += (i == 0 ? " AND " : "AND ") + arr[i] + " IS NOT NULL ";

                /** 根据事业部管理员所辖的事业部生成过滤条件  **/
                List<SqlParameter> list = null;
                string organFilter = "";
                if (ur != null && ur.OrganOperators != null && ur.OrganOperators.Count > 0)
                {
                    list = new List<SqlParameter>();
                    organFilter += "AND (";
                    for (int i = 0; i < ur.OrganOperators.Count; i++)
                    {
                        CompanyOrganOperator coo = ur.OrganOperators[i];
                        if (i > 0) organFilter += " OR ";
                        organFilter += "(emp_Company=@Company" + i + " AND emp_Organ=@Organ" + i +
                            (string.IsNullOrEmpty(coo.Division) ? "" : (" AND emp_Division=@Division" + i)) +
                            (string.IsNullOrEmpty(coo.Depart) ? "" : (" AND emp_Depart=@Depart" + i)) +
                            (string.IsNullOrEmpty(coo.Group) ? "" : (" AND emp_Group like @Group" + i)) + ")";
                        list.Add(SqlHelper.MakeInParam("@Company" + i, SqlDbType.NVarChar, 16, coo.Company));
                        list.Add(SqlHelper.MakeInParam("@Organ" + i, SqlDbType.NVarChar, 16, coo.Organ));
                        if (!string.IsNullOrEmpty(coo.Division))
                            list.Add(SqlHelper.MakeInParam("@Division" + i, SqlDbType.NVarChar, 16, coo.Division));
                        if (!string.IsNullOrEmpty(coo.Depart))
                            list.Add(SqlHelper.MakeInParam("@Depart" + i, SqlDbType.NVarChar, 16, coo.Depart));
                        if (!string.IsNullOrEmpty(coo.Group))
                            list.Add(SqlHelper.MakeInParam("@Group" + i, SqlDbType.NVarChar, 16, coo.Group + "%"));
                    }
                    organFilter += ") ";
                }
                if (!string.IsNullOrEmpty(organFilter)) strSQL += organFilter;
                /** **/

                strSQL += "GROUP BY " + fields + " " + "ORDER BY " + fields;
                DataSet data = SqlHelper.ExecuteDataset(strSQL, list!=null?list.ToArray():null);
                if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in data.Tables[0].Rows)
                    {
                        for (int i = 0; i < arr.Length; i++)
                        {
                            vals[i] = Convert.ToString(row[arr[i]]);
                            news[i] = (nodes[i] == null || vals[i] != nodes[i].NodeName || (i > 0 && news[i - 1]));
                            if (news[i])
                            {
                                nodes[i] = new TreeNode();
                                nodes[i].NodeName = vals[i];
                                if (i < arr.Length - 1)
                                    nodes[i].Childrens = new List<TreeNode>();
                                if (i == 0)
                                    tree.Companies.Add(nodes[i]);
                                else
                                    nodes[i - 1].Childrens.Add(nodes[i]);
                            }
                        }
                    }
                    data.Clear();
                }
            }
            catch (Exception e)
            {
                WriteLog.Error("GetOrganizationTree error:", e);
            }
            return tree;
        }

        public static void PaginationQuery(BaseFilter filter, PageList pl)
        {
            if (!(filter is EmployeeFilter)) return;
            EmployeeFilter fl = (EmployeeFilter)filter;
            pl.PageData = new List<object>();
            if (pl.PageSize <= 0 || pl.PageIndex <= 0) return;
            try
            {
                string strFROM = "FROM dbo.TA_Employee AS e";
                string strLeftJoin = " LEFT JOIN dbo.TA_StaffInfo AS s ON s.STF_PersonNumber=e.EMP_JobNumber";
                string strWHERE = " WHERE 1=1"
                    + (string.IsNullOrEmpty(fl.JobNumber) ? "" : " AND e.EMP_JobNumber=@jobNumber")
                    + (string.IsNullOrEmpty(fl.FullName) ? "" : " AND e.EMP_FullName LIKE @name")
                    + (string.IsNullOrEmpty(fl.Category) ? "" : " AND e.EMP_Category=@category")
                    + (string.IsNullOrEmpty(fl.Status) ? "" : " AND e.EMP_Status=@status")
                    + (string.IsNullOrEmpty(fl.Company) ? "" : " AND e.EMP_Company=@company")
                    + (string.IsNullOrEmpty(fl.Organ) ? "" : " AND e.EMP_Organ=@organ")
                    + (string.IsNullOrEmpty(fl.Division) ? "" : " AND e.EMP_Division=@division")
                    + (string.IsNullOrEmpty(fl.Depart) ? "" : " AND e.EMP_Depart=@depart")
                    + (string.IsNullOrEmpty(fl.Group) ? "" : " AND e.EMP_Group=@group")
                    + (string.IsNullOrEmpty(fl.JobTitle) ? "" : " AND e.EMP_JobTitle=@job");
                string strCountSQL = "SELECT COUNT(1) " + strFROM + strWHERE;
                List<SqlParameter> list = new List<SqlParameter>();
                if (!string.IsNullOrEmpty(fl.JobNumber))
                    list.Add(SqlHelper.MakeInParam("@jobNumber", SqlDbType.VarChar, 16, fl.JobNumber));
                if (!string.IsNullOrEmpty(fl.FullName))
                    list.Add(SqlHelper.MakeInParam("@name", SqlDbType.NVarChar, 8, "%" + fl.FullName + "%"));
                if (!string.IsNullOrEmpty(fl.Category))
                    list.Add(SqlHelper.MakeInParam("@category", SqlDbType.NVarChar, 16, fl.Category));
                if (!string.IsNullOrEmpty(fl.Status))
                    list.Add(SqlHelper.MakeInParam("@status", SqlDbType.VarChar, 16, fl.Status));
                if (!string.IsNullOrEmpty(fl.Company))
                    list.Add(SqlHelper.MakeInParam("@company", SqlDbType.NVarChar, 16, fl.Company));
                if (!string.IsNullOrEmpty(fl.Organ))
                    list.Add(SqlHelper.MakeInParam("@organ", SqlDbType.NVarChar, 16, fl.Organ));
                if (!string.IsNullOrEmpty(fl.Division))
                    list.Add(SqlHelper.MakeInParam("@division", SqlDbType.NVarChar, 16, fl.Division));
                if (!string.IsNullOrEmpty(fl.Group))
                    list.Add(SqlHelper.MakeInParam("@group", SqlDbType.NVarChar, 16, fl.Group));
                if (!string.IsNullOrEmpty(fl.Depart))
                    list.Add(SqlHelper.MakeInParam("@depart", SqlDbType.NVarChar, 16, fl.Depart));
                if (!string.IsNullOrEmpty(fl.JobTitle))
                    list.Add(SqlHelper.MakeInParam("@job", SqlDbType.NVarChar, 16, fl.JobTitle));
                DataSet data = SqlHelper.ExecuteDataset(strCountSQL, list.ToArray());
                pl.RowsCount = (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0) ? Convert.ToInt32(data.Tables[0].Rows[0][0]) : 0;
                pl.Calulate();
                pl.PageData.Clear();
                if (pl.RowsCount > 0)
                {
                    int start = (pl.PageIndex - 1) * pl.PageSize + 1;
                    int end = start + pl.PageSize - 1;
                    string strSQL = "select * from ("
                        + "SELECT ROW_NUMBER() OVER(ORDER BY e.EMP_LastUpdate DESC) AS NUMBER,e.*,s.STF_SectionChiefName " + strFROM
                        + strLeftJoin + strWHERE
                        + ") AS t where t.NUMBER BETWEEN " + start + " AND " + end;
                    data = SqlHelper.ExecuteDataset(strSQL, list.ToArray());
                    if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow row in data.Tables[0].Rows)
                        {
                            Employee emp = new Employee();
                            emp.JobNumber = Convert.ToString(row["EMP_JobNumber"]);
                            emp.FullName = Convert.ToString(row["EMP_FullName"]);
                            emp.IDNumSuffix = Convert.ToString(row["EMP_IDNumSuffix"]);
                            emp.Mobile = Convert.ToString(row["EMP_Mobile"]);
                            emp.LastUpdate = Convert.ToDateTime(row["EMP_LastUpdate"]);
                            emp.Status = Convert.ToByte(row["EMP_Status"]);
                            emp.Company = Convert.ToString(row["EMP_Company"]);
                            emp.Organ = Convert.ToString(row["EMP_Organ"]);
                            emp.Division = Convert.ToString(row["EMP_Division"]);
                            emp.Depart = Convert.ToString(row["EMP_Depart"]);
                            emp.Group = Convert.ToString(row["EMP_Group"]);
                            emp.Category = Convert.ToString(row["EMP_Category"]);
                            emp.JobTitle = Convert.ToString(row["EMP_JobTitle"]);
                            emp.EntryDate = Convert.ToString(row["EMP_EntryDate"]);
                            emp.Gender = Convert.ToString(row["EMP_Gender"]);
                            emp.SectionChiefName = Convert.ToString(row["STF_SectionChiefName"]);
                            pl.PageData.Add(emp);
                        }
                        data.Clear();
                    }
                }
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("PaginationQuery error:filters={0}", JsonUtil<EmployeeFilter>.JsonSerializerObject(fl)), e);
            }
        }

        public static Dictionary<string, string> Summary()
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            try
            {
                string strSQL =
                    "select CONVERT(VARCHAR(10),max(emp_lastupdate),103) as e_lastupdate from dbo.ta_employee;" +//最後導入時間
                    //"select max(emp_addtime) as e_lastaddtime from dbo.ta_employee;"+//最後添加時間
                    "select count(1) as e_count_new_leave from dbo.ta_employee as e "+
                    "inner join (select CONVERT(VARCHAR(8),max(emp_lastupdate),112) as lastupdate from dbo.ta_employee) as t "+
                    "on CONVERT(VARCHAR(8),e.emp_lastupdate,112)=t.lastupdate where e.emp_status=2;"+//最新離職人數
                    "select count(1) as e_count_new_onduty from dbo.ta_employee as e "+
                    "inner join (select CONVERT(VARCHAR(8),max(emp_addtime),112) as lastadd from dbo.ta_employee) as t "+
                    "on CONVERT(VARCHAR(8),e.emp_addtime,112)=t.lastadd where e.emp_status=1;"+//最新入職人數
                    "select count(1) as e_count_onduty from dbo.ta_employee where emp_status=1;"+//總共在職人數
                    "select count(1) as e_count_leave from dbo.ta_employee where emp_status=2;";//總共離職人數
                DataSet data = SqlHelper.ExecuteDataset(strSQL);
                if (data.Tables.Count > 0)
                {
                    if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0) dic.Add("e_lastupdate", Convert.ToString(data.Tables[0].Rows[0]["e_lastupdate"]));
                    if (data.Tables.Count > 1 && data.Tables[1].Rows.Count > 0) dic.Add("e_count_new_leave", Convert.ToString(data.Tables[1].Rows[0]["e_count_new_leave"]));
                    if (data.Tables.Count > 2 && data.Tables[2].Rows.Count > 0) dic.Add("e_count_new_onduty", Convert.ToString(data.Tables[2].Rows[0]["e_count_new_onduty"]));
                    if (data.Tables.Count > 3 && data.Tables[3].Rows.Count > 0) dic.Add("e_count_onduty", Convert.ToString(data.Tables[3].Rows[0]["e_count_onduty"]));
                    if (data.Tables.Count > 4 && data.Tables[4].Rows.Count > 0) dic.Add("e_count_leave", Convert.ToString(data.Tables[4].Rows[0]["e_count_leave"]));
                    data.Clear();
                }
            }
            catch (Exception e)
            {
                WriteLog.Error("Employee Summary error:", e);
            }
            return dic;
        }
    }
}
