﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using LEO.Project.WXProposal.Model.QueryFilter;
using LEO.Project.WXProposal.Model.Pagination;
using LEO.Project.WXProposal.Data.Entity;
using LEO.Project.Tools;

namespace LEO.Project.WXProposal.Data.DAO
{
    public class WXUserInfoDAO
    {
        /*
        public static List<WXUserInfo> GetWXUserListByJobNumbers(List<string> jobNumbers)
        {
            if (jobNumbers == null || jobNumbers.Count==0) return null;
            try
            {
                string strSQL = "SELECT a.wxu_openid,wxu_nickname,b.ewl_jobnumber FROM ta_wxuserinfo AS a,"
                    + "ta_emp_wxu_link AS b WHERE b.ewl_openid=a.wxu_openid AND b.ewl_jobnumber IN (";
                List<SqlParameter> list = new List<SqlParameter>();
                for (int i = 0; i < jobNumbers.Count; i++)
                {
                    strSQL += "@JobNum"+i;
                    list.Add(SqlHelper.MakeInParam("@JobNum"+i, SqlDbType.VarChar, 8, jobNumbers[i]));
                }
                strSQL += ")";
                DataSet data = SqlHelper.ExecuteDataset(strSQL, list.ToArray());
                if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                {
                    List<WXUserInfo> wxulst = new List<WXUserInfo>();
                    foreach (DataRow row in data.Tables[0].Rows)
                    {
                        WXUserInfo wxu = new WXUserInfo();
                        wxu.OpenID = Convert.ToString(row["WXU_OpenID"]);
                        wxu.NickName = Convert.ToString(row["WXU_NickName"]);
                        wxu.JobNumber = Convert.ToString(row["EWL_JobNumber"]);
                        wxulst.Add(wxu);
                    }
                    data.Clear();
                    return wxulst;
                }
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("GetWXUserListByJobNumbers error: jobNumbers={0}", String.Join(",", jobNumbers.ToArray())), e);
            }
            return null;
        }
        */

        public static List<WXUserInfo> GetWXUserListByJobNumber(string jobNumber)
        {
            if (string.IsNullOrEmpty(jobNumber)) return null;
            try
            {
                string strSQL = "SELECT * FROM dbo.TA_WXUserInfo AS a "
                    + "LEFT JOIN TA_Emp_WXU_Link AS b on b.EWL_OpenID=a.WXU_OpenID "
                    + "WHERE b.EWL_JobNumber=@JobNum";
                List<SqlParameter> list = new List<SqlParameter>();
                list.Add(SqlHelper.MakeInParam("@JobNum", SqlDbType.VarChar, 8, jobNumber));
                DataSet data = SqlHelper.ExecuteDataset(strSQL, list.ToArray());
                if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                {
                    List<WXUserInfo> wxulst = new List<WXUserInfo>();
                    foreach (DataRow row in data.Tables[0].Rows)
                    {
                        WXUserInfo wxu = new WXUserInfo();
                        wxu.OpenID = Convert.ToString(row["WXU_OpenID"]);
                        wxu.NickName = Convert.ToString(row["WXU_NickName"]);
                        wxu.Sex = Convert.ToString(row["WXU_Sex"]);
                        wxu.Country = Convert.ToString(row["WXU_Country"]);
                        wxu.Province = Convert.ToString(row["WXU_Province"]);
                        wxu.City = Convert.ToString(row["WXU_City"]);
                        wxu.LastUpdate = Convert.ToDateTime(row["WXU_LastUpdate"]);
                        wxu.Status = Convert.ToByte(row["WXU_Status"]);//0=无效,1=有效
                        wxu.JobNumber = Convert.ToString(row["EWL_JobNumber"]);
                        wxulst.Add(wxu);
                    }
                    data.Clear();
                    return wxulst;
                }
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("GetWXUserListByJobNumber error: jobNumber={0}", jobNumber), e);
            }
            return null;
        }

        public static WXUserInfo GetWXUserInfoByOpenId(string openId)
        {
            if (string.IsNullOrEmpty(openId)) return null;
            try
            {
                string strSQL = "SELECT TOP 1 * FROM dbo.TA_WXUserInfo AS a "
                    + "LEFT JOIN TA_Emp_WXU_Link AS b on b.EWL_OpenID=a.WXU_OpenID "
                    + "WHERE a.WXU_OpenID=@OpenId";
                List<SqlParameter> list = new List<SqlParameter>();
                list.Add(SqlHelper.MakeInParam("@OpenId", SqlDbType.VarChar, 32, openId));
                DataSet data = SqlHelper.ExecuteDataset(strSQL, list.ToArray());
                if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                {
                    DataRow row = data.Tables[0].Rows[0];
                    WXUserInfo wxu = new WXUserInfo();
                    wxu.OpenID = Convert.ToString(row["WXU_OpenID"]);
                    wxu.NickName = Convert.ToString(row["WXU_NickName"]);
                    wxu.Sex = Convert.ToString(row["WXU_Sex"]);
                    wxu.Country = Convert.ToString(row["WXU_Country"]);
                    wxu.Province = Convert.ToString(row["WXU_Province"]);
                    wxu.City = Convert.ToString(row["WXU_City"]);
                    wxu.LastUpdate = Convert.ToDateTime(row["WXU_LastUpdate"]);
                    wxu.Status = Convert.ToByte(row["WXU_Status"]);//0=无效,1=有效
                    wxu.JobNumber = Convert.ToString(row["EWL_JobNumber"]);
                    data.Clear();
                    return wxu;
                }
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("Get WXUserInfo error: OpenID={0}", openId), e);
            }
            return null;
        }

        public static int InsertWXUserInfo(WXUserInfo wxu)
        {
            SqlConnection con = SqlHelper.GetConnection();
            if (con == null) return -2;
            SqlTransaction trans = SqlHelper.BeginTransaction(con);
            int result = -1;
            if (trans != null)
            {
                string strInsertSQL = "INSERT INTO dbo.TA_WXUserInfo("
                    + "WXU_OpenID,WXU_NickName,WXU_Sex,WXU_Country,WXU_Province,WXU_City,WXU_LastUpdate,WXU_Status"
                    + ") VALUES (@OpenID,@NickName,@Sex,@Country,@Province,@City,@LastUpdate,@Status)";
                List<SqlParameter> list = new List<SqlParameter>();
                list.Add(SqlHelper.MakeInParam("@OpenID", SqlDbType.VarChar, 32, wxu.OpenID));
                list.Add(SqlHelper.MakeInParam("@NickName", SqlDbType.NVarChar, 32, wxu.NickName));
                list.Add(SqlHelper.MakeInParam("@Sex", SqlDbType.NVarChar, 4, wxu.Sex));
                list.Add(SqlHelper.MakeInParam("@Country", SqlDbType.NVarChar, 32, wxu.Country));
                list.Add(SqlHelper.MakeInParam("@Province", SqlDbType.NVarChar, 32, wxu.Province));
                list.Add(SqlHelper.MakeInParam("@City", SqlDbType.NVarChar, 32, wxu.City));
                list.Add(SqlHelper.MakeInParam("@LastUpdate", SqlDbType.DateTime, 0, DateTime.Now));
                list.Add(SqlHelper.MakeInParam("@Status", SqlDbType.TinyInt, 0, wxu.Status));
                int rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strInsertSQL, list.ToArray()));
                if (rowsAffected > 0 && !string.IsNullOrEmpty(wxu.JobNumber))
                {
                    strInsertSQL = "INSERT INTO dbo.TA_Emp_WXU_Link("
                    + "EWL_OpenID,EWL_JobNumber) VALUES (@OpenID,@JobNumber)";
                    list = new List<SqlParameter>();
                    list.Add(SqlHelper.MakeInParam("@OpenID", SqlDbType.VarChar, 32, wxu.OpenID));
                    list.Add(SqlHelper.MakeInParam("@JobNumber", SqlDbType.VarChar, 8, wxu.JobNumber));
                    rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strInsertSQL, list.ToArray()));
                }
                if (rowsAffected > 0) result = 1;
                if (result > 0) SqlHelper.CommitTransaction(trans);
                else SqlHelper.RollbackTransaction(trans);
            }
            SqlHelper.ReleaseConnection(con);

            return result;
        }

        public static int UpdateWXUserInfo(WXUserInfo wxu, string mobile)
        {
            SqlConnection con = SqlHelper.GetConnection();
            if (con == null) return -2;
            SqlTransaction trans = SqlHelper.BeginTransaction(con);
            int result = -1;
            if (trans != null)
            {
                string strSQL = "UPDATE dbo.TA_WXUserInfo set "
                    + "WXU_NickName=@NickName,WXU_Sex=@Sex,WXU_Country=@Country,WXU_Province=@Province,"
                    + "WXU_City=@City,WXU_LastUpdate=@LastUpdate,WXU_Status=@Status "
                    + "WHERE WXU_OpenID=@OpenID";
                List<SqlParameter> list = new List<SqlParameter>();
                list.Add(SqlHelper.MakeInParam("@OpenID", SqlDbType.VarChar, 32, wxu.OpenID));
                list.Add(SqlHelper.MakeInParam("@NickName", SqlDbType.NVarChar, 32, wxu.NickName));
                list.Add(SqlHelper.MakeInParam("@Sex", SqlDbType.NVarChar, 4, wxu.Sex));
                list.Add(SqlHelper.MakeInParam("@Country", SqlDbType.NVarChar, 32, wxu.Country));
                list.Add(SqlHelper.MakeInParam("@Province", SqlDbType.NVarChar, 32, wxu.Province));
                list.Add(SqlHelper.MakeInParam("@City", SqlDbType.NVarChar, 32, wxu.City));
                list.Add(SqlHelper.MakeInParam("@LastUpdate", SqlDbType.DateTime, 0, DateTime.Now));
                list.Add(SqlHelper.MakeInParam("@Status", SqlDbType.TinyInt, 0, wxu.Status));
                int rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strSQL, list.ToArray()));
                if (rowsAffected > 0)
                {
                    if (!string.IsNullOrEmpty(wxu.JobNumber) && !string.IsNullOrEmpty(mobile))
                    {
                        strSQL = "UPDATE dbo.TA_Emp_WXU_Link SET EWL_JobNumber=@JobNumber,EWL_Mobile=@Mobile WHERE EWL_OpenID=@OpenID";
                        list.Clear();
                        list.Add(SqlHelper.MakeInParam("@OpenID", SqlDbType.VarChar, 32, wxu.OpenID));
                        list.Add(SqlHelper.MakeInParam("@JobNumber", SqlDbType.VarChar, 8, wxu.JobNumber));
                        list.Add(SqlHelper.MakeInParam("@Mobile", SqlDbType.VarChar, 16, mobile));
                        rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strSQL, list.ToArray()));
                        if (rowsAffected == 0)
                        {
                            strSQL = "INSERT INTO dbo.TA_Emp_WXU_Link(EWL_OpenID,EWL_JobNumber,EWL_Mobile) VALUES (@OpenID,@JobNumber,@Mobile)";
                            rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strSQL, list.ToArray()));
                        }
                        if (rowsAffected > 0)
                        {
                            strSQL = "UPDATE dbo.TA_Employee set EMP_Mobile=@Mobile WHERE EMP_JobNumber=@JobNumber";
                            list.Clear();
                            list.Add(SqlHelper.MakeInParam("@JobNumber", SqlDbType.VarChar, 8, wxu.JobNumber));
                            list.Add(SqlHelper.MakeInParam("@Mobile", SqlDbType.VarChar, 16, mobile));
                            rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strSQL, list.ToArray()));
                        }
                    }
                    else if (string.IsNullOrEmpty(wxu.JobNumber))
                    {
                        strSQL = "DELETE from dbo.TA_Emp_WXU_Link WHERE EWL_OpenID=@OpenID";
                        list.Clear();
                        list.Add(SqlHelper.MakeInParam("@OpenID", SqlDbType.VarChar, 32, wxu.OpenID));
                        //list.Add(SqlHelper.MakeInParam("@JobNumber", SqlDbType.VarChar, 8, wxu.JobNumber));
                        SqlHelper.ExecuteNonQuery(trans, strSQL, list.ToArray());
                    }
                }
                if (rowsAffected > 0) result = 1;
                if (result > 0) SqlHelper.CommitTransaction(trans);
                else SqlHelper.RollbackTransaction(trans);
            }
            SqlHelper.ReleaseConnection(con);

            return result;
        }

        public static int DeleteWXUserInfos(string[] openIds)
        {
            if (openIds == null || openIds.Length == 0) return 0;
            int result = -1;
            SqlConnection con = null;
            SqlTransaction trans = null;
            try
            {
                con = SqlHelper.GetConnection();
                if (con == null) return -2;
                trans = SqlHelper.BeginTransaction(con);
                if (trans != null)
                {
                    string strSQL = "DELETE FROM dbo.TA_WXUserInfo WHERE WXU_OpenID IN (";
                    string strSQL1 = "DELETE FROM dbo.TA_Emp_WXU_Link WHERE EWL_OpenID IN (";
                    List<SqlParameter> list = new List<SqlParameter>();
                    for (int i = 0; i < openIds.Length; i++)
                    {
                        strSQL += "@OpenId" + i;
                        strSQL1 += "@OpenId" + i;
                        list.Add(SqlHelper.MakeInParam("@OpenId" + i, SqlDbType.VarChar, 32, openIds[i]));
                    }
                    strSQL += ")";
                    strSQL1 += ")";
                    int rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strSQL, list.ToArray()));
                    if (rowsAffected > 0)
                    {
                        int rdel = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strSQL1, list.ToArray()));
                        if (rdel < 0) rowsAffected = 0;
                    }
                    if (rowsAffected > 0) result = 1;
                }
            }
            catch (Exception ex)
            {
                WriteLog.Error("DeleteWXUserInfos Error:", ex);
            }
            finally
            {
                if (trans != null)
                {
                    if (result > 0) SqlHelper.CommitTransaction(trans);
                    else SqlHelper.RollbackTransaction(trans);
                }
                if (con != null) SqlHelper.ReleaseConnection(con);
            }

            return result;
        }

        public static void PaginationQuery(BaseFilter filter, PageList pl)
        {
            if (!(filter is WXUserFilter)) return;
            WXUserFilter fl = (WXUserFilter)filter;
            pl.PageData = new List<object>();
            if (pl.PageSize <= 0 || pl.PageIndex <= 0) return;
            try
            {
                string strFROM =
                    " FROM dbo.TA_WXUserInfo as w" +
                    " LEFT JOIN dbo.TA_EMP_WXU_Link AS l ON l.EWL_OpenID=w.WXU_OpenID" +
                    " LEFT JOIN dbo.TA_Employee AS e ON e.EMP_JobNumber=l.EWL_JobNumber";
                string strPCount = 
                    " LEFT JOIN  (SELECT COUNT(1) AS pcount,p.PPS_WX_OpenID FROM TA_Proposal AS p"+
                    " WHERE p.PPS_WX_OpenID IS NOT NULL GROUP BY p.PPS_WX_OpenID) AS pc"+
                    " ON w.WXU_OpenID=pc.PPS_WX_OpenID";
                string strWHERE = " WHERE 1=1"
                    + (string.IsNullOrEmpty(fl.JobNumber) ? "" : " AND l.EWL_JobNumber=@jobNumber")
                    + (string.IsNullOrEmpty(fl.FullName) ? "" : " AND e.EMP_FullName LIKE @name")
                    + (string.IsNullOrEmpty(fl.Mobile) ? "" : " AND l.EWL_Mobile=@mobile")
                    + ((string.IsNullOrEmpty(fl.RegStatus) || (fl.RegStatus != "0" && fl.RegStatus != "1")) ? "" : (fl.RegStatus == "1" ? " AND l.EWL_JobNumber IS NOT NULL" : (fl.RegStatus == "0" ? " AND l.EWL_JobNumber IS NULL" : "")));
                string strCountSQL = "SELECT COUNT(1)" + strFROM + strWHERE;
                List<SqlParameter> list = new List<SqlParameter>();
                if (!string.IsNullOrEmpty(fl.JobNumber))
                    list.Add(SqlHelper.MakeInParam("@jobNumber", SqlDbType.VarChar, 16, fl.JobNumber));
                if (!string.IsNullOrEmpty(fl.FullName))
                    list.Add(SqlHelper.MakeInParam("@name", SqlDbType.NVarChar, 8, "%" + fl.FullName + "%"));
                if (!string.IsNullOrEmpty(fl.Mobile))
                    list.Add(SqlHelper.MakeInParam("@mobile", SqlDbType.NVarChar, 16, fl.Mobile));
                DataSet data = SqlHelper.ExecuteDataset(strCountSQL, list.ToArray());
                pl.RowsCount = (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0) ? Convert.ToInt32(data.Tables[0].Rows[0][0]) : 0;
                pl.Calulate();
                pl.PageData.Clear();
                if (pl.RowsCount > 0)
                {
                    int start = (pl.PageIndex - 1) * pl.PageSize + 1;
                    int end = start + pl.PageSize - 1;
                    string strSQL = 
                        "select * from ("+
                        "SELECT ROW_NUMBER() OVER(ORDER BY w.WXU_LastUpdate DESC) AS NUMBER,"+
                        "w.*,l.EWL_Mobile,l.EWL_JobNumber,e.EMP_FullName,e.EMP_Mobile,pc.pcount" +
                        strFROM + strPCount + strWHERE + 
                        ") AS t where t.NUMBER BETWEEN " + start + " AND " + end;
                    data = SqlHelper.ExecuteDataset(strSQL, list.ToArray());
                    if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow row in data.Tables[0].Rows)
                        {
                            WXUserView wu = new WXUserView();
                            wu.JobNumber = Convert.ToString(row["EWL_JobNumber"]);
                            wu.FullName = Convert.ToString(row["EMP_FullName"]);
                            wu.Mobile = Convert.ToString(row["EWL_Mobile"]);
                            DateTime? dt = Convert.ToDateTime(row["WXU_LastUpdate"]);
                            wu.LastUpdate = (dt.HasValue) ? dt.Value.ToString("yyyy-MM-dd HH:mm") : ""; ;
                            wu.OpenID = Convert.ToString(row["WXU_OpenID"]);
                            wu.NickName = Convert.ToString(row["WXU_NickName"]);
                            string pcount = Convert.ToString(row["pcount"]);
                            wu.ProposalCount = (string.IsNullOrEmpty(pcount) ? 0 : int.Parse(pcount));
                            string Country = Convert.ToString(row["WXU_Country"]);
                            string Province = Convert.ToString(row["WXU_Province"]);
                            string City = Convert.ToString(row["WXU_City"]);
                            wu.Region = "";
                            if (!string.IsNullOrEmpty(Country))
                                wu.Region += (string.IsNullOrEmpty(wu.Region) ? "" : " ") + Country;
                            if (!string.IsNullOrEmpty(Province))
                                wu.Region += (string.IsNullOrEmpty(wu.Region) ? "" : " ") + Province;
                            if (!string.IsNullOrEmpty(City))
                                wu.Region += (string.IsNullOrEmpty(wu.Region) ? "" : " ") + City;
                            pl.PageData.Add(wu);
                        }
                        data.Clear();
                    }
                }
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("PaginationQuery error:filters={0}", JsonUtil<WXUserFilter>.JsonSerializerObject(fl)), e);
            }
        }

        public static Dictionary<string, string> Summary()
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            try
            {
                string strSQL =
                    "select count(1) as w_count_today_reg from dbo.ta_wxuserinfo where CONVERT(VARCHAR(8),wxu_lastupdate,112)=CONVERT(VARCHAR(8),GETDATE(),112);" +//今日註冊
                    "select count(1) as w_count_total from dbo.ta_wxuserinfo;";//總註冊數
                DataSet data = SqlHelper.ExecuteDataset(strSQL);
                if (data.Tables.Count > 0)
                {
                    if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0) dic.Add("w_count_today_reg", Convert.ToString(data.Tables[0].Rows[0]["w_count_today_reg"]));
                    if (data.Tables.Count > 1 && data.Tables[1].Rows.Count > 0) dic.Add("w_count_total", Convert.ToString(data.Tables[1].Rows[0]["w_count_total"]));
                    data.Clear();
                }
            }
            catch (Exception e)
            {
                WriteLog.Error("WXUserInfo Summary error:", e);
            }
            return dic;
        }

    }
}
