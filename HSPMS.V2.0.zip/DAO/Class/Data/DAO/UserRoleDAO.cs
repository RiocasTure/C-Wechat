﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LEO.Project.WXProposal.Data.Entity;
using System.Data.SqlClient;
using System.Data;
using LEO.Project.Tools;

namespace LEO.Project.WXProposal.Data.DAO
{
    public class UserRoleDAO
    {
        private static UserRoleDAO _instance;
        public static UserRoleDAO instance
        {
            get
            {
                if (_instance == null) _instance = new UserRoleDAO();
                return _instance;
            }
        }
        /*
        public static string GetUserRoleByAccount(string account)
        {
            if (string.IsNullOrEmpty(account)) return null;
            try
            {
                string strSQL = 
                    "SELECT * FROM dbo.TA_User_Role WHERE UPPER(UR_UserID)=@Account OR "+
                    "(UPPER(UR_UserID) IN (select UPPER(ad_accountname) FROM ta_ad_account WHERE ad_jobnumber=@Account)) OR "+
                    "(UPPER(UR_UserID) IN (select UPPER(ad_jobnumber) FROM ta_ad_account WHERE ad_accountname=@Account))";
                List<SqlParameter> list = new List<SqlParameter>();
                list.Add(SqlHelper.MakeInParam("@Account", SqlDbType.NVarChar, 32, account.ToUpper()));
                DataSet data = SqlHelper.ExecuteDataset(strSQL, list.ToArray());
                string ur = UserRole.Role_None;
                List<string> roles = new List<string>();
                if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in data.Tables[0].Rows)
                    {
                        string roleName = Convert.ToString(row["UR_RoleName"]);
                        roles.AddRange(new HashSet<string>(roleName.Split(UserRole.RoleSplit)).ToArray());
                    }
                    data.Clear();
                }
                if (roles.Count > 0)
                {
                    roles = new List<string>(new HashSet<string>(roles.ToArray()));
                    ur = string.Join("|", roles.ToArray());
                }
                return ur;
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("GetUserRoleByAccount error: account={0}", account), e);
            }
            return null;
        }
        */

        public UserRole GetUserRoleByUserID(string userId)
        {
            if (string.IsNullOrEmpty(userId)) return null;
            try
            {
                /*
                string strSQL =
                    "SELECT TOP 1 * FROM dbo.TA_User_Role WHERE UPPER(UR_UserID)=@RoleUserId";
                List<SqlParameter> list = new List<SqlParameter>();
                list.Add(SqlHelper.MakeInParam("@RoleUserId", SqlDbType.VarChar, 16, userId.ToUpper()));
                SqlParameter[] param = list.ToArray();
                WriteLog.Info(param.Length > 0 ? string.Format("{0}={1}", param[0].ParameterName,param[0].Value.ToString()) : "No Parameter!");
                DataSet data = SqlHelper.ExecuteDataset(strSQL, param);
                */
                DataSet data = SqlHelper.ExecuteDataset("SELECT TOP 1 * FROM dbo.TA_User_Role WHERE UPPER(UR_UserID)='"+userId.ToUpper()+"'");
                if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                {
                    UserRole ur = new UserRole();
                    ur.UserID = userId;
                    ur.RoleName = Convert.ToString(data.Tables[0].Rows[0]["UR_RoleName"]);
                    ur.IDType = Convert.ToString(data.Tables[0].Rows[0]["UR_IDType"]);
                    ur.SecureCode = Convert.ToString(data.Tables[0].Rows[0]["UR_SecureCode"]);
                    data.Clear();
                    /*
                    strSQL = "SELECT * FROM dbo.TA_Organ_Operator WHERE UPPER(OPT_UserID)=@RoleUserId";
                    data = SqlHelper.ExecuteDataset(strSQL, list.ToArray());
                    */
                    data = SqlHelper.ExecuteDataset("SELECT * FROM dbo.TA_Organ_Operator WHERE UPPER(OPT_UserID)='"+userId.ToUpper()+"'");
                    if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                    {
                        ur.OrganOperators = new List<CompanyOrganOperator>();
                        foreach (DataRow row in data.Tables[0].Rows)
                        {
                            CompanyOrganOperator coo = new CompanyOrganOperator();
                            coo.UserID = Convert.ToString(row["OPT_UserID"]);
                            coo.IDType = Convert.ToString(row["OPT_IDType"]);
                            coo.Company = Convert.ToString(row["OPT_Company"]);
                            coo.Organ = Convert.ToString(row["OPT_Organ"]);
                            coo.Division = Convert.ToString(row["OPT_Division"]);
                            coo.Depart = Convert.ToString(row["OPT_Depart"]);
                            coo.Group = Convert.ToString(row["OPT_Group"]);
                            ur.OrganOperators.Add(coo);
                        }
                        data.Clear();
                    }
                    return ur;
                }
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("GetUserRoleByUserID error: userId={0}", userId), e);
            }
            return null;
        }

        public int SaveUserRole(UserRole ur)
        {
            if (ur == null) return 0;
            SqlConnection con = SqlHelper.GetConnection();
            if (con == null) return -2;
            SqlTransaction trans = SqlHelper.BeginTransaction(con);
            int rowsAffected = 0;
            if (trans != null)
            {
                string strUpdateSQL = "UPDATE dbo.TA_User_Role WHERE SET UR_RoleName=@Role WHERE UPPER(UR_UserID)=UPPER(@Account)";
                string strInsertSQL = "INSERT INTO dbo.TA_User_Role(UR_UserID,UR_IDType,UR_RoleName) VALUES (@Account,@IDType,@Role)";
                List<SqlParameter> list = new List<SqlParameter>();
                list.Add(SqlHelper.MakeInParam("@Account", SqlDbType.NVarChar, 32, ur.UserID));
                list.Add(SqlHelper.MakeInParam("@IDType", SqlDbType.Char, 2, ur.IDType));
                list.Add(SqlHelper.MakeInParam("@Role", SqlDbType.NVarChar, 32, ur.RoleName));
                rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strUpdateSQL, list.ToArray()));
                if (rowsAffected == 0)
                {
                    rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strInsertSQL, list.ToArray()));
                }
                if (rowsAffected > 0) SqlHelper.CommitTransaction(trans);
                else SqlHelper.RollbackTransaction(trans);
            }
            SqlHelper.ReleaseConnection(con);
            return rowsAffected;
        }
    }
}
