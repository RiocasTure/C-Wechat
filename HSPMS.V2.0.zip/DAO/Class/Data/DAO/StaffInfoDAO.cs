﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using LEO.Project.WXProposal.Data.Entity;
using System.Data;
using LEO.Project.Tools;

namespace LEO.Project.WXProposal.Data.DAO
{
    public class StaffInfoDAO
    {
        public static int CountStaffInfoRecords()
        {
            try
            {
                string strSQL = "SELECT COUNT(1) AS REC_COUNT FROM dbo.TA_StaffInfo";
                DataSet data = SqlHelper.ExecuteDataset(strSQL);
                if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
                {
                    DataRow row = data.Tables[0].Rows[0];
                    int count = Convert.ToInt32(row["REC_COUNT"]);
                    data.Clear();
                    return count;
                }
                return 0;
            }
            catch (Exception e)
            {
                WriteLog.Error("CountStaffInfoRecords Exception", e);
                return -1;
            }
        }

        public static int UpdateStaffInfoList(List<StaffInfo> staffList)
        {
            if (staffList == null || staffList.Count == 0) return 0;
            int result = -1;
            SqlConnection con = null;
            SqlTransaction trans = null;
            try
            {
                con = SqlHelper.GetConnection();
                if (con == null) return -2;
                trans = SqlHelper.BeginTransaction(con);
                if (trans != null)
                {
                    string strSQL = "DELETE FROM dbo.TA_StaffInfo"; //2=离职
                    int rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strSQL));
                    if (rowsAffected >= 0)
                    {
                        string strInsertSQL = "INSERT INTO dbo.TA_StaffInfo("
                            + "STF_PersonNumber,STF_PersonName,STF_RoleName,STF_SectionChiefName,STF_SectionChiefNumber,"
                            + "STF_SupervisorName,STF_SupervisorNumber,STF_LeaderName,STF_LeaderNumber,STF_AreaName,"
                            + "STF_FloorName,STF_GroupName,STF_DivisionName,STF_JoinDate,STF_EmploymentName,STF_State,"
                            + "STF_LastUpdate) VALUES (@PersonNumber,@PersonName,@RoleName,@SectionChiefName,"
                            + "@SectionChiefNumber,@SupervisorName,@SupervisorNumber,@LeaderName,@LeaderNumber,"
                            + "@AreaName,@FloorName,@GroupName,@DivisionName,@JoinDate,@EmploymentName,@State,"
                            + "@LastUpdate)";
                        int updateCount = 0;
                        DateTime now = DateTime.Now;
                        foreach (StaffInfo stf in staffList)
                        {
                            stf.LastUpdate = now;
                            List<SqlParameter> list = new List<SqlParameter>();
                            list.Add(SqlHelper.MakeInParam("@PersonNumber", SqlDbType.VarChar, 32, stf.PersonNumber));
                            list.Add(SqlHelper.MakeInParam("@PersonName", SqlDbType.NVarChar, 16, stf.PersonName));
                            list.Add(SqlHelper.MakeInParam("@RoleName", SqlDbType.NVarChar, 8, stf.RoleName));
                            list.Add(SqlHelper.MakeInParam("@SectionChiefName", SqlDbType.NVarChar, 32, stf.SectionChiefName));
                            list.Add(SqlHelper.MakeInParam("@SectionChiefNumber", SqlDbType.VarChar, 64, stf.SectionChiefNumber));
                            list.Add(SqlHelper.MakeInParam("@SupervisorName", SqlDbType.NVarChar, 32, stf.SupervisorName));
                            list.Add(SqlHelper.MakeInParam("@SupervisorNumber", SqlDbType.VarChar, 64, stf.SupervisorNumber));
                            list.Add(SqlHelper.MakeInParam("@LeaderName", SqlDbType.NVarChar, 32, stf.LeaderName));
                            list.Add(SqlHelper.MakeInParam("@LeaderNumber", SqlDbType.VarChar, 64, stf.LeaderNumber));
                            list.Add(SqlHelper.MakeInParam("@AreaName", SqlDbType.NVarChar, 16, stf.AreaName));
                            list.Add(SqlHelper.MakeInParam("@FloorName", SqlDbType.NVarChar, 16, stf.FloorName));
                            list.Add(SqlHelper.MakeInParam("@GroupName", SqlDbType.NVarChar, 16, stf.GroupName));
                            list.Add(SqlHelper.MakeInParam("@DivisionName", SqlDbType.NVarChar, 16, stf.DivisionName));
                            list.Add(SqlHelper.MakeInParam("@JoinDate", SqlDbType.VarChar, 10, stf.JoinDate));
                            list.Add(SqlHelper.MakeInParam("@EmploymentName", SqlDbType.NVarChar, 16, stf.EmploymentName));
                            list.Add(SqlHelper.MakeInParam("@State", SqlDbType.Char, 1, stf.State));
                            list.Add(SqlHelper.MakeInParam("@LastUpdate", SqlDbType.DateTime, 0, stf.LastUpdate));
                            rowsAffected = Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans, strInsertSQL, list.ToArray()));
                            if (rowsAffected <= 0) break;
                            else updateCount += rowsAffected;
                        }
                        if (updateCount == staffList.Count) result = updateCount;
                    }
                }
            }
            catch (Exception ex)
            {
                WriteLog.Error("UpdateStaffInfoList Exception", ex);
            }
            finally
            {
                try
                {
                    if (trans != null)
                    {
                        if (result > 0) SqlHelper.CommitTransaction(trans);
                        else SqlHelper.RollbackTransaction(trans);
                    }
                }
                catch (Exception e)
                {
                    WriteLog.Error("Transaction End Exception", e);
                }
                finally
                {
                    if (con != null) SqlHelper.ReleaseConnection(con);
                }
            }

            return result;
        }

    }
}
