﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Timers;
using System.IO;
using System.Globalization;
using System.Xml.Serialization;
using LEO.Project.WXProposal;
using LEO.Project.WXProposal.Model.Session;
using LEO.Project.Tools;
using LEO.Project.WXProposal.Data.Entity;
using LEO.Project.WXProposal.Data.DAO;
using System.Text;
using System.Runtime.CompilerServices;

namespace LEO.Project.WXProposal.Control
{
    public class SessionDaemon
    {
        public static readonly int MinIntervalOfSessionListSaving = 180000;//保存SessionList的最短时间间隔为3分钟
        public static readonly int SessionTimeout = 12*3600000;//Session有效期为12小时
        public static readonly int MaxSessionCapacity = 5000;//最大Session容量为5000用户

        private static SessionDaemon instance;
        public static SessionDaemon getInstance()
        {
            if (instance == null)
            {
                instance = new SessionDaemon();
            }
            return instance;
        }

        public void Start()
        {
            SessionList.Instance.Load();
            WriteLog.AppInfo("SessionDaemon started!");
        }

        public void Stop()
        {
            SessionList.Instance.Save();
            WriteLog.AppInfo("SessionDaemon stopped!");
        }

        public UserSession GetUserSessionBySessionId(string sessionId)
        {
            return SessionList.Instance.GetSession(sessionId);
        }

        public UserSession CreateUserSession(string jobNumber, string userKey, int userType, string ipAddress)
        {
            SessionList.Instance.CleanUpTimeoutSession();
            UserSession us = SessionList.Instance.QuerySession(userKey, userType, ipAddress);
            if (us != null)
            {
                if ((userType == UserSessionType.WechatUser && us is WechatUserSession) ||
                    (userType == UserSessionType.NTUser && us is NTUserSession) ||
                    (userType == UserSessionType.DefaultType && us is UserSession))
                {
                    us.JobNumber = jobNumber;
                    //WriteLog.Info("UserSession Update:jobnumber=" + jobNumber + ",userKey=" + userKey + ",userType=" + userType + ",ipAddress=" + ipAddress);
                    return us;
                }
                SessionList.Instance.RemoveSessionByUserKey(userKey, userType);
            }
            if (userType == UserSessionType.WechatUser) us = new WechatUserSession();
            else if (userType == UserSessionType.NTUser) us = new NTUserSession();
            else us = new UserSession();
            //us = new WechatUserSession();
            us.UserKey = userKey;
            us.JobNumber = jobNumber;
            us.SessionId = System.Guid.NewGuid().ToString("N").ToUpper();//D=减号连接、N=无减号连接、B=D加大括号、P=D加括号
            us.IPAddress = ipAddress;
            us.createTime = DateTimeUtil.CurrentMillis;
            us.lastUpdate = us.createTime;
            us.tokenStart = 0;
            SessionList.Instance.AddSession(us);

            EventLog log = (us is WechatUserSession)?EventLog.WXUserSessionEvent(us.IPAddress, us.JobNumber, us.UserKey, us.SessionId):
                (us is NTUserSession)?EventLog.NTUserSessionEvent(us.IPAddress,us.JobNumber,us.UserKey, us.SessionId):
                EventLog.UserSessionEvent(us.IPAddress,us.JobNumber,us.UserKey,us.SessionId);
            int logresult = EventLogDAO.InsertEventLog(log);
            if (logresult <= 0) WriteLog.Error("Log event fail in CreateUserSession", null);
            //WriteLog.Info("UserSession Create:jobnumber="+jobNumber+",openID="+openID+",ipAddress="+ipAddress);
            return us;
        }

        public void RemoveUserSessionsByUserKeys(string[] userIds, int userType)
        {
            if (userIds == null || userIds.Length == 0) return;
            for (int i = 0; i < userIds.Length; i++)
            {
                SessionList.Instance.RemoveSessionByUserKey(userIds[i], userType);
            }
        }

    }

    /*
    [XmlInclude(typeof(UserSession))]
    [XmlInclude(typeof(NTUserSession))]
    [XmlInclude(typeof(WechatUserSession))]
    */
    public class SessionList
    {
        object WriteLocker = new object();
        private SessionList()
        {
            userSessionList = new Dictionary<string, UserSession>();
        }

        private static SessionList instance = null;
        public static SessionList Instance
        {
            get
            {
                if (instance == null)
                    instance = new SessionList();
                return instance;
            }
        }

        private Dictionary<string, UserSession> userSessionList;
        //private string sessionListXmlfile = HttpContext.Current.Server.MapPath("~/Log/") + "UserSessionList.xml";
        //private string sessionListJsonfile = HttpContext.Current.Server.MapPath("~/bin/") + "UserSessionList.json";
        private string sessionListDataFile = HttpContext.Current.Server.MapPath("~/bin/") + "UserSessionList.dat";

        private System.Timers.Timer SaveTimer = null;
        public void AddSession(UserSession session)
        {
            UserSession us = (UserSession)session;
            if (userSessionList == null) userSessionList = new Dictionary<string, UserSession>();
            userSessionList.Add(us.SessionId, us);
            ActiveSave();
        }

        public UserSession GetSession(string sessionId)
        {
            if (userSessionList == null) return null;
            if (userSessionList.ContainsKey(sessionId))
            {
                UserSession us = userSessionList[sessionId];
                if (DateTimeUtil.CurrentMillis - us.lastUpdate < SessionDaemon.SessionTimeout)
                {
                    us.lastUpdate = DateTimeUtil.CurrentMillis;
                    return us;
                }
            }
            return null;
        }

        public UserSession QuerySession(string userKey, int userType, string ipAddress)
        {
            var findRs = userSessionList.Where(us => (us.Value.UserKey == userKey && us.Value.UserType==userType && us.Value.IPAddress == ipAddress)).Take(1).ToList();
            if (findRs.Count > 0) return findRs[0].Value;
            return null;
        }

        public void CleanUpTimeoutSession()
        {
            if (userSessionList == null) return;
            if (userSessionList.Count > SessionDaemon.MaxSessionCapacity)
            {
                long now = DateTimeUtil.CurrentMillis;
                var timeoutList = userSessionList.Where(us => (now - us.Value.lastUpdate) > SessionDaemon.SessionTimeout).ToList();
                if (timeoutList.Count == 0) return;
                foreach (var item in timeoutList)
                {
                    userSessionList.Remove(item.Key);
                }
                WriteLog.Info(string.Format("Clean {0} timeout sessions!", timeoutList.Count));
            }
        }

        public void RemoveSessionByUserKey(string userKey,int userType)
        {
            foreach (var item in userSessionList.Where(us => us.Value.UserKey == userKey && us.Value.UserType == userType).ToList())
            {
                userSessionList.Remove(item.Key);
            }
            //sessionList.remove(x => x.OpenID == openID);
        }

        private void ActiveSave()
        {
            if (SaveTimer != null && SaveTimer.Enabled) return;
            if (SaveTimer == null)
            {
                SaveTimer = new System.Timers.Timer(SessionDaemon.MinIntervalOfSessionListSaving);
                SaveTimer.Elapsed += new ElapsedEventHandler(SaveAction);
            }
            SaveTimer.AutoReset = false; // fire only once
            SaveTimer.Enabled = true;
            SaveTimer.Start();
        }


        private void SaveAction(object sender, System.Timers.ElapsedEventArgs args)
        {
            if (SaveTimer != null)
            {
                Save();
            }
        }

        /*
        [XmlInclude(typeof(UserSession))]
        [XmlInclude(typeof(NTUserSession))]
        [XmlInclude(typeof(WechatUserSession))]
        */
        //[MethodImpl(MethodImplOptions.Synchronized)]
        public void Save()
        {
            /*
            if (File.Exists(sessionListXmlfile))
            {
                try
                {
                    DateTime ft = File.GetLastWriteTime(sessionListXmlfile);
                    string suffix = ft.ToString("yyyyMMddHHmmssfff", CultureInfo.InvariantCulture);
                    File.Move(sessionListXmlfile, Global.LogPath + "SessionList_" + suffix + ".xml");
                }
                catch (Exception e)
                {
                    WriteLog.Error("Session List File Move Error!", e);
                }
            }
            */
            //if (sessionList.Count <= 0) return;
            //以XML文件持久化對象數據
            /*
            try
            {
                var serializer = new XmlSerializer(typeof(List<UserSession>));
                using (var stream = File.OpenWrite(sessionListXmlfile))
                {
                    serializer.Serialize(stream, userSessionList.Values.ToList<UserSession>());
                }
            }
            catch (Exception e)
            {
                WriteLog.Error("Save Session List Fail!", e);
            }
            */
            //以JSON文件持久化對象數據
            /*
            StreamWriter strWriter = null;
            try
            {
                strWriter = new StreamWriter(sessionListJsonfile, false, Encoding.UTF8);//overwrite, not append
                strWriter.Write(JsonUtil<Dictionary<string, UserSession>>.JsonSerializerObject(userSessionList));
            }
            catch (Exception e)
            {
                WriteLog.Error("Save Session Map File Fail!", e);
            }
            finally
            {
                if (strWriter != null)
                {
                    try { strWriter.Flush(); strWriter.Close(); strWriter.Dispose(); }
                    catch (Exception ex) { WriteLog.Error("SessionMapFile.CloseWriter", ex); }
                }
            }
            */
            //以二進制文件持久化對象數據
            lock (typeof(SessionList))
            {
                try
                {
                    Object2FileUtil.WriteToBinaryFile<Dictionary<string, UserSession>>(sessionListDataFile, userSessionList);
                }
                catch (Exception ex)
                {
                    WriteLog.Error("Save SessionList Fail!", ex);
                }
            }
        }

        public void Load()
        {
            //以XML格式文件形式載入對象
            /*
            try
            {
                if (!File.Exists(sessionListXmlfile)) return;
                var serializer = new XmlSerializer(typeof(List<UserSession>));
                using (var stream = File.OpenRead(sessionListXmlfile))
                {
                    userSessionList.Clear();
                    var data = (List<UserSession>)(serializer.Deserialize(stream));
                    foreach (UserSession us in data)
                    {
                        userSessionList.Add(us.SessionId, us);
                    }
                    //sessionList.AddRange(data);
                }
            }
            catch (Exception e)
            {
                userSessionList = new Dictionary<string, UserSession>();
                WriteLog.Error("Load Session List Fail!", e);
            }
            */
            //以JSON格式文件形式載入對象
            /*
            StreamReader sr = null;
            try
            {
                sr = new StreamReader(sessionListJsonfile, Encoding.UTF8);
                //使用StreamReader类来读取文件
                sr.BaseStream.Seek(0, SeekOrigin.Begin);
                userSessionList = JsonUtil<Dictionary<string, UserSession>>.JsonDeserializeObject(sr.ReadToEnd());
            }
            catch (Exception ex)
            {
                WriteLog.Error("Load Session Map File Fail!", ex);
            }
            finally
            {
                if (sr != null)
                {
                    try { sr.Close(); sr.Dispose(); }
                    catch (Exception e) { WriteLog.Error("SessionMapFile.CloseReader", e); }
                }
                if (userSessionList==null) userSessionList = new Dictionary<string, UserSession>();
            }
            */
            //以二進制文件形式載入對象
            try
            {
                userSessionList = Object2FileUtil.ReadFromBinaryFile<Dictionary<string, UserSession>>(sessionListDataFile);
            }
            catch (Exception ex)
            {
                WriteLog.Error("Load SessionList Fail!", ex);
            }
            if (userSessionList == null) userSessionList = new Dictionary<string, UserSession>();
        }
    }


}
