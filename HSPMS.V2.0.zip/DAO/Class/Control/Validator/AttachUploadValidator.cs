﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LEO.Project.WXProposal.Data.Entity;
using LEO.Project.WXProposal.Data.DAO;
using LEO.Project.Tools;
using System.IO;
using LEO.Project.WXProposal.Validator;
using LEO.Project.WXProposal.Model.Session;

namespace LEO.Project.WXProposal.Control.Validator
{
    public class AttachUploadValidator
    {
        public static ValidateResult ValidateProposalDailyCount(UserSession us)
        {
            if (us == null || string.IsNullOrEmpty(us.JobNumber)) return ValidateResult.Result(false, -1, "未登记注册");
            int proposalCount = ProposalInfoDAO.GetTodayProposalCountByJobNumber(us.JobNumber);
            if (proposalCount >= SysConfig.MaxProposalCountByDaily)
            {
                return ValidateResult.Result(false, -2, string.Format("每天提案數量不能超過 {0} 個", SysConfig.MaxProposalCountByDaily));
            }
            return ValidateResult.Result(true, 0, null);
        }

        public static ValidateResult ValidateAttachUpload(UserSession us, HttpFileCollection upFiles)
        {
            if (us == null || string.IsNullOrEmpty(us.JobNumber)) return ValidateResult.Result(false, -1, "未登记注册");

            ValidateResult vr = null;
            string UploadPath = Path.Combine(HttpRuntime.AppDomainAppPath, SysConfig.Proposal_Attach_Path);
            //已上传附件大小計算
            List<AttachmentInfo> attachList = new List<AttachmentInfo>();
            int fileSizeSum = 0;
            if (us.UploadFilePaths != null && us.UploadFilePaths.Count > 0)
            {
                for (var i = 0; i < us.UploadFilePaths.Count; i++)
                {
                    AttachmentInfo attach = ProposalFileDAO.GetByFilePath(us.UploadFilePaths[i]);
                    if (attach != null)
                    {
                        attach.FileSize = (int)FileUtil.GetFileSize(Path.Combine(UploadPath, attach.FileDate.Value.ToString("yyyyMMdd") + '\\' + attach.FilePath));
                        attachList.Add(attach);
                        fileSizeSum += attach.FileSize;
                    }
                }
            }

            //单个文件不超过5MB
            long totalLenth = 0;
            int upCount = 0;
            if (upFiles.AllKeys.Any())
            {
                string[] keys = upFiles.AllKeys.ToArray<string>();
                /****** Validate Upload Content ******/
                foreach (string key in keys)
                {
                    // Get the uploaded file from the Files collection
                    var httpPostedFile = upFiles[key];
                    if (httpPostedFile != null)
                    {
                        if (httpPostedFile.ContentLength > SysConfig.MaxUploadFileLength)
                        {
                            vr = ValidateResult.Result(false, 1, string.Format("單個上傳文件大小不能超過 {0}", FileUtil.ConvertFileSize(SysConfig.MaxUploadFileLength)));
                            break;
                        }
                        totalLenth += httpPostedFile.ContentLength;
                        upCount++;
                    }
                }
            }
            if (vr==null && (upCount==0||totalLenth==0)) vr = ValidateResult.Result(false, 2, "未發現上傳文件內容！");

            //已上传附件是否已超限
            if (vr==null && (attachList.Count + upCount > SysConfig.MaxUploadFileCount || fileSizeSum + totalLenth > SysConfig.MaxUploadFileLengthByProposal))
            {
                vr = ValidateResult.Result(false, 3, string.Format("提案附件文件大小不能超過 {0}，數量不能超過 {1} 個", FileUtil.ConvertFileSize(SysConfig.MaxUploadFileLengthByProposal), SysConfig.MaxUploadFileCount));
            }

            //当日上传附件是否已经超限
            if (vr == null)
            {
                List<AttachmentInfo> flist = ProposalFileDAO.GetTodayProposalAttachListByJobNumber(us.JobNumber);
                fileSizeSum = 0;
                if (flist != null)
                {
                    foreach (AttachmentInfo att in flist)
                    {
                        att.FileSize = (int)FileUtil.GetFileSize(Path.Combine(UploadPath, att.FileDate.Value.ToString("yyyyMMdd") + '\\' + att.FilePath));
                        fileSizeSum += att.FileSize;
                    }
                }
                if (fileSizeSum + totalLenth > SysConfig.MaxUploadFileLengthByDaily)
                {
                    vr = ValidateResult.Result(false, 4, string.Format("每天上傳附件大小不能超過 {0}", FileUtil.ConvertFileSize(SysConfig.MaxUploadFileLengthByDaily)));
                }
            }
            if (vr==null) vr = ValidateResult.Result(true, 0, null);
            vr.ResultObject = attachList;
            return vr;
        }
    }
}
