﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LEO.Project.WXProposal.Validator;
using LEO.Project.Tools;
using LEO.Project.WXProposal.Model.Session;

namespace LEO.Project.WXProposal.Control.Validator
{
    public class SessionValidator
    {
        public static ValidateResult ValidateOperationTimer(UserSession us)
        {
            if (us == null || string.IsNullOrEmpty(us.JobNumber)) return ValidateResult.Result(false, -1, "未登记注册");
            if (us is WechatUserSession)
            {
                WechatUserSession wus = (WechatUserSession)us;
                long diffT = DateTimeUtil.CurrentMillis - wus.tokenStart;
                if (wus.tokenStart == 0) return ValidateResult.Result(false, -1, "當前登入無效! 请关闭窗口重新进入!");
                if (diffT < SysConfig.MinProposalSubmitInterval * 1000) return ValidateResult.Result(false, -1, "请勿频繁操作!");
                if (diffT > SysConfig.MaxProposalSubmitTokenTimeout * 1000) return ValidateResult.Result(false, -1, "操作等待时间过长，请关闭窗口重新进入!");
            }
            return ValidateResult.Result(true, 0, null);
        }
    }
}
