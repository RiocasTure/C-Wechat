﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections.Specialized;
using LEO.Project.Tools;
using System.Reflection;
using WebChatInterface.Class.Tencent;

namespace LEO.Project.WXProposal.Control
{
    public class SysConfig
    {
        public static readonly string HSPPW_Staff_Syn_ScheduleTime = "22:00";
        //public static readonly int MaxUploadFileLength = 5 * 1024 * 1024;
        public static readonly string Url_UserReg = "http://acc.leo.com.hk/01/webchat/pms/index.html";
        public static readonly string Url_ProposalInput = "http://acc.leo.com.hk/01/webchat/pms/step-1.html";
        public static readonly string Url_ProposalQuery = "http://acc.leo.com.hk/01/webchat/pms/list.html";
        public static readonly string Url_WXAuth = "http://acc.leo.com.hk/01/webchat/WXAuth.ashx";
        //public static readonly string HSPPW_Staff_Syn_ScheduleTime = "22:00";
        public static readonly string Proposal_Attach_Path = "../Intranet/SysAdmin/data/upload/";
        public static readonly int MaxUploadFileLength = 5 * 1024 * 1024;
        public static readonly int MaxUploadFileLengthByProposal = 10 * 1024 * 1024;
        public static readonly int MaxUploadFileLengthByDaily = 20 * 1024 * 1024;
        public static readonly int MaxUploadFileCount = 10;//单次上传文件不超过10个
        public static readonly int MaxProposalCountByDaily = 10;//每个帐号每天提交提案不超过10个
        public static readonly int MinProposalSubmitInterval = 60;//提交提案的最短时间间隔为60秒(1分钟)
        public static readonly int MaxProposalSubmitTokenTimeout = 600;//提交提案的Token的超时时间为600秒(10分钟)

        public static void InitAppSettings(NameValueCollection nvc)
        {
            var enu = nvc.GetEnumerator();
            while (enu.MoveNext())
            {
                string key = (string)enu.Current;
                string classField = null;
                Assembly assembly = null;
                if (!string.IsNullOrEmpty(key))
                {
                    if (key.StartsWith("SysConfig."))
                    {
                        classField = "LEO.Project.WXProposal.Control." + key;
                        assembly = typeof(SysConfig).Assembly;
                    }
                    else if (key.StartsWith("Account."))
                    {
                        classField = "WebChatInterface.Class.Tencent." + key;
                        assembly = typeof(Account).Assembly;
                    }
                    if (!string.IsNullOrEmpty(classField))
                    {
                        ReflectionHelper.SetFieldValue(assembly, classField, nvc[key]);
                    }
                }
            }
        }
    }
}
