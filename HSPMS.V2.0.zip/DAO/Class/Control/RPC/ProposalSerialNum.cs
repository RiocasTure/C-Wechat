﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Ipc;
using LEO.Project.Tools;
using System.IO.Pipes;
using System.IO;
using System.Threading;

namespace LEO.Project.WXProposal.Control.RPC
{
    public class ProposalSerialNum : MarshalByRefObject
    {
        private int iCount = 0;
        public int count()
        {
            iCount++;
            return iCount;
        }
    }

    public class ProposalSerialNumIPC
    {
        private static ProposalSerialNum serverIPC = null;
        private static bool serverReg = false;

        public static void RegServerIPC()
        {
            if (!serverReg)
            {
                IpcChannel serverchannel = new IpcChannel("ProposalChannel");
                ChannelServices.RegisterChannel(serverchannel, false);
                RemotingConfiguration.RegisterWellKnownServiceType(typeof(ProposalSerialNum), "ProposalSrv", WellKnownObjectMode.Singleton);
            }
        }

        public static ProposalSerialNum GetServerIPC()
        {
            if (serverIPC == null)
            {
                try
                {
                    IpcChannel tcc = new IpcChannel();
                    ChannelServices.RegisterChannel(tcc, false);
                    WellKnownClientTypeEntry remotEntry = new WellKnownClientTypeEntry(typeof(ProposalSerialNum), "ipc://ProposalChannel/ProposalSrv");
                    RemotingConfiguration.RegisterWellKnownClientType(remotEntry);
                }
                catch (Exception ex)
                {
                    WriteLog.Error("ProposalSerialNumIPC.GetServerIPC Exception", ex);
                }
                serverIPC = new ProposalSerialNum();
            }
            return serverIPC;
        }
    }

    public class ProposalSerialNumPipe
    {
        private static string pipeName = "proposalpipe";
        /*
        private Thread server;
        private static int iCount = 0;

        public ProposalSerialNumPipe()
        {
            server = new Thread(Process);
        }
        public void StartServer()
        {
            if (server != null) server.Start();
        }

        void Process()
        {
            Byte[] bytes;
            UTF8Encoding encoding = new UTF8Encoding();
            string message1 = "Named Pipe Message Example.";
            string message2 = "Another Named Pipe Message Example.";
            using (NamedPipeServerStream pipeStream = new
            NamedPipeServerStream(pipeName, PipeDirection.InOut, 1,
            PipeTransmissionMode.Message, PipeOptions.None))
            {
                pipeStream.WaitForConnection();

                // Let’s send two messages.
                bytes = encoding.GetBytes(message1);
                pipeStream.Write(bytes, 0, bytes.Length);
                bytes = encoding.GetBytes(message2);
                pipeStream.Write(bytes, 0, bytes.Length);

            }
        }

        public static string GetPipeMsg()
        {
            Decoder decoder = Encoding.UTF8.GetDecoder();
            Byte[] bytes = new Byte[10];
            Char[] chars = new Char[10];
            string message = "";
            using (NamedPipeClientStream pipeStream =
                    new NamedPipeClientStream(pipeName))
            {
                pipeStream.Connect();
                pipeStream.ReadMode = PipeTransmissionMode.Message;
                int numBytes;
                do
                {
                    do
                    {
                        numBytes = pipeStream.Read(bytes, 0, bytes.Length);
                        int numChars = decoder.GetChars(bytes, 0, numBytes, chars, 0);
                        message += new String(chars, 0, numChars);
                    } while (!pipeStream.IsMessageComplete);

                    decoder.Reset();
                } while (numBytes != 0);
                pipeStream.Close();
                pipeStream.Dispose();
            }
            return message;
        }
        */
    }

    public class NamedPipeListenServer
    {
        private static int iCount = 0;
        List<NamedPipeServerStream> _serverPool = new List<NamedPipeServerStream>();
        string _pipName = "test";
        public NamedPipeListenServer(string pipName)
        {
            _pipName = pipName;
        }

        /// <summary>
        /// 创建一个NamedPipeServerStream
        /// </summary>
        /// <returns></returns>
        protected NamedPipeServerStream CreateNamedPipeServerStream()
        {
            NamedPipeServerStream npss = new NamedPipeServerStream(_pipName, PipeDirection.InOut, 10);
            _serverPool.Add(npss);
            WriteLog.AppInfo("启动了一个NamedPipeServerStream " + npss.GetHashCode());
            return npss;
        }

        /// <summary>
        /// 销毁
        /// </summary>
        /// <param name="npss"></param>
        protected void DestroyObject(NamedPipeServerStream npss)
        {
            npss.Close();
            if (_serverPool.Contains(npss))
            {
                _serverPool.Remove(npss);
            }
            WriteLog.AppInfo("销毁一个NamedPipeServerStream " + npss.GetHashCode());
        }

        public void Run()
        {
            using (NamedPipeServerStream pipeServer = CreateNamedPipeServerStream())
            {
                pipeServer.WaitForConnection();
                WriteLog.AppInfo("建立一个连接 " + pipeServer.GetHashCode());

                Action act = new Action(Run);
                act.BeginInvoke(null, null);

                try
                {
                    bool isRun = true;
                    while (isRun)
                    {
                        string str = null;
                        StreamReader sr = new StreamReader(pipeServer);
                        while (pipeServer.CanRead && (null != (str = sr.ReadLine())))
                        {
                            ProcessMessage(str, pipeServer);

                            if (!pipeServer.IsConnected)
                            {
                                isRun = false;
                                break;
                            }
                        }

                        Thread.Sleep(50);
                    }
                }
                // Catch the IOException that is raised if the pipe is broken
                // or disconnected.
                catch (IOException e)
                {
                    WriteLog.Error("ERROR", e);
                }
                finally
                {
                    DestroyObject(pipeServer);
                }
            }

        }

        /// <summary>
        /// 处理消息
        /// </summary>
        /// <param name="str"></param>
        /// <param name="pipeServer"></param>
        protected virtual void ProcessMessage(string str, NamedPipeServerStream pipeServer)
        {
            // Read user input and send that to the client process.
            using (StreamWriter sw = new StreamWriter(pipeServer))
            {
                sw.AutoFlush = true;
                iCount++;
                sw.WriteLine("hello world " + str + "(" + iCount + ")");
            }
        }

        /// <summary>
        /// 停止
        /// </summary>
        public void Stop()
        {
            for (int i = 0; i < _serverPool.Count; i++)
            {
                var item = _serverPool[i];

                DestroyObject(item);
            }
        }
    }

    public class NamedPipeClient : IDisposable
    {
        string _serverName;
        string _pipName;
        NamedPipeClientStream _pipeClient;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serverName">服务器地址</param>
        /// <param name="pipName">管道名称</param>
        public NamedPipeClient(string serverName, string pipName)
        {
            _serverName = serverName;
            _pipName = pipName;

            _pipeClient = new NamedPipeClientStream(serverName, pipName, PipeDirection.InOut);

        }

        /// <summary>
        /// 查询
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public string Query(string request)
        {
            if (!_pipeClient.IsConnected)
            {
                _pipeClient.Connect(10000);
            }

            StreamWriter sw = new StreamWriter(_pipeClient);
            sw.WriteLine(request);
            sw.Flush();

            StreamReader sr = new StreamReader(_pipeClient);
            string temp;
            string returnVal = "";
            while ((temp = sr.ReadLine()) != null)
            {
                returnVal = temp;
                //nothing
            }
            return returnVal;
        }

        #region IDisposable 成员

        bool _disposed = false;
        public void Dispose()
        {
            if (!_disposed && _pipeClient != null)
            {
                _pipeClient.Dispose();
                _disposed = true;
            }
        }

        #endregion
    }

}
