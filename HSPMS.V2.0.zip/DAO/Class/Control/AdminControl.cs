﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LEO.Project.WXProposal.Data.Entity;
using LEO.Project.WXProposal.Data.DAO;
using LEO.Project.Tools;

namespace LEO.Project.WXProposal.Control
{
    public class AdminControl
    {
        public static string[] ValidUserRoles = new string[] { UserRole.Role_Super, UserRole.Role_Admin, UserRole.Role_Operator };
        public static string[] ValidAdminRoles = new string[] { UserRole.Role_Super, UserRole.Role_Admin };

        public static string GetCurrntNTUserRole(HttpContext httpContext)
        {
            string ntUser = HttpUtil.GetHttpContextNTName(HttpContext.Current);
            if (!string.IsNullOrEmpty(ntUser))
            {
                UserRole ur = UserRoleDAO.instance.GetUserRoleByUserID(ntUser);
                if (ur != null && !string.IsNullOrEmpty(ur.RoleName))
                    return ur.RoleName;
                //return UserRoleDAO.GetUserRoleByAccount(ntUser);
            }
            return UserRole.Role_None;
        }
        /*
        */

        public static UserRole GetCurrntNTUserURole(HttpContext httpContext)
        {
            string ntUser = HttpUtil.GetHttpContextNTName(HttpContext.Current);
            if (!string.IsNullOrEmpty(ntUser))
            {
                UserRole ur = UserRoleDAO.instance.GetUserRoleByUserID(ntUser);
                if (UserRole.CheckRoleIntersection(ur.RoleName, ValidAdminRoles))
                    ur.OrganOperators = null;
                return ur;
            }
            return null;
        }

    }
}
