﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WebChatInterface.WS;
using LEO.Project.WXProposal.Data.Entity;
using LEO.Project.WXProposal.Control;
using LEO.Project.Tools;
using LEO.Project.WXProposal.Data.DAO;
using System.IO;
using LEO.Project.WXProposal.Data.Imports;
using System.Text.RegularExpressions;
using LEO.Project.WXProposal.Model.QueryFilter;
using LEO.Project.WXProposal.Model.Pagination;
using LEO.Project.WXProposal.Data.Exports;
using System.Web;
using LEO.Project.WXProposal.Model.Session;
using LEO.Project.WXProposal.Validator;
using LEO.Project.WXProposal.Control.Validator;

namespace LEO.Project.WXProposal.Web
{
    public class FileHandler
    {
        public static readonly Regex AttachPatternRegex = new Regex(@"\/attach\/((?:19|20)\d\d)(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])\/[A-Fa-f0-9]{32}\/(.*?)$");
        public static readonly Regex PathPatternRegex = new Regex(@"((?:19|20)\d\d)(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])\/[A-Fa-f0-9]{32}\/(.*?)$");

        public static WSResult UploadProposalFileForUser(HttpContext context)
        {
            string savePath = Path.Combine(HttpRuntime.AppDomainAppPath, SysConfig.Proposal_Attach_Path);
            WSResult ws = WebHandler.CheckSession();
            if (ws.IsOK && ws.ResultObject != null && ws.ResultObject is UserSession)
            {
                UserSession us = (UserSession)ws.ResultObject;
                ws.ResultObject = null;
                ValidateResult vr = AttachUploadValidator.ValidateAttachUpload(us, HttpContext.Current.Request.Files);
                if (!vr.IsOK) return WSResult.Result(vr);
                List<AttachmentInfo> attachList =
                    (vr.ResultObject != null && vr.ResultObject is List<AttachmentInfo>) ?
                    (List<AttachmentInfo>)vr.ResultObject : new List<AttachmentInfo>();
                string[] keys = HttpContext.Current.Request.Files.AllKeys.ToArray<string>();
                /****** Save Upload Content ******/
                foreach (string key in keys)
                {
                    var httpPostedFile = HttpContext.Current.Request.Files[key];
                    if (httpPostedFile != null)
                    {
                        AttachmentInfo f = FileUtil.SaveUploadFile(savePath, httpPostedFile);
                        if (f != null)
                        {
                            f.FileSize = httpPostedFile.ContentLength;
                            int flag = ProposalFileDAO.Insert(f);
                            if (flag > 0)
                            {
                                attachList.Add(f);
                                us.UploadFilePaths.Add(f.FilePath);
                            }
                            else
                            {
                                ws = WSResult.Result(false, -1, "數據寫入失敗！");
                                WriteLog.Error(string.Format("數據寫入失敗，源文件名：{0}，另存為：{1}", f.FileName, f.FilePath), null);
                                break;
                            }
                        }
                        else
                        {
                            ws = WSResult.Result(false, -1, "文件保存失敗！");
                            WriteLog.Error(string.Format("文件保存失敗，文件名：{0}", httpPostedFile.FileName), null);
                            break;
                        }
                    }
                }
                if (ws.IsOK) ws = WSResult.Result(true, 1, "文件保存成功");
                ws.ResultObject = attachList;
            }
            return ws;
        }

        public static WSResult UploadProposalFileForAdmin(HttpContext context)
        {
            WSResult ws = null;
            if (context.Request.Files.AllKeys.Any())
            {
                //string savePath = context.Server.MapPath("~/SysAdmin/data/upload");
                string savePath = Path.Combine(HttpRuntime.AppDomainAppPath, SysConfig.Proposal_Attach_Path);
                string[] keys = context.Request.Files.AllKeys.ToArray<string>();
                long totalLenth = 0;
                /****** Validate Upload Content ******/
                foreach (string key in keys)
                {
                    // Get the uploaded file from the Files collection
                    var httpPostedFile = context.Request.Files[key];
                    if (httpPostedFile != null)
                    {
                        totalLenth += httpPostedFile.ContentLength;
                        // Validate the uploaded file
                        if (httpPostedFile.ContentLength > SysConfig.MaxUploadFileLength)
                        {
                            ws = WSResult.Result(false, -1, string.Format("上傳文件大小不能超過 {0:#.##} MB", (double)SysConfig.MaxUploadFileLength / (1024 * 1024)));
                            break;
                        }
                    }
                }
                List<AttachmentInfo> flst = new List<AttachmentInfo>();
                if (ws == null)
                {
                    /****** Save Upload Content ******/
                    foreach (string key in keys)
                    {
                        var httpPostedFile = context.Request.Files[key];
                        if (httpPostedFile != null)
                        {
                            AttachmentInfo f = FileUtil.SaveUploadFile(savePath, httpPostedFile);
                            if (f != null)
                            {
                                f.FileSize = httpPostedFile.ContentLength;
                                int flag = ProposalFileDAO.Insert(f);
                                if (flag > 0) flst.Add(f);
                                else
                                {
                                    ws = WSResult.Result(false, -1, string.Format("文件另存失敗，源文件名：{0}，另存為：{1}", f.FileName, f.FilePath));
                                    break;
                                }
                            }
                            else
                            {
                                ws = WSResult.Result(false, -1, string.Format("文件保存失敗，文件名：{0}", httpPostedFile.FileName));
                                break;
                            }
                        }
                    }
                }
                if (ws == null && flst.Count > 0)
                {
                    ws = WSResult.Result(true, 1, "文件保存成功");
                    ws.ResultObject = flst;
                }
            }
            if (ws == null) ws = WSResult.Result(false, 0, "未發現上傳文件內容！");
            return ws;
        }

        public static WSResult UploadEmployeeExcelForAdmin(HttpContext context)
        {
            WSResult ws = null;
            string secureCode = context.Request.Params["iUploadCode"];
            if (string.IsNullOrEmpty(secureCode)) ws = WSResult.Result(false, -1, "安全密碼不能為空！");
            else
            {
                UserRole urole = UserRoleDAO.instance.GetUserRoleByUserID(HttpUtil.GetHttpContextNTName(context));
                if (urole == null || (!UserRole.CheckRole(urole.RoleName, UserRole.Role_Super) && !UserRole.CheckRole(urole.RoleName, UserRole.Role_DBA)))
                    ws = WSResult.Result(false, -1, "Permission Deny!");
                else if (!urole.CheckSecureCode(secureCode)) ws = WSResult.Result(false, -1, "安全密碼錯誤！");
                else
                {
                    if (context.Request.Files.AllKeys.Any())
                    {
                        string savePath = context.Server.MapPath("~/SysAdmin/data/upload/tmp/" + StringUtils.RandomString());
                        string key = context.Request.Files.AllKeys.ToArray<string>()[0];
                        /****** Validate Upload Content ******/
                        // Get the uploaded file from the Files collection
                        var httpPostedFile = context.Request.Files[key];
                        if (httpPostedFile != null)
                        {
                            // Validate the uploaded file
                            if (httpPostedFile.ContentLength > SysConfig.MaxUploadFileLength)
                            {
                                ws = WSResult.Result(false, -1, string.Format("上傳文件大小不能超過 {0:#.##} MB", (double)SysConfig.MaxUploadFileLength / (1024 * 1024)));
                            }
                            else
                            {
                                string saveFilePath = FileUtil.SaveUploadBinFile(savePath, httpPostedFile);
                                if (saveFilePath != null)
                                {
                                    int counts = DataImporter.ImportEmployeeData(saveFilePath);
                                    //FileUtil.ClearFileData(saveFilePath);
                                    ws = WSResult.Result(true, 1, "資料上傳成功，共 " + counts + " 條記錄被更新！");
                                }
                                else
                                {
                                    ws = WSResult.Result(false, -1, string.Format("文件上傳失敗，文件名：{0}", httpPostedFile.FileName));
                                }
                            }
                        }
                    }
                }
            }
            if (ws == null) ws = WSResult.Result(false, 0, "未發現上傳文件內容！");
            return ws;
        }

        public static void DownloadFileForAdmin(HttpContext context)
        {
            //string path = "/attach/20160127/2b9bd21368f24147b33ae355f0e831b7/portfolio_seatacshuttle_dispatch.png";
            //Regex pattern = new Regex(@"^\/attach\/((?:19|20)\d\d)(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])\/[A-Fa-f0-9]{32}\/(.*?)$");
            string path = context.Request.Params["path"];
            //WriteLog.Info("Download:"+path);
            if (!string.IsNullOrEmpty(path) && PathPatternRegex.IsMatch(path))
            {
                Regex regex = new Regex("/");
                string[] fds = regex.Split(path);
                if (fds.Length == 3)
                {
                    string filePath = Path.Combine(HttpContext.Current.Server.MapPath("~/SysAdmin/data/upload/"), fds[fds.Length - 3] + '\\' + fds[fds.Length - 2]);
                    //WriteLog.Info(filePath + ":" + File.Exists(filePath));
                    if (File.Exists(filePath))
                    {
                        //FileUtil.DownloadFile(filePath, fds[fds.Length - 1]);
                        FileUtil.DownloadLargeFile(filePath, fds[fds.Length - 1]);
                        return;
                    }
                }
            }
            //context.Response.StatusCode = 404;
            context.Response.ContentType = "text/plain";
            context.Response.Write("404 Not Found!");
        }

        public static void ExportReportExcelForAdmin(HttpContext context, string action)
        {
            string filterArr = context.Request.Params["filterArr"];
            ProposalFilter f = null;
            try
            {
                if (!string.IsNullOrEmpty(filterArr))
                    f = JsonUtil<ProposalFilter>.JsonDeserializeObject(filterArr);
            }
            catch (Exception ex)
            {
                WriteLog.Error(string.Format("Export Proposal Report To Excel For Admin Error:filterArr={0}", filterArr), ex);
            }

            if (f == null) f = new ProposalFilter();
            /*
            DateTime? dtb = DateTimeUtil.ParseDateTime(DateTimeUtil.FormatYMD, f.DateBegin);
            DateTime? dte = DateTimeUtil.ParseDateTime(DateTimeUtil.FormatYMD, f.DateEnd);
            */
            f.WebFormOrganize();

            PageList pl = new PageList();//每頁10條記錄
            pl.PageSize = 0;
            pl.PageIndex = 1;
            UserRole ur = AdminControl.GetCurrntNTUserURole(HttpContext.Current);
            if (action == "proposal-q")
            {
                ProposalInfoDAO.PaginationQueryForAdmin(ur, f, pl, true);
                Dictionary<string, object> dict = new Dictionary<string, object>();
                dict.Add("ProposalList", pl.PageData);
                dict.Add("QueryTimestamp", DateTime.Now.ToString(DateTimeUtil.FormatDMYHM));
                /*
                f.DateBegin = dtb.HasValue ? dtb.Value.ToString(DateTimeUtil.FormatDMY) : "";
                f.DateEnd = dte.HasValue ? dte.Value.ToString(DateTimeUtil.FormatDMY) : "";
                */
                dict.Add("Filter", f);
                string urole = AdminControl.GetCurrntNTUserRole(HttpContext.Current);
                if (UserRole.CheckRole(urole, UserRole.Role_Super) || UserRole.CheckRole(urole, UserRole.Role_Admin))
                    ExcelExporter.ExportByTemplate("proposal-query-audit.xlsx", dict, "提案內容匯出報表.xlsx");
                else
                    ExcelExporter.ExportByTemplate("proposal-query.xlsx", dict, "提案內容匯出報表.xlsx");
                return;
            }
            else if (action == "proposal-sum")
            {
                ProposalInfoDAO.PaginationQueryProposalEmpSummaryForAdmin(ur, f, pl);
                ProposalInfoDAO.FillProposalEmpSumNumsForAdmin(ur, f, pl);
                Dictionary<string, object> dict = new Dictionary<string, object>();
                dict.Add("ProposalSumList", pl.PageData);
                dict.Add("QueryTimestamp", DateTime.Now.ToString(DateTimeUtil.FormatDMYHM));
                /*
                f.DateBegin = dtb.HasValue ? dtb.Value.ToString(DateTimeUtil.FormatDMY) : "";
                f.DateEnd = dte.HasValue ? dte.Value.ToString(DateTimeUtil.FormatDMY) : "";
                */
                dict.Add("Filter", f);
                ExcelExporter.ExportByTemplate("proposal-summary.xlsx", dict, "個人匯總提案數量報表.xlsx");
                return;
            }
        }

    }
}
