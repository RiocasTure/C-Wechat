﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LEO.Project.Tools;
using System.Web;
using LEO.Project.WXProposal.Model.Session;
using LEO.Project.WXProposal.Control;
using WebChatInterface.WS;
using WebChatInterface.Class.Tencent.MsgCode;
using System.IO;
using WebChatInterface.Class.Tencent;
using WebChatInterface.Class.Tencent.WXMsg.Receive;
using WebChatInterface.Class.Tencent.WXMsg.Response;
using WebChatInterface.Class.Tencent.WXMsg.Receive.Event;
using LEO.Project.WXProposal.Validator;
using LEO.Project.WXProposal.Control.Validator;
using LEO.Project.WXProposal.Data.Entity;
using LEO.Project.WXProposal.Data.DAO;
using LEO.Project.WXProposal.Model.Pagination;
using LEO.Project.WXProposal.Model.QueryFilter;
using System.Text.RegularExpressions;
using LEO.Project.WXProposal.Data.Exports;
using LEO.Project.WXProposal.Data.Imports;
using JsonView;

namespace LEO.Project.WXProposal.Web
{
    public class WebHandler
    {
        public static WSResult CheckSession()
        {
            string ip = HttpUtil.GetRequestIPAddress(HttpContext.Current.Request);
            HttpCookie cookie = HttpContext.Current.Request.Cookies["AuthSessionID"];
            if (cookie != null)
            {
                string sessionId = cookie.Value;
                UserSession us = SessionDaemon.getInstance().GetUserSessionBySessionId(sessionId);
                if (us != null)
                {
                    WSResult ws = null;
                    if (string.IsNullOrEmpty(us.JobNumber)) ws = WSResult.Result(false, -3, "Account not registed!");
                    else ws = WSResult.Result(true, 0, "Wechat User OK!");
                    ws.ResultObject = us;
                    return ws;
                }
            }
            /**先檢查是否NT登錄用戶*/
            string ntUserName = HttpUtil.GetHttpContextNTFullName(HttpContext.Current);
            WriteLog.Info("NTUserName:" + ntUserName);
            if (!string.IsNullOrEmpty(ntUserName))
            {
                UserSession us = SessionDaemon.getInstance().CreateUserSession("", ntUserName, UserSessionType.NTUser, ip);
                cookie = new HttpCookie("AuthSessionID", us.SessionId);
                cookie.Expires = DateTime.Now.AddMilliseconds(SessionDaemon.SessionTimeout);
                HttpContext.Current.Response.Cookies.Add(cookie);
                WSResult ws = WSResult.Result(true, 0, "NT User OK!");
                ws.ResultObject = us;
                return ws;
                //return WSResult.Result(false, -1, "NT User Invalid!");
            }
            else
            {
                //return WSResult.Result(false, -1, "Session expired!");
                return WSResult.Result(false, -2, "No session found!");
            }
            /*
            else
            {
                UserSession us = SessionDaemon.getInstance().CreateUserSession("5203724", "o_GR4wJi8mvZNZkJUzFUcxfA2Og0", UserSessionType.WechatUser, ip);
                cookie = new HttpCookie("AuthSessionID", us.SessionId);
                HttpContext.Current.Response.Cookies.Add(cookie);
                WSResult ws = WSResult.Result(true, 0, "Session Valid.");
                ws.ResultObject = us;
                return ws;
            }
            */
        }

        //取客户端IP
        public static string GetUserIP(HttpRequest Request)
        {
            string userIP;
            if (Request.ServerVariables["HTTP_VIA"] == null)
            {
                userIP = Request.UserHostAddress;
            }
            else
            {
                userIP = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            }
            return userIP;
        }

        public static WSResult RegJobNumber(string jobNum, string fullName, string idSuffix, string mobile, string next)
        {
            if (string.IsNullOrEmpty(jobNum) || string.IsNullOrEmpty(fullName) || string.IsNullOrEmpty(idSuffix))
                return WSResult.Result(false, -3, "Parameter Invalid!");
            WSResult ws = CheckSession();
            if (ws.ResultObject != null && ws.ResultObject is UserSession)
            {
                if (ws.ResultObject is WechatUserSession)
                {
                    WechatUserSession us = (WechatUserSession)ws.ResultObject;
                    if (string.IsNullOrEmpty(us.JobNumber))
                    {
                        WXUserInfo wxu = WXUserInfoDAO.GetWXUserInfoByOpenId(us.OpenID);
                        if (wxu == null) return WSResult.Result(false, 0, "WebChat user not existed!");
                        if (!string.IsNullOrEmpty(wxu.JobNumber))
                        {
                            if (wxu.JobNumber == jobNum) return WSResult.Result(true, 1, "Register duplicated!");
                            return WSResult.Result(false, 0, "WebChat user is registered by other jobnumber!");
                        }
                        Employee emp = EmployeeDAO.GetEmployeeByJobNumber(jobNum);
                        //if (emp == null || emp.FullName != ChineseConvert.ToTraditional(fullName) || emp.IDNumSuffix != idSuffix)
                        if (emp == null || !ChineseConvert.CheckChineseMatch(emp.FullName,fullName) || emp.IDNumSuffix.ToUpper() != idSuffix.ToUpper())
                                return WSResult.Result(false, -4, "抱歉!您输入的工号/姓名/身份证后6位信息不正确！");
                        if (string.IsNullOrEmpty(mobile) || !RegValid.IsMobile(mobile))
                            return WSResult.Result(false, -4, "抱歉!請输入正确的手机号码！");
                        if (emp.Status != EmployeeStatus.Valid)
                            return WSResult.Result(false, -5, "抱歉!您输入的工号無效！");
                        wxu.JobNumber = jobNum;
                        int flag = WXUserInfoDAO.UpdateWXUserInfo(wxu, mobile);
                        if (flag > 0)
                        {
                            us.JobNumber = jobNum;
                            us = (WechatUserSession)SessionDaemon.getInstance().CreateUserSession(jobNum, us.OpenID, UserSessionType.WechatUser, us.IPAddress);
                            //if (!string.IsNullOrEmpty(next) && next == "") us.tokenStart = DateTimeUtil.CurrentMillis;
                            us.tokenStart = DateTimeUtil.CurrentMillis;
                            return WSResult.Result(true, 1, "登记成功!");
                        }
                        else return WSResult.Result(true, -6, "抱歉！因系统繁忙，暂时未能处理您的登记请求。");
                    }
                    else
                    {
                        if (us.JobNumber == jobNum) return WSResult.Result(true, 1, "Register duplicated for twice!");
                        return WSResult.Result(false, 0, "JobNumber existed!");
                    }
                }
                else return WSResult.Result(false, 0, "No need to reg jobnumber!");
            }
            else
            {
                return ws;
            }
        }

        public static WSResult SubmitProposal(string dataArr, string fileArr, string uJobNum, string uName)
        {
            try
            {
                //string category, string title, string desc, string advice, string uJobNum, string uName, string soNum, string itemName, string ordQty, string eqId, string eqName, string workerNow, string workerAfter, string effNow, string effAfter, string dpRateNow, string dpRateAfter, string progress, string otherImprove
                WSResult ws = CheckSession();
                if (ws.IsOK && ws.ResultObject != null && ws.ResultObject is UserSession)
                {
                    UserSession us = (UserSession)ws.ResultObject;
                    ValidateResult vr = AttachUploadValidator.ValidateProposalDailyCount(us);
                    if (!vr.IsOK) return WSResult.Result(vr);
                    vr = SessionValidator.ValidateOperationTimer(us);
                    if (!vr.IsOK) return WSResult.Result(vr);
                    ProposalInfo pi = JsonUtil<ProposalInfo>.JsonDeserializeObject(dataArr);
                    pi.FormDate = DateTime.Now;
                    pi.SubmitTime = DateTime.Now;
                    vr = ProposalInputValidator.ValidateInputData(us, pi, fileArr, uJobNum, uName);
                    if (!vr.IsOK) return WSResult.Result(vr);
                    pi.Number = ProposalInfoDAO.GenerateSerialNumber();
                    pi.Status = ProposalStatus.Received;
                    int result = ProposalInfoDAO.SaveProposalInfo(pi);
                    if (result > 0)
                    {
                        if (us.UploadFilePaths != null) us.UploadFilePaths.Clear();
                        return WSResult.Result(true, 1, pi.Number);
                    }
                    return WSResult.Result(false, -1, "抱歉！您的提案资料未能提交成功！");
                }
                else ws.ResultObject = null;
                return ws;
            }
            catch (Exception ex)
            {
                WriteLog.Error("SubmitProposal Exception", ex);
                return WSResult.Result(false, -1, "系統處理異常！請聯繫GISS(2955)。");
            }
        }

        /*
        public string UploadFile()
        {
            WSResult ws = Handler.CheckSession(Context.Request);
            if (ws.IsOK && ws.ResultObject != null && ws.ResultObject is UserSession)
            {
                UserSession us = (UserSession)ws.ResultObject;
                try
                {
                    var Request = Context.Request;
                    var length = Request.ContentLength;
                    if (length == 0)
                    {
                        return JsonUtil<WSResult>.JsonSerializerObject(WSResult.Result(false, -1, "上传内容为空"));
                    }
                    else if (length > SysConfig.MaxUploadFileLength)
                    {
                        return JsonUtil<WSResult>.JsonSerializerObject(WSResult.Result(false, -1, "单次上传的文件大小不能超过" + FileUtil.ConvertFileSize(SysConfig.MaxUploadFileLength) + "！"));
                    }
                    var bytes = new byte[length];
                    Request.InputStream.Read(bytes, 0, length);
                    var fileName = Request.Headers["X-File-Name"];
                    var fileSize = Request.Headers["X-File-Size"];
                    var fileType = Request.Headers["X-File-Type"];

                    string picName = string.Empty;
                    string localPath = Path.Combine(HttpRuntime.AppDomainAppPath, "Upload");
                    string ex = Path.GetExtension(fileName);
                    picName = DateTimeUtil.CurrentMillis.ToString() + ex;
                    AttachmentInfo fi = new AttachmentInfo();
                    fi.RelatedKey = picName;
                    fi.FileName = picName;
                    fi.FilePath = "/Upload/";
                    fi.FileSize = length;
                    string picUrl = fi.FilePath + picName;
                    if (!Directory.Exists(localPath))
                    {
                        Directory.CreateDirectory(localPath);
                    }
                    // save the file.
                    var fileStream = new FileStream(Path.Combine(localPath, picName), FileMode.Create, FileAccess.ReadWrite);
                    fileStream.Write(bytes, 0, length);
                    fileStream.Close();
                    ws.ResultObject = JsonUtil<AttachmentInfo>.JsonSerializerObject(fi);
                }
                catch (Exception ex)
                {
                    WriteLog.Error("ProposalWS.UploadFiles() Exception", ex);
                    ws.IsOK = false;
                    ws.ResultObject = WriteLog.FlattenException(ex);
                }
            }else ws.ResultObject = null;
            return JsonUtil<WSResult>.JsonSerializerObject(ws);
        }
        */

        public static WSResult QueryProposals(string keyword, string dateBegin, string dateEnd, string status, int pageIndex)
        {
            WSResult ws = CheckSession();
            if (ws.IsOK && ws.ResultObject != null && ws.ResultObject is UserSession)
            {
                UserSession us = (UserSession)ws.ResultObject;
                string openID = (us is WechatUserSession) ? ((WechatUserSession)us).OpenID : null;
                if (!string.IsNullOrEmpty(us.JobNumber))
                {
                    PageList pl = new PageList();//每頁10條記錄
                    pl.PageSize = 10;
                    pl.PageIndex = pageIndex;
                    DateTime? dtb = DateTimeUtil.ParseDateTime(DateTimeUtil.FormatYMD, dateBegin);
                    DateTime? dte = DateTimeUtil.ParseDateTime(DateTimeUtil.FormatYMD, dateEnd);
                    ProposalInfoDAO.PaginationQuery(
                        string.IsNullOrEmpty(keyword) ? "" : keyword.Trim(),
                        us.JobNumber,
                        openID,//us.OpenID, 
                        dtb.HasValue ? dtb.Value.ToString(DateTimeUtil.FormatYMD) : "",
                        dte.HasValue ? dte.Value.ToString(DateTimeUtil.FormatYMD) : "",
                        string.IsNullOrEmpty(status) ? "" : status.Trim(), pl);
                    object[] arr = pl.PageData.ToArray();
                    pl.PageData.Clear();
                    for (int i = 0; i < arr.Length; i++)
                    {
                        if (arr[i] is ProposalInfo)
                        {
                            ProposalInfo pi = (ProposalInfo)arr[i];
                            if ((string.IsNullOrEmpty(openID) || (pi.WXOpenID == openID)) && pi.AuthorJobNumber == us.JobNumber)
                            {
                                pl.PageData.Add(ProposalView.Copy((ProposalInfo)arr[i]));
                            }
                        }
                    }
                    ws.ResultObject = pl;
                    return ws;
                }
            }
            //ws.ResultObject = null;
            return ws;
            /*
            WSResult ws = WSResult.Result(true, 0, "Session Valid.");
            PageList pl = new PageList();//每頁10條記錄
            pl.PageSize = 10;
            pl.PageIndex = pageIndex;
            ProposalInfoDAO.PaginationQuery(keyword, "3100150", "o_GR4wLznJGryPXgWGOEvMUFR0uo", dateBegin, dateEnd, status, pl);
            object[] arr = pl.PageData.ToArray();
            pl.PageData.Clear();
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] is ProposalInfo)
                {
                    pl.PageData.Add(ProposalView.Copy((ProposalInfo)arr[i]));
                }
            }
            ws.ResultObject = pl;
            return ws;
            */
        }

        public static WSResult QuerySummary()
        {
            WSResult ws = CheckSession();
            if (ws.IsOK && ws.ResultObject != null && ws.ResultObject is UserSession)
            {
                UserSession us = (UserSession)ws.ResultObject;
                Dictionary<string, string> sumDict = ProposalInfoDAO.UserSummary(us.JobNumber);
                ws.ResultObject = sumDict;
            }
            return ws;
        }


    }
}
