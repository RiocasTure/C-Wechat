﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LEO.Project.WXProposal.Validator
{
    public class ValidateResult
    {
        public bool IsOK { get; set; }
        public int ErrCode { get; set; }
        public string SysMsg { get; set; }
        public Object ResultObject { get; set; }

        public static ValidateResult Result(bool isOK, int errCode, string msg)
        {
            ValidateResult result = new ValidateResult();
            result.IsOK = isOK;
            result.ErrCode = errCode;
            result.SysMsg = msg;
            return result;
        }
    }
}
