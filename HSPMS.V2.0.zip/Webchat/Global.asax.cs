﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Web.Configuration;
//using System.Xml.Linq;
using System.IO;
using System.Text;
using LEO.Project.WXProposal.Control;
using LEO.Project.Tools;
using LEO.Project.WXProposal.Data.DAO;
using System.Reflection;

namespace LEO.Project.WXProposal
{
    public class Global : System.Web.HttpApplication
    {
        private static string logpath = null;
        public static string LogPath
        {
            get
            {
                return logpath;
            }
        }

        private static bool AppRunning = false;

        private void SaveAndUnload(object sender, EventArgs e)
        {
            if (AppRunning)
            {
                SessionDaemon.getInstance().Stop();
                LogAppInfo("SessionDaemon stopped!");
                AppRunning = false;
            }
            LogAppInfo("Save And Unload OK!");
        }

        protected void Application_Start(object sender, EventArgs e)
        {
            SqlHelper.ConnectionString = ConfigurationManager.ConnectionStrings["TiAnDB"].ToString().Trim();
            SqlHelper.CommandTimeout = Convert.ToInt32(ConfigurationManager.AppSettings["CommandTimeout"]);
            SysConfig.InitAppSettings(ConfigurationManager.AppSettings);
            logpath = HttpContext.Current.Server.MapPath("~/Log/");
            //AppDomain.CurrentDomain.DomainUnload += ApplicationEnd;
            AppDomain.CurrentDomain.ProcessExit += SaveAndUnload;
            SessionDaemon.getInstance().Start();
            LogAppInfo("SessionDaemon started!");
            AppRunning = true;
        }

        protected void Session_Start(object sender, EventArgs e)
        {
            //LogAppInfo("Session_Start");
        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {
            //LogAppInfo("Application_BeginRequest");
            /*
            HttpApplication application = (HttpApplication)sender;
            if (application.Request.Path.StartsWith("/webchat/WS/Proposal.asmx"))
            {
            }
            else
            {
                if (!application.Request.IsAuthenticated)
                {
                    HttpContext.Current.User.Identity.Name
                }
            }
            */
        }

        protected void Application_EndRequest(object sender, EventArgs e)
        {
            HttpApplication application = (HttpApplication)sender;

            if (application.Response.StatusCode != 401 || !application.Request.IsAuthenticated) return;

            var customErrors = (CustomErrorsSection)ConfigurationManager.GetSection("system.web/customErrors");

            var accessDeniedPath = customErrors.Errors["401"] != null ? customErrors.Errors["401"].Redirect : customErrors.DefaultRedirect;
            if (string.IsNullOrEmpty(accessDeniedPath))
                return; // Let other code handle it (probably IIS).

            application.Response.ClearContent();
            application.Server.Execute(accessDeniedPath);
            //Response.Redirect(accessDeniedPath);
            HttpContext.Current.Server.ClearError();
        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {
            //LogAppInfo("Application_AuthenticateRequest");
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            // Get the exception object.
            Exception exc = Server.GetLastError();
            WriteLog.Error("URL Error:" + HttpContext.Current.Request.Url.ToString(), exc);

            // Clear the error from the server
            Server.ClearError();

            //LogAppInfo("Application_Error");
        }

        protected void Session_End(object sender, EventArgs e)
        {
            //LogAppInfo("Session_End");
        }

        protected void Application_End(object sender, EventArgs e)
        {
            SaveAndUnload(sender, e);
            //LogAppInfo("Application_End");
        }

        public static void LogAppInfo(string strText)
        {
            WriteLog.AppInfo(strText);
            /*
            if (string.IsNullOrEmpty(strText)) return;
            StreamWriter strWriter = new StreamWriter(logpath + "AppInfo.log", true, Encoding.UTF8);
            string str = DateTime.Now + " " + strText;
            strWriter.WriteLine(str);
            strWriter.Close();
            */
        }

    }

}