﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;
//using Newtonsoft.Json.Linq;
using System.Data;
using WebChatInterface.Class.Tencent;
using LEO.Project.WXProposal.Control;
using LEO.Project.Tools;
using LEO.Project.WXProposal.Model.Session;
using LEO.Project.WXProposal.Data.Imports;

namespace WebChatInterface
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //string action = Request.Form["action"]; //post
            //string action = Request.QueryString["action"]; //get
            string action = Request.Params["action"];
            if (!string.IsNullOrEmpty(action))
            {
                if (action == "menu")
                {
                    string token = WeiXinUtils.GetAccessToken();
                    if (token == null)
                    {
                        Response.Write("AccessToken Error!");
                        return;
                    }
                    string menuFile = HttpContext.Current.Server.MapPath("~/menu.json");
                    string json = WeiXinUtils.ReadTextFromFile(menuFile);
                    string menuPostUrl = Account.Url_CreateMenu.Replace("${ACCESS_TOKEN}", token);
                    string postResponse = HttpUtil.HttpPost(menuPostUrl, json, Encoding.UTF8, null);
                    if (!string.IsNullOrEmpty(postResponse))
                    {
                        WeiXinUtils.LogJson(postResponse);
                    }
                }
                else if (action == "auth")
                {
                    string next = Request.Params["next"];
                    if (string.IsNullOrEmpty(next)) next = "submit"; //默认为提交提案
                    HttpCookie cookie = Request.Cookies["AuthSessionID"];
                    StringBuilder sb = new StringBuilder();
                    if (cookie != null)
                    {
                        string sessionId = cookie.Value;
                        sb.Append("Get SessionID from cookie: ").Append(sessionId).Append('\n');

                        UserSession us = SessionDaemon.getInstance().GetUserSessionBySessionId(sessionId);
                        if (us != null && us is WechatUserSession)
                        {
                            WechatUserSession wus = (WechatUserSession)us;
                            sb.Append("Get UserSession: ").Append("JobNumber=").Append(us.JobNumber).Append(",OpenId=").Append(wus.OpenID).Append(",IP=").Append(us.IPAddress).Append('\n');
                            WXAuth.UrlRedirect(us, next);
                            /*
                            if (string.IsNullOrEmpty(us.JobNumber))
                            {
                                string act = (!string.IsNullOrEmpty(next) && next == "query") ? "query" : "submit";//默认为提交提案
                                HttpContext.Current.Response.Redirect("http://acc.leo.com.hk/01/webchat/pms/index.html" +"?next=" + act, true);
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(next) && next == "query")
                                    HttpContext.Current.Response.Redirect("http://acc.leo.com.hk/01/webchat/pms/list.html", true);
                                else
                                    HttpContext.Current.Response.Redirect("http://acc.leo.com.hk/01/webchat/pms/step-1.html", true);
                            }
                            */
                            WriteLog.Info(sb.ToString());
                            return;
                        }
                        sb.Append("No UserSession Found!").Append('\n');
                    }
                    string redirectUrl = HttpUtility.UrlEncode(SysConfig.Url_WXAuth);//Server.UrlEncode
                    /**
                     * snsapi_base:不弹出授权页面直接跳转，仅能获取openid；
                     * snsapi_userinfo:弹出授权页面，可通过openid获取昵称、性别、所在地，即使未关注，只要用户授权，也能获取
                     */
                    string scope = "snsapi_userinfo";
                    string state = next;// "STATE";
                    string authUrl = string.Format(
                        "https://open.weixin.qq.com/connect/oauth2/authorize?appid={0}&redirect_uri={1}&response_type={2}&scope={3}&state={4}#wechat_redirect",
                        Account.AppID,redirectUrl,"code",scope,state);
                    sb.Append("Redirect WX Authorize...");
                    //WriteLog.Info(sb.ToString());
                    Response.Redirect(authUrl,true);
                }
            }
            else
            {
                //bool c = ChineseConvert.CheckChineseMatch("陳梅蘭", "陈梅兰");
                //bool d = ChineseConvert.CheckChineseMatch("李玉容", "李玉容");
                Response.Write("Welcome!");
            }
            Response.End();
        }

    }

}
