﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Text;
using System.Web.Security;
using LEO.Project.Tools;
using WebChatInterface.Class.Tencent.WXMsg.Receive;
using WebChatInterface.Class.Tencent.WXMsg.Response;
using WebChatInterface.Class.Tencent.WXMsg.Receive.Event;
using WebChatInterface.Class.Tencent.MsgCode;
using WebChatInterface.Class.Tencent;
using WebChatInterface.WS;
using LEO.Project.WXProposal.Control;
using LEO.Project.WXProposal.Data.Entity;
using LEO.Project.WXProposal.Data.DAO;
using LEO.Project.WXProposal.Model.Session;
using LEO.Project.WXProposal.Control.Validator;
using LEO.Project.WXProposal.Validator;
using LEO.Project.WXProposal.Web;

namespace WebChatInterface
{
    public class Handler : IHttpHandler
    {
        public void ProcessRequest(HttpContext context)
        {
            string sMsgSig = context.Request.Params["msg_signature"];
            string sTimeStamp = context.Request.Params["timestamp"];
            string sNonce = context.Request.Params["nonce"];
            if (!string.IsNullOrEmpty(sMsgSig) && !string.IsNullOrEmpty(sTimeStamp) && !string.IsNullOrEmpty(sNonce))
            {
                if (HttpContext.Current.Request.HttpMethod.ToUpper() == "POST")
                {
                    WXMP_Event_Response(context, sMsgSig, sTimeStamp, sNonce);
                    return;
                }
                string sEchoStr = context.Request.Params["echostr"];
                if (!string.IsNullOrEmpty(sEchoStr))
                {
                    //回调URL验证
                    WXMP_Verify_Recall(context, sMsgSig, sTimeStamp, sNonce, sEchoStr);
                    return;
                }
                context.Response.Write("Hello WXMP!");
                return;
            }
            string action = context.Request.Params["action"];
            if (!string.IsNullOrEmpty(action))
            {
                if (HttpContext.Current.Request.HttpMethod.ToUpper() == "POST" && action == "upload")
                {
                    WSResult ws = FileHandler.UploadProposalFileForUser(context);
                    context.Response.Write(JsonUtil<WSResult>.JsonSerializerObject(ws));
                    context.Response.End();
                    return;
                }
            }
            context.Response.Write("Welcome");
        }


        private static void WXMP_Verify_Recall(HttpContext context, string sMsgSig, string sTimeStamp, string sNonce, string sEchoStr)
        {
            string echoStr = sEchoStr;
            int verify = MsgCrypt.VerifyCallBack(sMsgSig, sTimeStamp, sNonce, ref echoStr);
            context.Response.ContentType = "text/plain";
            if (verify == 0)
            {
                WriteLog.Info("VerifyCallBack:" + echoStr);
                //context.Response.Write(sEchoStr);
                context.Response.Write(echoStr);
            }
            else
            {
                WriteLog.Error("VerifyCallBack Error:" + verify, null);
                context.Response.Write(echoStr);
                //context.Response.Write("Error Code:" + verify);
            }
        }

        private static void WXMP_Event_Response(HttpContext context, string sMsgSig, string sTimeStamp, string sNonce)
        {
            string sReqData = string.Empty;
            using (Stream stream = HttpContext.Current.Request.InputStream)
            {
                Byte[] postBytes = new Byte[stream.Length];
                stream.Read(postBytes, 0, (Int32)stream.Length);
                sReqData = Encoding.UTF8.GetString(postBytes);
            }
            WeiXinUtils.LogJson(string.Format("msg_signature: {0}\r\ntimestamp: {1}\r\nnonce: {2}\r\ndata: {3}", sMsgSig, sTimeStamp, sNonce, sReqData));
            string sContent = string.Empty;
            if (!string.IsNullOrEmpty(sReqData))
            {
                //WriteLog.Info(sReqData);
                BaseReceive msg = MsgCrypt.DecryptMsg(sMsgSig, sTimeStamp, sNonce, sReqData);
                if (msg != null)
                {
                    if (msg is ReceiveText)//文本消息
                    {
                        string content = ((ReceiveText)msg).Content;
                        ResponseText reply = new ResponseText();
                        reply.Content = "Welcome";
                        string encryptReply = MsgCrypt.EncryptMsg(reply, sTimeStamp, sNonce);
                        context.Response.Write(encryptReply);
                    }
                    else if (msg is BaseEvent) //事件
                    {
                        BaseEvent eventMsg = (BaseEvent)msg;
                        if (eventMsg is MenuClick) //点击菜单事件
                        {
                            string eventKey = ((MenuClick)eventMsg).EventKey;
                            //context.Response.Write(MsgCrypt.MsgCrypt.EncryptMsg(MsgReply.ReplyText(eventMsg, "暂时不提供该项服务"), sTimeStamp, sNonce));
                            //context.Response.Write(MsgReply.ReplyText(eventMsg, "暂时不提供该项服务").ToXmlString());
                            context.Response.Write(MsgReply.ReplyOneNews(eventMsg,
                                "我要提案", "请点击进入填写提案表单内容",
                                "http://acc.leo.com.hk/01/webchat/images/form_fill.png",
                                "http://acc.leo.com.hk/01/webchat/Default.aspx?action=auth").ToXmlString());
                        }
                        else if (eventMsg is ViewUrl) //点击菜单链接
                        {
                            string url = ((ViewUrl)eventMsg).EventKey;
                            //context.Response.Write(MsgCrypt.MsgCrypt.EncryptMsg(MsgReply.ReplyText(eventMsg, "你已进入以下网址：\r\n" + url), sTimeStamp, sNonce));
                            context.Response.Write(MsgReply.ReplyText(eventMsg, "你已进入以下网址：\r\n" + url).ToXmlString());
                        }
                        else if (eventMsg is EnterAgent)//进入应用
                        {
                        }
                        else
                        {
                            if (eventMsg.Event == "subscribe") //订阅/关注
                            {
                                BaseResponse reply = MsgReply.ReplyOneNews(msg, "欢迎使用利奥企业号", "利奥企业号对接企业ERP，实现生产流程监控、查询等在线功能。", "http://acc.leo.com.hk/01/webchat/form/pictures/demo.png", "http://acc.leo.com.hk/01/webchat/form/demo.html");
                                //string encryptReply = MsgCrypt.MsgCrypt.EncryptMsg(reply, sTimeStamp, sNonce);
                                //context.Response.Write(encryptReply);
                                context.Response.Write(reply.ToXmlString());
                                ////context.Response.Write(MsgCrypt.MsgCrypt.EncryptMsg(MsgReply.ReplyText(eventMsg, "欢迎使用利奥企业号！利奥企业号对接企业ERP，实现生产流程监控、查询等在线功能。"), sTimeStamp, sNonce));
                            }
                            else if (eventMsg.Event == "unsubscribe") //取消订阅/关注
                            {
                                //BaseResponse reply = MsgReply.ReplyOneNews(msg, "感谢使用利奥企业号", "利奥企业号对接企业ERP，实现生产流程监控、查询等在线功能。欢迎下次继续关注！", "http://acc.leo.com.hk/01/webchat/form/demo.png", "http://acc.leo.com.hk/01/webchat/form/demo.html");
                                //string encryptReply = MsgCrypt.MsgCrypt.EncryptMsg(reply, sTimeStamp, sNonce);
                                //context.Response.Write(encryptReply);
                                ////context.Response.Write(MsgCrypt.MsgCrypt.EncryptMsg(MsgReply.ReplyText(eventMsg, "感谢使用利奥企业号。欢迎下次继续关注！"), sTimeStamp, sNonce));
                            }
                        }
                    }
                }
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

    }
}
