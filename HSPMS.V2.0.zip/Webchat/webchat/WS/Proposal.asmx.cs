﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Globalization;
using LEO.Project.WXProposal.Model.Session;
using LEO.Project.WXProposal.Control;
using LEO.Project.WXProposal.Data.Entity;
using LEO.Project.WXProposal.Data.DAO;
using LEO.Project.Tools;
using JsonView;
using LEO.Project.WXProposal.Model.Pagination;
using System.IO;
using System.Xml.Serialization;
using LEO.Project.WXProposal.Control.Validator;
using LEO.Project.WXProposal.Validator;
using LEO.Project.WXProposal.Web;
using LEO.Project.WXProposal.Data.Imports;
using System.Data;
using System.Text;
//using LEO.Project.WXProposal.Control.RPC;

namespace WebChatInterface.WS
{
    /// <summary>
    /// Summary description for Proposal
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    [XmlInclude(typeof(AttachmentInfo))]
    [XmlInclude(typeof(WSResult))]
    public class ProposalWS : System.Web.Services.WebService
    {
/*
        [WebMethod]
        public string RPCCallTest()
        {
            //return ProposalSerialNumIPC.GetServerIPC().count();
            //return ProposalSerialNumPipe.GetPipeMsg();
            using (NamedPipeClient client = new NamedPipeClient(".", "test"))
            {
                string result = client.Query("fff");
                client.Dispose();
                return result;
            }
        }

        [WebMethod]
        public string CheckChineseMatch(string src, string dst)
        {
            bool a = !string.IsNullOrEmpty(src) && !string.IsNullOrEmpty(dst);
            StringBuilder sb = new StringBuilder();
            if (a)
            {
                sb.Append(ChineseConvert.CheckChineseMatch(src, dst));
            }
            else
                //sb.Append("No input string found!");
                try
                {
                    string excelFile = "D:/min.xlsx";
                    List<string> sheetNames = ExcelImporter.GetExcelSheetNameList(excelFile);
                    foreach (string sheetName in sheetNames)
                    {
                        DataTable dt = ExcelImporter.ImportSheetData(excelFile, sheetName);
                        if (dt == null) continue;
                        if (dt.Rows.Count > 0)
                        {
                            for (int r = 0; r < dt.Rows.Count; r++)
                            {
                                DataRow dr = dt.Rows[r];
                                if (!ChineseConvert.CheckChineseMatch(dr.ItemArray[0].ToString(), dr.ItemArray[1].ToString()))
                                {
                                    sb.Append(r + 1).Append(' ').Append(dr.ItemArray[0].ToString()).Append('：').Append(dr.ItemArray[1].ToString()).Append('\n');
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    WriteLog.Error("ImportEmployee Exception:", ex);
                }
            return sb.ToString();//ChineseConvert.ToTraditional(fullName);
        }
*/
        [WebMethod]
        public WSResult RegJobNumber(string jobNum, string fullName, string idSuffix, string mobile,string next)
        {
            return WebHandler.RegJobNumber(jobNum, fullName, idSuffix, mobile, next);
            /*
            if (string.IsNullOrEmpty(jobNum) || string.IsNullOrEmpty(fullName) || string.IsNullOrEmpty(idSuffix))
                return WSResult.Result(false, -3, "Parameter Invalid!");
            WSResult ws = Handler.CheckSession(Context.Request);
            if (ws.ResultObject != null && ws.ResultObject is UserSession)
            {
                if (ws.ResultObject is WechatUserSession)
                {
                    WechatUserSession us = (WechatUserSession)ws.ResultObject;
                    if (string.IsNullOrEmpty(us.JobNumber))
                    {
                        WXUserInfo wxu = WXUserInfoDAO.GetWXUserInfoByOpenId(us.OpenID);
                        if (wxu == null) return WSResult.Result(false, 0, "WebChat user not existed!");
                        if (!string.IsNullOrEmpty(wxu.JobNumber))
                        {
                            if (wxu.JobNumber == jobNum) return WSResult.Result(true, 1, "Register duplicated!");
                            return WSResult.Result(false, 0, "WebChat user is registered by other jobnumber!");
                        }
                        Employee emp = EmployeeDAO.GetEmployeeByJobNumber(jobNum);
                        if (emp == null || emp.FullName != ChineseConvert.ToTraditional(fullName) || emp.IDNumSuffix != idSuffix)
                            return WSResult.Result(false, -4, "抱歉!您输入的工号/姓名/身份证后6位信息不正确！");
                        if (string.IsNullOrEmpty(mobile) || !RegValid.IsMobile(mobile))
                            return WSResult.Result(false, -4, "抱歉!請输入正确的手机号码！");
                        if (emp.Status != EmployeeStatus.Valid)
                            return WSResult.Result(false, -5, "抱歉!您输入的工号無效！");
                        wxu.JobNumber = jobNum;
                        int flag = WXUserInfoDAO.UpdateWXUserInfo(wxu, mobile);
                        if (flag > 0)
                        {
                            us.JobNumber = jobNum;
                            SessionDaemon.getInstance().CreateUserSession(jobNum, us.OpenID, UserSessionType.WechatUser, us.IPAddress);
                            if (!string.IsNullOrEmpty(next) && next == "") us.tokenStart = DateTimeUtil.CurrentMillis;
                            return WSResult.Result(true, 1, "登记成功!");
                        }
                        else return WSResult.Result(true, -6, "抱歉！因系统繁忙，暂时未能处理您的登记请求。");
                    }
                    else
                    {
                        if (us.JobNumber == jobNum) return WSResult.Result(true, 1, "Register duplicated for twice!");
                        return WSResult.Result(false, 0, "JobNumber existed!");
                    }
                }
                else return WSResult.Result(false, 0, "No need to reg jobnumber!");
            }
            else
            {
                return ws;
            }
            */
        }

        [WebMethod]
        public WSResult TestReg(string jobNum, string fullName, string idSuffix)
        {
            Employee emp = EmployeeDAO.GetEmployeeByJobNumber(jobNum);
            if (emp == null || !ChineseConvert.CheckChineseMatch(emp.FullName, fullName) || emp.IDNumSuffix != idSuffix)
                return WSResult.Result(false, -4, "抱歉!您输入的工号/姓名/身份证后6位信息不正确！");
            if (emp.Status != EmployeeStatus.Valid)
                return WSResult.Result(false, -5, "抱歉!您输入的工号無效！");
            return WSResult.Result(true, 0, "OK");
        }


        [WebMethod]
        public WSResult SubmitProposal(string dataArr, string fileArr, string uJobNum, string uName)
        {
            return WebHandler.SubmitProposal(dataArr, fileArr, uJobNum, uName);
            /*
            try
            {
                //string category, string title, string desc, string advice, string uJobNum, string uName, string soNum, string itemName, string ordQty, string eqId, string eqName, string workerNow, string workerAfter, string effNow, string effAfter, string dpRateNow, string dpRateAfter, string progress, string otherImprove
                WSResult ws = Handler.CheckSession(Context.Request);
                if (ws.IsOK && ws.ResultObject != null && ws.ResultObject is UserSession)
                {
                    UserSession us = (UserSession)ws.ResultObject;
                    ValidateResult vr = AttachUploadValidator.ValidateProposalDailyCount(us);
                    if (!vr.IsOK) return WSResult.Result(vr);
                    vr = SessionValidator.ValidateOperationTimer(us);
                    if (!vr.IsOK) return WSResult.Result(vr);
                    ProposalInfo pi = JsonUtil<ProposalInfo>.JsonDeserializeObject(dataArr);
                    pi.FormDate = DateTime.Now;
                    pi.SubmitTime = DateTime.Now;
                    vr = ProposalInputValidator.ValidateInputData(us, pi, fileArr, uJobNum, uName);
                    if (!vr.IsOK) return WSResult.Result(vr);
                    pi.Number = ProposalInfoDAO.GenerateSerialNumber();
                    pi.Status = ProposalStatus.Received;
                    int result = ProposalInfoDAO.SaveProposalInfo(pi);
                    if (result > 0)
                    {
                        if (us.UploadFilePaths!=null) us.UploadFilePaths.Clear();
                        return WSResult.Result(true, 1, pi.Number);
                    }
                    return WSResult.Result(false, -1, "抱歉！您的提案资料未能提交成功！");
                }
                else ws.ResultObject = null;
                return ws;
            }
            catch (Exception ex)
            {
                WriteLog.Error("SubmitProposal Exception", ex);
                return WSResult.Result(false, -1, "系統處理異常！請聯繫GISS(2955)。");
            }
            */
        }

        /*
        [WebMethod]
        public string UploadFile()
        {
            WSResult ws = Handler.CheckSession(Context.Request);
            if (ws.IsOK && ws.ResultObject != null && ws.ResultObject is UserSession)
            {
                UserSession us = (UserSession)ws.ResultObject;
                try
                {
                    var Request = Context.Request;
                    var length = Request.ContentLength;
                    if (length == 0)
                    {
                        return JsonUtil<WSResult>.JsonSerializerObject(WSResult.Result(false, -1, "上传内容为空"));
                    }
                    else if (length > SysConfig.MaxUploadFileLength)
                    {
                        return JsonUtil<WSResult>.JsonSerializerObject(WSResult.Result(false, -1, "单次上传的文件大小不能超过" + FileUtil.ConvertFileSize(SysConfig.MaxUploadFileLength) + "！"));
                    }
                    var bytes = new byte[length];
                    Request.InputStream.Read(bytes, 0, length);
                    var fileName = Request.Headers["X-File-Name"];
                    var fileSize = Request.Headers["X-File-Size"];
                    var fileType = Request.Headers["X-File-Type"];

                    string picName = string.Empty;
                    string localPath = Path.Combine(HttpRuntime.AppDomainAppPath, "Upload");
                    string ex = Path.GetExtension(fileName);
                    picName = DateTimeUtil.CurrentMillis.ToString() + ex;
                    AttachmentInfo fi = new AttachmentInfo();
                    fi.RelatedKey = picName;
                    fi.FileName = picName;
                    fi.FilePath = "/Upload/";
                    fi.FileSize = length;
                    string picUrl = fi.FilePath + picName;
                    if (!Directory.Exists(localPath))
                    {
                        Directory.CreateDirectory(localPath);
                    }
                    // save the file.
                    var fileStream = new FileStream(Path.Combine(localPath, picName), FileMode.Create, FileAccess.ReadWrite);
                    fileStream.Write(bytes, 0, length);
                    fileStream.Close();
                    ws.ResultObject = JsonUtil<AttachmentInfo>.JsonSerializerObject(fi);
                }
                catch (Exception ex)
                {
                    WriteLog.Error("ProposalWS.UploadFiles() Exception", ex);
                    ws.IsOK = false;
                    ws.ResultObject = WriteLog.FlattenException(ex);
                }
            }else ws.ResultObject = null;
            return JsonUtil<WSResult>.JsonSerializerObject(ws);
        }
        */

        [WebMethod]
        public WSResult QueryProposals(string keyword, string dateBegin, string dateEnd, string status, int pageIndex)
        {
            return WebHandler.QueryProposals(keyword, dateBegin, dateEnd, status, pageIndex);
            /*
            WSResult ws = Handler.CheckSession(Context.Request);
            if (ws.IsOK && ws.ResultObject != null && ws.ResultObject is UserSession)
            {
                UserSession us = (UserSession)ws.ResultObject;
                string openID = (us is WechatUserSession) ? ((WechatUserSession)us).OpenID : null;
                if (!string.IsNullOrEmpty(us.JobNumber))
                {
                    PageList pl = new PageList();//每頁10條記錄
                    pl.PageSize = 10;
                    pl.PageIndex = pageIndex;
                    DateTime? dtb = DateTimeUtil.ParseDateTime(DateTimeUtil.FormatYMD, dateBegin);
                    DateTime? dte = DateTimeUtil.ParseDateTime(DateTimeUtil.FormatYMD, dateEnd);
                    ProposalInfoDAO.PaginationQuery(
                        string.IsNullOrEmpty(keyword) ? "" : keyword.Trim(), 
                        us.JobNumber, 
                        openID,//us.OpenID, 
                        dtb.HasValue?dtb.Value.ToString(DateTimeUtil.FormatYMD):"", 
                        dte.HasValue?dte.Value.ToString(DateTimeUtil.FormatYMD):"",
                        string.IsNullOrEmpty(status) ? "" : status.Trim(), pl);
                    object[] arr = pl.PageData.ToArray();
                    pl.PageData.Clear();
                    for (int i = 0; i < arr.Length; i++)
                    {
                        if (arr[i] is ProposalInfo)
                        {
                            ProposalInfo pi = (ProposalInfo)arr[i];
                            if ((string.IsNullOrEmpty(openID) || (pi.WXOpenID == openID)) && pi.AuthorJobNumber == us.JobNumber)
                            {
                                pl.PageData.Add(ProposalView.Copy((ProposalInfo)arr[i]));
                            }
                        }
                    }
                    ws.ResultObject = pl;
                    return ws;
                }
            }
            //ws.ResultObject = null;
            return ws;
            /*
            WSResult ws = WSResult.Result(true, 0, "Session Valid.");
            PageList pl = new PageList();//每頁10條記錄
            pl.PageSize = 10;
            pl.PageIndex = pageIndex;
            ProposalInfoDAO.PaginationQuery(keyword, "3100150", "o_GR4wLznJGryPXgWGOEvMUFR0uo", dateBegin, dateEnd, status, pl);
            object[] arr = pl.PageData.ToArray();
            pl.PageData.Clear();
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] is ProposalInfo)
                {
                    pl.PageData.Add(ProposalView.Copy((ProposalInfo)arr[i]));
                }
            }
            ws.ResultObject = pl;
            return ws;
            */
        }

        [WebMethod]
        public WSResult GetSEIInfo(string so)
        {
            WSResult ws = WebHandler.CheckSession();
            if (ws.IsOK && ws.ResultObject != null && ws.ResultObject is UserSession)
            {
                WebChatInterface.ICPService.ICPService rws = new WebChatInterface.ICPService.ICPService();
                ws.ResultObject = rws.GetSOInfo(so);
                /*
                string seiInfo = rws.GetSEIInfo(so);
                ws.ResultObject = seiInfo;
                */
            }
            return ws;
        }

        [WebMethod]
        public WSResult QuerySummary()
        {
            return WebHandler.QuerySummary();
            /*
            WSResult ws = Handler.CheckSession(Context.Request);
            if (ws.IsOK && ws.ResultObject != null && ws.ResultObject is UserSession)
            {
                UserSession us = (UserSession)ws.ResultObject;
                Dictionary<string, string> sumDict = ProposalInfoDAO.UserSummary(us.JobNumber);
                ws.ResultObject = sumDict;
            }
            return ws;
            */
        }

    }
}
