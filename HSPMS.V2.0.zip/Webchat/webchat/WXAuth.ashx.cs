﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using LEO.Project.WXProposal.Control;
using LEO.Project.WXProposal.Data.DAO;
using LEO.Project.WXProposal.Model.Session;
using LEO.Project.WXProposal.Data.Entity;
using LEO.Project.Tools;
using WebChatInterface.Class.Tencent;

namespace WebChatInterface
{
    public class WXAuth : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            string code = context.Request.Params["code"];
            string state = context.Request.Params["state"];
            WXUserInfo src = null;
            StringBuilder sb = new StringBuilder();
            if (HttpContext.Current.Request.HttpMethod.ToUpper() == "GET")
            {
                if (!string.IsNullOrEmpty(code))
                {
                    WXUserInfo wxu = WeiXinUtils.GetWXUserInfoByCode(code);
                    if (wxu == null)
                    {
                        HttpContext.Current.Response.Write("WeiXin User Fetch Fail!");
                        WriteLog.Info("WeiXin User Fetch Fail! Code=" + code);
                        return;
                    }
                    sb.Append("WX Auth Result:OpenID=" + wxu.OpenID).Append('\n');
                    src = WXUserInfoDAO.GetWXUserInfoByOpenId(wxu.OpenID);
                    if (src != null)
                    {
                        src.NickName = wxu.NickName;
                        src.LastUpdate = DateTime.Now;
                        src.Sex = wxu.Sex;
                        src.Country = wxu.Country;
                        src.Province = wxu.Province;
                        src.City = wxu.City;
                        WXUserInfoDAO.UpdateWXUserInfo(src,null);
                        sb.Append("WXUserInfoDAO GetWXUserInfoByOpenId: Update & JobNumber=").Append(src.JobNumber).Append('\n');
                    }
                    else
                    {
                        src = wxu;
                        src.LastUpdate = DateTime.Now;
                        src.Status = 1;//有效
                        WXUserInfoDAO.InsertWXUserInfo(src);
                        sb.Append("WXUserInfoDAO GetWXUserInfoByOpenId: Insert").Append('\n');
                    }
                }
            }

            sb.Append("WXUserInfo:"+src).Append('\n');
            //WriteLog.Info(sb.ToString());
            if (src == null) HttpContext.Current.Response.Write("No WeiXin User Detected!");
            else
            {
                string ip = HttpUtil.GetRequestIPAddress(context.Request);
                UserSession us = SessionDaemon.getInstance().CreateUserSession(src.JobNumber, src.OpenID, UserSessionType.WechatUser, ip);
                UrlRedirect(us, state);
                /*
                if (string.IsNullOrEmpty(src.JobNumber))
                {
                    string act = (!string.IsNullOrEmpty(state) && state == UserAction.ActionQuery) ? UserAction.ActionQuery : UserAction.ActionSubmit;//默认为提交提案
                    HttpContext.Current.Response.Redirect(SysConfig.Url_UserReg + '?' + UserAction .ActionNext+ '=' + act, true);
                }
                else
                {
                    if (!string.IsNullOrEmpty(state) && state == "query")
                        HttpContext.Current.Response.Redirect(SysConfig.Url_ProposalQuery, true);
                    else
                        HttpContext.Current.Response.Redirect(SysConfig.Url_ProposalInput, true);
                }
                */
            }
            //context.Response.ContentType = "text/plain";
            //context.Response.Write("Hello World");
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        public static void UrlRedirect(UserSession us, string next)
        {
            if (us != null && us is WechatUserSession)
            {
                WechatUserSession wus = (WechatUserSession)us;

                wus.lastUpdate = DateTimeUtil.CurrentMillis;
                HttpCookie cookie = new HttpCookie("AuthSessionID", us.SessionId);
                cookie.Expires = DateTime.Now.AddMilliseconds(SessionDaemon.SessionTimeout);
                HttpContext.Current.Response.Cookies.Add(cookie);

                EventLog log = EventLog.WXUserAccessEvent(us.IPAddress, us.JobNumber, wus.OpenID, wus.SessionId);
                int logresult = EventLogDAO.InsertEventLog(log);
                if (logresult <= 0) WriteLog.Error("Log event fail in WXAuth.UrlRedirect", null);

                if (string.IsNullOrEmpty(us.JobNumber))
                {
                    string act = (!string.IsNullOrEmpty(next) && next == UserAction.ActionQuery) ? UserAction.ActionQuery : UserAction.ActionSubmit;//默认为提交提案
                    HttpContext.Current.Response.Redirect(SysConfig.Url_UserReg + '?' + UserAction .ActionNext+ '=' + act, true);
                }
                else
                {
                    if (!string.IsNullOrEmpty(next) && next == UserAction.ActionQuery)
                        HttpContext.Current.Response.Redirect(SysConfig.Url_ProposalQuery, true);
                    else
                    {
                        wus.tokenStart = DateTimeUtil.CurrentMillis;
                        HttpContext.Current.Response.Redirect(SysConfig.Url_ProposalInput, true);
                    }
                }
            }
        }
    }
}
