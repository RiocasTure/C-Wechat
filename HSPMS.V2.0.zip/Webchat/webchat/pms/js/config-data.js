/** Constants **/
var version="20170811";
var DataMethod = "POST",
	DataFeederBase = "../WS/Proposal.asmx/",
	GetSEIInfo = "GetSEIInfo",
	RegJobNumber = "RegJobNumber",
	SubmitProposal = "SubmitProposal",
	QueryProposals = "QueryProposals",
	UploadFile = "../Handler.ashx?action=upload",
	UploadPath = "../attach/";

var DataTransError = "网络传输异常";
var DataProcessError = "系统未能及时响应";
var inputFieldsSettings = [
	{type:"生产性向上",fields:["fields_progress","fields_so_ord","fields_pd_name","improve_workers","improve_eff"],require:["fields_so_ord","fields_pd_name"]},
	{type:"机台设备",fields:["fields_progress","fields_eq","improve_workers","improve_eff"],require:["fields_eq"]},
	{type:"品质",fields:["fields_progress","fields_so_ord","fields_pd_name","improve_dprate"],require:[]},
	{type:"5S",fields:["fields_progress","fields_so_ord","fields_pd_name"],require:[]},
	{type:"其他",fields:["fields_progress","fields_so_ord","fields_pd_name","fields_eq"],require:[]}
];
var mobiOption = {
	preset: 'date', //日期格式 date（日期）|datetime（日期加时间）
	theme: 'android-ics light',//'jqm', //皮肤样式
	display: 'bubble',//'modal', //显示方式
	mode: 'mixed',//'scroller',//'clickpick', //日期选择模式
	dateFormat: 'yy-mm-dd', // 日期格式
	setText: '确定', //确认按钮名称
	cancelText: '取消',//取消按钮名籍我
	dateOrder: 'yymmdd', //面板中日期排列格式
	dayText: '日', monthText: '月', yearText: '年', //面板中年月日文字
	yearText: '年', monthText: '月',  dayText: '日'//,  //面板中年月日文字
};
var MaxUploadFileLength = 6291456;
var MaxUploadFileCount = 10;
var LCProposal = false;
/*
var LCProposal = {};
LCProposal["YieldingInfo"]={};
LCProposal["AuditInfo"]={};
*/

var LCProposalPage = new Array();
var ItemOptions=new Array();
var AttachList=new Array();
var isWXEmbedded = window.navigator.userAgent.toLowerCase().match(/MicroMessenger/i) == 'micromessenger';