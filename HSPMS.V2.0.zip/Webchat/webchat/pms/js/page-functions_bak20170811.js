var previousOrientation;
var checkOrientation = function(){
    if(window.orientation !== previousOrientation){
	    previousOrientation = window.orientation;
    }
	fitListPageDisplay("pqr");
};

bindWindowEvent("orientationchange",checkOrientation);
bindWindowEvent("resize",checkOrientation);
if (isWXEmbedded) bindWindowEvent("load",function(){
	if (typeof WeixinJSBridge == "object" && typeof WeixinJSBridge.invoke == "function") {
		handleFontSize();
	} else {
		if (document.addEventListener) {
			document.addEventListener("WeixinJSBridgeReady", handleFontSize, false);
		} else if (document.attachEvent) {
			document.attachEvent("WeixinJSBridgeReady", handleFontSize);
			document.attachEvent("onWeixinJSBridgeReady", handleFontSize);
		}
	}
});

 function handleFontSize() {
	if (isWXEmbedded){
		// 设置网页字体为默认大小
		WeixinJSBridge.invoke('setFontSizeCallback', {'fontSize': 0});
		// 重写设置网页字体大小的事件
		WeixinJSBridge.on('menu:setfont', function () {
			WeixinJSBridge.invoke('setFontSizeCallback', {'fontSize': 0});
		});
	}
}

function fitListPageDisplay(prefix){
	var headtr = $('#'+prefix+'_datahead thead tr');
	var listtr = $('#'+prefix+'_datalist tbody tr');
	if (listtr.length>0 && headtr.length>0){
		var th = $(listtr.get(0)).children("th");
		var tds = $(listtr.get(0)).children("td");
		var hths = $(headtr.get(0)).children("th");
		for (var i=0;i<th.length;i++){
			if (i>=hths.length) break;
			$(hths.get(i)).width($(th.get(i)).width());
		}
		for (var i=0;i<tds.length;i++){
			if (i+th.length>=hths.length) break;
			if (i==0) continue;
			$(hths.get(i+th.length)).width($(tds.get(i)).width());
		}
	}
}

function closeMyWindow(){
	if (typeof WeixinJSBridge != "undefined")
		WeixinJSBridge.invoke("closeWindow",{},function(e){});
	else{
		if (window.parent&&window.parent.isPopFrameOpen&&window.parent.isPopFrameOpen()){
			if (window.parent.closePopFrame){
				window.parent.closePopFrame();
				return;
			}
		}
		window.close();
	}
}

function setSelectVal(selectId,val){
	$("#"+selectId).val(val);
	$("#"+selectId).selectmenu("refresh");
	$("#"+selectId).parent().css("width","");
	var selectWidth = $("#"+selectId).parent().width();
	if (selectWidth>0){
		var span = $("#"+selectId).parent().children("span.ui-btn-inner").children("span.ui-btn-text");
		span.html("");
		var blankWidth = $("#"+selectId).parent().width();
		if (selectWidth>blankWidth){
			$("#"+selectId).parent().css({"width":blankWidth+"px","overflow":"hidden","text-overflow":"ellipsis"});
		}
		span.html(val);
	}
}

function autoHideFooter(){
	if (isWXEmbedded){
		$('div.cnt-ctn input[type="text"],div.cnt-ctn textarea,div.cnt-ctn input[type="number"],div.cnt-ctn input[type="select"]').each(function(){
			$(this).unbind("focus");
			$(this).bind("focus",function(){
				setTimeout(function(){
					$("div.cnt-ctn-footer").children("div.foot-mask").remove();
					////$("div.cnt-ctn-footer").prepend('<div class="foot-mask"></div>');
					//$("div.cnt-ctn-footer").css("opacity","0.3");
					$("div.cnt-ctn-footer").animate({opacity: "0.5"}, 300);
				},300);
			});
			$(this).unbind("blur");
			$(this).bind("blur",function(){
				setTimeout(function(){
					////$("div.cnt-ctn-footer").children("div.foot-mask").remove();
					//$("div.cnt-ctn-footer").css("opacity","1.0");
					$("div.cnt-ctn-footer").animate({opacity: "1.0"}, 300);
				},300);
			});
		});
	}
}

function pageInit_Index(){}
function pageDataInit_Index(){
	$("#agree_ref").unbind("click");
	$("#agree_ref").bind("click",function(event){
		event.stopPropagation();
		event.stopImmediatePropagation();
		$.mobile.changePage(noCacheUrl($(this).prop("href")), {
			transition: "pop",
			changeHash: true,
			role: "dialog"
		});
		return false;
	});
	$("#reg_agree").unbind("click");
	$("#reg_agree").bind("click",function(){
		event.stopPropagation();
		event.stopImmediatePropagation();
		$("#register_smt_btn").button("enable");
		$.mobile.changePage(noCacheUrl($("#agree_ref").prop("href")), {
			transition: "pop",
			changeHash: true,
			role: "dialog"
		});
		return false;
	});
	$("#register_smt_btn").unbind("click");
	$("#register_smt_btn").bind("click",function(){
		var agree = $("#reg_agree").prop("checked");
		if (!agree){
			alert("请先阅读并同意提案须知条款！");
			return;
		}
		var uid = $("#reg_uid").val();
		var uname = $("#reg_uname").val();
		var idsuf = $("#reg_idsuffix").val();
		var mobile = $("#reg_tel").val();
		var msg = "";
		if (!uid || uid.length<7) msg+= (msg==""?"":"、")+"工号";
		if (!uname || uname.length<2) msg+= (msg==""?"":"、")+"姓名";
		if (!idsuf || idsuf.length!=6) msg+= (msg==""?"":"、")+"身份证后6位";
		if (!mobile || mobile.length!=11) msg+= (msg==""?"":"、")+"手机号码";
		if (msg!=""){
			alert("您所输入的以下内容不正确，请修正：\n\n"+msg+"。");
			return;
		}
		showLoadingMsg();
		var dataObj = {"jobNum":uid,"fullName":uname,"idSuffix":idsuf,"mobile":mobile,"next":""};//getLocationParams("next")
		$.ajax({
			type: DataMethod,
			url: noCacheUrl(DataFeederBase+RegJobNumber),
			dataType: "json",
			contentType: "application/json; charset=utf-8",
			data: convertObj2AjaxData(dataObj),
			success: function(data){
				if (data && data.d && data.d.IsOK){
					popToast("註冊登記成功！",3000);
					var next = getLocationParams("next");
					if (next && next=='query') next = 'list.html';
					else next = 'step-1.html';//next==submit||next==''
					$.mobile.changePage(next+"?ver="+version, {reloadPage : true, transition: "slide", reverse:false});
				}else{
					alert("抱歉！系统暂时无法为您进行注册登记！\n\n詳細信息："+data.d.SysMsg);
				}
				hideMsg();
			},
			error: function (jqXHR, textStatus, errorThrown) {
				alert("抱歉！系统暂时无法为您进行注册登记！\n\n詳細信息："+DataTransError);
				hideMsg();
			},
			timeout: 8000
		});
	});
	autoHideFooter();
}

function pageInit_Agreement(){
	$("#agree_content").css("height",parseInt($(window).height()-96)+"px").css("overflow","auto");
	$("#agree_btn").unbind("click");
	$("#agree_btn").bind("click",function(event){
		$("#reg_agree").prop("checked", true).checkboxradio("refresh");
		$("#register_smt_btn").button("enable");
		/**close dialog**/
		if (window.location.hash=='#&ui-state=dialog'){
			$(".ui-dialog").dialog("close");
		}
		return false;
		/**or return true**/
		//return true;
	});
}

function pageEventInit_List(){
	var viewDetail = function(){
		$("div#viewDetailCxt ul.cnt-ctn-propul").children("li").css("display","none");
		var i=$(this).attr("data-idx");
		if (LCProposalPage["PageData"][i]){
			var impWShow = false,impEShow = false,impDShow = false,impOther = false;
			for (var propName in LCProposalPage["PageData"][i]){
				var element = $("#pv_"+propName);
				if (element.length==1){
					var valstr = LCProposalPage["PageData"][i][propName];
					element.children("span").html(valstr==''?'&nbsp;':valstr);
				}
				//Workers Eff DPRate
				if (LCProposalPage["PageData"][i][propName]!=null&&
					LCProposalPage["PageData"][i][propName]!=""&&
					LCProposalPage["PageData"][i][propName]!="0"){
					if (propName.indexOf("ImprvWorkers")==0) impWShow = true;
					if (propName.indexOf("ImprvEff")==0) impEShow = true;
					if (propName.indexOf("ImprvDPRate")==0) impDShow = true;
					if (propName.indexOf("ImprvOther")==0) impOther = true;
					element.css("display","");
				}
			}
			$("#Imprv_Workers").css("display",impWShow?"table-row":"none");
			$("#Imprv_Eff").css("display",impEShow?"table-row":"none");
			$("#Imprv_DPRate").css("display",impDShow?"table-row":"none");
			$("#Imprv_Other").css("display",impOther?"table-row":"none");
			$("#ImproveDataHead").css("display",(impWShow||impEShow||impDShow||impOther)?"block":"none");
			$("#ImproveDataList").css("display",(impWShow||impEShow||impDShow||impOther)?"table":"none");
			$("#viewDetailCxt").css("max-height","");
			if ($(window).height()-$("#viewDetailCxt").height()<50)
				$("#viewDetailCxt").css("max-height",($(window).height()-50)+"px");
			$("#viewDetail").popup();
			$("#viewDetail").popup("open",{positionTo: "window"});
		}else alert("提案列表已更新，请重新查询！");
	};
	$("table#queryResult tbody tr").unbind("click");
	$("table#queryResult tbody tr").bind("click",viewDetail);
	$("#pqr_datalist tbody tr").unbind("click");
	$("#pqr_datalist tbody tr").bind("click",viewDetail);
}

function pageDataRender_ListView(){
	var statics = LCProposalPage["PageData"].length==0?'无记录':('共'+LCProposalPage["PageData"].length+'条');
	if (LCProposalPage["PageData"].length<LCProposalPage["RowsCount"])
		statics = '显示'+LCProposalPage["PageData"].length+'/共'+LCProposalPage["RowsCount"]+'条';
	$("#querylist_head h1").children("span").html(statics);
	var loadmore = (LCProposalPage["PageCount"]>LCProposalPage["PageIndex"]);
	$("p.cnt-ctn-tblst-margin").css("display",loadmore?"block":"none");
	$("#query_loadmore_btn").closest("div.cnt-ctn-tb-footer").css("display",loadmore?"block":"none");
	pageEventInit_List();
}

function pageDataRender_List(){
	$("#queryResult").css("display","block");
	var statics = LCProposalPage["PageData"].length==0?'无记录':('共'+LCProposalPage["PageData"].length+'条');
	if (LCProposalPage["PageData"].length<LCProposalPage["RowsCount"])
		statics = '显示'+LCProposalPage["PageData"].length+'/共'+LCProposalPage["RowsCount"]+'条';
	$("#querylist_head h1").children("span").html(statics);
	var loadmore = (LCProposalPage["PageCount"]>LCProposalPage["PageIndex"]);
	$("p.cnt-ctn-tblst-margin").css("display",loadmore?"block":"none");
	$("#query_loadmore_btn").closest("div.cnt-ctn-tb-footer").css("display",loadmore?"block":"none");
	
	if (window.parent&&window.parent.isPopFrameOpen&&window.parent.isPopFrameOpen()){
		$("div.cnt-ctn-tblst").css("display","none");
		$("#pqr_datahead").css("display","table");
		$("#pqr_datalist").css("display","table");
		$("#pqr_datalist tbody tr").remove();
		var tbodyhtml = "";
		for (var i=0;i<LCProposalPage["PageData"].length;i++){
			tbodyhtml += 
				'<tr data-idx="'+i+'">' +
				'<th>'+(i+1)+'</th>' +
				'<td>'+LCProposalPage["PageData"][i].Number+'</td>' +
				'<td>'+LCProposalPage["PageData"][i].FormDate+'</td>' +
				'<td>'+LCProposalPage["PageData"][i].SubmitTime+'</td>' +
				'<td>'+LCProposalPage["PageData"][i].Category+'</td>' +
				'<td>'+LCProposalPage["PageData"][i].Title+'</td>' +
				'<td>'+LCProposalPage["PageData"][i].Status+'</td>' +
				'</tr>';
		}
		$("#pqr_datalist").children("tbody").html(tbodyhtml);//$("#pqr_datalist > tbody").append(tbodyhtml);
		$("#pqr_datalist").table("refresh");
		setTimeout(function(){$("#querylist").css("min-height","100px");fitListPageDisplay("pqr");$(window).trigger("resize");},20);
	}else{
		$("div.cnt-ctn-tblst").css("display","block");
		$("#pqr_datahead").css("display","none");
		$("#pqr_datalist").css("display","none");
		$("#queryResult tbody tr").remove();
		var tbodyhtml = "";
		for (var i=0;i<LCProposalPage["PageData"].length;i++){
			tbodyhtml += 
				'<tr data-idx="'+i+'">' +
				'<th>'+LCProposalPage["PageData"][i].Number+'<span>'+(i+1)+'</span></th>' +
				'<td>'+LCProposalPage["PageData"][i].FormDate+'</td>' +
				'<td class="elisw-txt">'+LCProposalPage["PageData"][i].Title+'</td>' +
				'<td>'+LCProposalPage["PageData"][i].Status+'</td>' +
				'<td class="elisw-txt">'+LCProposalPage["PageData"][i].Description+'</td>' +
				'</tr>';
		}
		$("#queryResult").children("tbody").html(tbodyhtml);//$("#queryResult > tbody").append(tbodyhtml);
		$("#queryResult").table("refresh");
	}
	pageEventInit_List();
}

function pageDataQuery_BtnLoading(loading){
	if (loading){
		$("#query_loadmore_btn").text("正在加載...");
		$("#query_loadmore_btn").button("disable");
		$("#query_loadmore_btn").parent().children("span").children('span').eq(1).removeClass("ui-icon").removeClass("ui-icon-loading");
		$("#query_loadmore_btn").parent().children("span").children('span').eq(1).addClass("ui-icon").addClass("ui-icon-loading");
	}else{
		$("#query_loadmore_btn").text("加載更多");
		$("#query_loadmore_btn").button("enable");
		setTimeout(function(){$("#query_loadmore_btn").parent().children("span").children('span').eq(1).removeClass("ui-icon").removeClass("ui-icon-loading");},10);
	}
	$("#query_loadmore_btn").button("refresh");
}

function pageDataQuery_List(nextPage){
	var pageIndex = nextPage && LCProposalPage["PageIndex"] && LCProposalPage["PageIndex"]>0?LCProposalPage["PageIndex"]+1:1;
	if (pageIndex==1){
		LCProposalPage["keyword"] = $("#qKeyword").val().trim();
		LCProposalPage["dateBegin"] = getDateInputValue($("#qDateBegin"));
		LCProposalPage["dateEnd"] = getDateInputValue($("#qDateEnd"));
		LCProposalPage["status"] = $("#qStatus").val();
	}
	//showLoadingMsg();
	pageDataQuery_BtnLoading(true);
	var dataObj = {
		"keyword":LCProposalPage["keyword"],"dateBegin":LCProposalPage["dateBegin"],
		"dateEnd":LCProposalPage["dateEnd"],"status":LCProposalPage["status"],"pageIndex":pageIndex
	};
	$.ajax({
		type: DataMethod,
		url: noCacheUrl(DataFeederBase+QueryProposals),
		//url: noCacheUrl("./data/list.json"),
		dataType: "json",
		contentType: "application/json; charset=utf-8",
		data: convertObj2AjaxData(dataObj),
		success: function(data){
			if (data && data.d && data.d.IsOK){
				if (data.d.ResultObject){
					LCProposalPage["PageSize"] = data.d.ResultObject["PageSize"];
					LCProposalPage["PageCount"] = data.d.ResultObject["PageCount"];
					LCProposalPage["PageIndex"] = data.d.ResultObject["PageIndex"];
					LCProposalPage["RowsCount"] = data.d.ResultObject["RowsCount"];
					if (pageIndex==1) LCProposalPage["PageData"] = data.d.ResultObject["PageData"];
					else for (var i=0;i<data.d.ResultObject["PageData"].length;i++){
						LCProposalPage["PageData"].push(data.d.ResultObject["PageData"][i]);
					}
					pageDataRender_List();
					if ($("#queryPanel").hasClass("ui-panel-open")){
						setTimeout(function(){$("#queryPanel").panel("close");},400);
					}
				}else{
					alert("抱歉！因系统数据异常，本次查询失败！");
				}
			}else{
				if (data && data.d && data.d.SysMsg) alert(data.d.SysMsg);
				else alert("抱歉！"+DataProcessError+"，请稍候再试！");
			}
			//hideMsg();
			pageDataQuery_BtnLoading(false);
		},
		error: function (jqXHR, textStatus, errorThrown) {
			alert("抱歉！因"+DataTransError+"的原因，系统未能处理您的查询请求！");
			//hideMsg();
			pageDataQuery_BtnLoading(false);
		},
		timeout: 8000
	});
}
function pageInit_List(){}
function pageDataInit_List(){
	initDateInput($("#qDateBegin"));
	initDateInput($("#qDateEnd"));
	pageDataQuery_List();
	$("#q_query_btn").unbind("click");
	$("#q_query_btn").bind("click",function(){
		pageDataQuery_List();
	});
	$("#query_loadmore_btn").unbind("click");
	$("#query_loadmore_btn").bind("click",function(){
		pageDataQuery_List(true);
	});
}

function pageInit_Step1(){
	if (!LCProposal){
		LCProposal = {};
		LCProposal["YieldingInfo"]={};
		LCProposal["AuditInfo"]={};
	}
	if (LCProposal["Category"]){
		$("input[name=P_Category]").filter('[value="'+LCProposal["Category"]+ '"]').prop('checked', true).checkboxradio('refresh');
	}
}
function pageDataInit_Step1(){
	$("#step1_smt_btn").unbind("click");
	$("#step1_smt_btn").bind("click",function(event){
		var category = $("input[name=P_Category]:checked").val();
		if (category && category!=""){
			//if (!LCProposal) LCProposal = new Array();
			LCProposal["Category"] = category;
			$.mobile.changePage("step-2.html?ver="+version, {reloadPage : false, transition: "slide", reverse:false});
		}else{
			alert("请指定正确的改善类别！");
		}
	});
}

function pageInit_Step2(){
	if (!LCProposal){
		$.mobile.changePage("step-1.html?ver="+version, {reloadPage : false, transition: "slide", reverse:true});
		return;
	}
	$("#st2_proposal_name").val(LCProposal["Title"]);
	$("#st2_problem_desc").val(LCProposal["Description"]);
	$("#st2_improvement").val(LCProposal["Advice"]);
	$("#st2_uid").val(LCProposal["uJobNum"]);
	$("#st2_uname").val(LCProposal["uName"]);
	setSelectVal("st2_progress",LCProposal["AuditInfo"]["FollowProgress"]);
}

function initDataInput_Step2(){
	if (!LCProposal){
		$.mobile.changePage("step-1.html?ver="+version, {reloadPage : false, transition: "slide", reverse:true});
		return false;
	}
	var pTitle = $("#st2_proposal_name").val().trim();
	var pDesc = $("#st2_problem_desc").val().trim();
	var pAdvice = $("#st2_improvement").val().trim();
	if (pTitle.length<1 || pTitle.length>20){
		alert("提案名称请输入1～20个字！");return false;
	}else if (pDesc.length<1 || pDesc.length>150){
		alert("问题描述请输入1～150个字！");return false;
	}else if (pAdvice.length<1 || pAdvice.length>150){
		alert("改善建议请输入1～150个字！");return false;
	}
	var pJNum = $("#st2_uid").val().trim();
	var pUName = $("#st2_uname").val().trim();
	if (pJNum!="" || pUName!=""){
		if (pJNum.length!=7){
			alert("您输入的共同提案者工号不正确！");return false;
		}else if (pUName.length<2||pUName.length>5){
			alert("您输入的共同提案者姓名不正确！");return false;
		}
	}
	LCProposal["Title"] = pTitle;
	LCProposal["Description"] = pDesc;
	LCProposal["Advice"] = pAdvice;
	LCProposal["uJobNum"] = pJNum;
	LCProposal["uName"] = pUName;
	LCProposal["AuditInfo"]["FollowProgress"] = $("#st2_progress").val();
	return true;
}

function pageDataInit_Step2(){
	$("#step2_1_btn").unbind("click");
	$("#step2_1_btn").bind("click",function(event){
		if (initDataInput_Step2())
			$.mobile.changePage("step-1.html?ver="+version, {reloadPage : false, transition: "slide", reverse:true});
	});
	$("#step2_smt_btn").unbind("click");
	$("#step2_smt_btn").bind("click",function(event){
		if (initDataInput_Step2())
			$.mobile.changePage("step-3.html?ver="+version, {reloadPage : false, transition: "slide", reverse:false});
	});
	autoHideFooter();
}

function pageInit_Step3(){
	if (!LCProposal){
		$.mobile.changePage("step-1.html?ver="+version, {reloadPage : false, transition: "slide", reverse:true});
		setTimeout(function(){$.mobile.changePage("step-1.html?ver="+version, {reloadPage : false, transition: "slide", reverse:true});},300);
		return;
	}
	$("#attach_upload_toolbar span p b:nth-child(1)").html(MaxUploadFileCount);
	$("#attach_upload_toolbar span p b:nth-child(2)").html(convertFileSize(MaxUploadFileLength));
	$("#st3_sonum").val(LCProposal["YieldingInfo"]["SONum"]);
	$("#st3_ord_qty").val(LCProposal["YieldingInfo"]["OrderQty"]);
	$("#st3_eqid").val(LCProposal["YieldingInfo"]["EQID"]);
	$("#st3_eqname").val(LCProposal["YieldingInfo"]["EQName"]);
	$("#st3_worker_qty_now").val(LCProposal["YieldingInfo"]["WorkersNow"]);
	$("#st3_worker_qty_after").val(LCProposal["YieldingInfo"]["WorkersOptimized"]);
	$("#st3_efficiency_now").val(LCProposal["YieldingInfo"]["EffNow"]);
	$("#st3_efficiency_after").val(LCProposal["YieldingInfo"]["EffOptimized"]);
	$("#st3_badrate_now").val(LCProposal["YieldingInfo"]["DPRateNow"]);
	$("#st3_badrate_after").val(LCProposal["YieldingInfo"]["DPRateOptimized"]);
	$("#st3_other_result").val(LCProposal["YieldingInfo"]["OtherResult"]);
	/*
	if (!isEmpty(ItemOptions)){
		var seiOpts = $("#st3_itname").prop('options');
		seiOpts.length=0;
		for (var i=0;i<ItemOptions.length;i++){
			seiOpts.add(new Option(ItemOptions[i],ItemOptions[i]));
		}
	}
	*/
	$("#st3_itname").val(LCProposal["YieldingInfo"]["ItemName"]);//setSelectVal("st3_itname",LCProposal["YieldingInfo"]["ItemName"]);
	for (var i=0;i<inputFieldsSettings.length;i++){
		if (inputFieldsSettings[i].type==LCProposal["Category"]){
			var improve = false;
			$("table.cnt-ctn-frm-tb tr").each(function(){
				var trid = $(this).prop("id");
				if (trid.length>0){
					if ($.inArray(trid, inputFieldsSettings[i].fields)>=0){
						improve = improve || trid.indexOf("improve_")==0;
						if ($.inArray(trid, inputFieldsSettings[i].require)<0)
							$(this).removeClass("cnt-ctn-frm-tb-optional-tr").addClass("cnt-ctn-frm-tb-optional-tr");
					}else $(this).removeClass("cnt-ctn-frm-tb-hide-tr").addClass("cnt-ctn-frm-tb-hide-tr");
				}
			});
			if (!improve) $("#improvements_tb").css("display","none");
			break;
		}
	}
	renderStep3AttachList();
}

function initDataInput_Step3(){
	if (!LCProposal){
		$.mobile.changePage("step-1.html?ver="+version, {reloadPage : false, transition: "slide", reverse:true});
		return false;
	}
	var pSoNum = $("#st3_sonum").val().trim();
	var pOrdQty = $("#st3_ord_qty").val().trim();
	var pEqId = $("#st3_eqid").val().trim();
	var pEqName = $("#st3_eqname").val().trim();
	if ($("#fields_so_ord").hasClass("cnt-ctn-frm-tb-hide-tr")){
		var pSoNum = "";
		var pOrdQty = "";
		$("#st3_itname").val("");
	}else if ($("#fields_so_ord").hasClass("cnt-ctn-frm-tb-optional-tr")){
	}else{//必填
		if (pSoNum.length==0) {alert("请输入工程单号！");return false;}
		if (pOrdQty.length==0) {alert("请输入订单数量！");return false;}
		if ($("#st3_itname").val().length==0) {alert("请指定产品名称！");return false;}
	}
	if (pSoNum.length!=0 && pSoNum.length!=8){
		alert("您输入的工程单号格式不正确！");return false;
	}
	if ($("#fields_eq").hasClass("cnt-ctn-frm-tb-hide-tr")){
		var pEqId = "";
		var pEqName = "";
	}else if ($("#fields_eq").hasClass("cnt-ctn-frm-tb-optional-tr")){
	}else{//必填
		if (pEqId.length==0) {alert("请输入机台身份证！");return false;}
		if (pEqName.length==0) {alert("请输入机台名称！");return false;}
	}
	LCProposal["YieldingInfo"]["SONum"] = pSoNum;
	LCProposal["YieldingInfo"]["OrderQty"] = pOrdQty;
	LCProposal["YieldingInfo"]["EQID"] = pEqId;
	LCProposal["YieldingInfo"]["EQName"] = pEqName;
	LCProposal["YieldingInfo"]["WorkersNow"] = $("#st3_worker_qty_now").val();
	LCProposal["YieldingInfo"]["WorkersOptimized"] = $("#st3_worker_qty_after").val();
	LCProposal["YieldingInfo"]["EffNow"] = $("#st3_efficiency_now").val();
	LCProposal["YieldingInfo"]["EffOptimized"] = $("#st3_efficiency_after").val();
	LCProposal["YieldingInfo"]["DPRateNow"] = $("#st3_badrate_now").val();
	LCProposal["YieldingInfo"]["DPRateOptimized"] = $("#st3_badrate_after").val();
	LCProposal["YieldingInfo"]["ItemName"] = $("#st3_itname").val();
	LCProposal["YieldingInfo"]["OtherResult"] = $("#st3_other_result").val();
	/*
	ItemOptions.splice(0,ItemOptions.length);
	var seiOpts = $("#st3_itname").prop('options');
	for (var i=0;i<seiOpts.length;i++){
		ItemOptions.push(seiOpts[i].value);
	}
	*/
	return true;
}

function ajaxGetSEIName(sonum){
	if (sonum==""){
		//$("#st3_itname").prop('options').length=0;
		//setSelectVal("st3_itname","");
		$("#st3_sonum").val("");
		$("#st3_itname").val("");
		return;
	}
	showLoadingMsg("正在刷新产品名称 ...");
	var dataObj = {"so":sonum};
	$.ajax({
		type: DataMethod,
		url: noCacheUrl(DataFeederBase+GetSEIInfo),
		dataType: "json",
		contentType: "application/json; charset=utf-8",
		data: convertObj2AjaxData(dataObj),
		success: function(data){
			if (data && data.d && data.d.IsOK){
				var ord = data.d.ResultObject;
				if (isEmpty(ord)||!ord.SONo||!ord.SOChiProgramName){
					alert("抱歉！查无此SO："+$("#st3_sonum").val());
					$("#st3_sonum").val("");
					$("#st3_itname").val("");
				}else{
					$("#st3_itname").val(ord.SOChiProgramName);
				}
				/*
				var seiOpts = $("#st3_itname").prop('options');
				seiOpts.length=0;
				var seiArr = $.secureEvalJSON(data.d.ResultObject);
				if (isEmpty(seiArr)||!seiArr.length||seiArr.length<=0){
					alert("抱歉！查無此SO："+$("#st3_sonum").val());
					$("#st3_sonum").val("");
					setSelectVal("st3_itname","");
				}else{
					for (var i=0;i<seiArr.length;i++){
						seiOpts.add(new Option(seiArr[i]["SEIName"],seiArr[i]["SEIName"]));
					}
					setSelectVal("st3_itname",seiArr[0]["SEIName"]);
				}
				*/
			}else{
				if (data && data.d && data.d.SysMsg) alert(data.d.SysMsg);
				else alert("抱歉！"+DataProcessError+"，无法获取对应的产品名称，请稍后再试！");
				$("#st3_sonum").val("");
				$("#st3_itname").val("");//setSelectVal("st3_itname","");
			}
			hideMsg();
		},
		error: function (jqXHR, textStatus, errorThrown) {
			alert("抱歉！因"+DataTransError+"的原因，無法獲取對應的產品名稱列表！");
			$("#st3_sonum").val("");
			$("#st3_itname").val("");//setSelectVal("st3_itname","");
			hideMsg();
		},
		timeout: 8000
	});
}

function ajaxSubmitProposal(){
	showLoadingMsg();
	var fileArr = new Array();
	if (!isEmpty(AttachList)&&AttachList.length>0){
		for (var i=0;i<AttachList.length;i++) fileArr.push(AttachList[i].FilePath);
	}
	//delete ItemOptions;
	var dataObj = {"dataArr":toJSONStr(LCProposal),"fileArr":toJSONStr(fileArr),"uJobNum":LCProposal["uJobNum"],"uName":LCProposal["uName"]};
	$.ajax({
		type: DataMethod,
		url: noCacheUrl(DataFeederBase+SubmitProposal),
		dataType: "json",
		contentType: "application/json; charset=utf-8",
		data: convertObj2AjaxData(dataObj),
		success: function(data){
			if (data && data.d && data.d.IsOK){
				LCProposal = false;
				$.mobile.changePage("step-done.html?ver="+version, {reloadPage : false, transition: "slide", reverse:false, data: {"smt-num":data.d.SysMsg}});
			}else{
				alert(data.d.SysMsg);
			}
			hideMsg();
		},
		error: function (jqXHR, textStatus, errorThrown) {
			alert("抱歉！因"+DataTransError+"的原因，您的提案资料暂时未能提交！");
			hideMsg();
		},
		timeout: 8000
	});
}

function initAttachUploadPopup(){
	$("#attach_upload_speed").parent().css("display","none");
	$("#attach_imgsize").parent().css("display","none");
	$("#attach_pop_upload_btn").removeAttr("data-flag");
	$("#attach_pop_upload_btn").text("上傳");
	$("#attach_pop_cancel_btn").text("取消");
	$("#attach_pop_upload_btn").button("enable");
	$("#attach_pop_upload_btn").button("refresh");
	$("#attach_pop_cancel_btn").button("refresh");
}

function showSheetUploadInfo(fileName,fileType,fileSize,imgWidth,imgHeight,base64Content,isAndroid){
	$("#attach_imgname").html(fileName);
	$("#attach_imgtype").html(fileType);
	$("#attach_upload_size").html(fileSize+" KB");
	if (!isAndroid){
		var maxHR = 0.5,maxWR=0.7;
		var h = $(window).height(),w=$(window).width();
		$("#attach_imgsize").html(imgWidth + " × " + imgHeight);
		$("#attach_imgsize").parent().css("display","block");
		$("#attach_upload_img").html('<img src="' + base64Content + '" alt="' + fileName + '" title="' + fileName + '" style="max-width:'+(w*maxWR)+'px;max-height:'+(h*maxHR)+'px;">');
	}
	$("#attach_upload_info").popup("open");
	if (isWXEmbedded) $("#attach_upload_info-popup").css("top","1.5em");
	setTimeout(function(){
		var w = $("#attach_upload_info-popup").width();
		var ww = $(window).width();
		var margin = (w>ww)?12:(ww-w)/2;
		$("#attach_upload_info-popup").css("left",margin+"px").css("right",margin+"px");
	},50);
}

function setAttachUploadPercent(percent,msg){
	var ulbtn = $("#attach_pop_upload_btn");
	var ccbtn = $("#attach_pop_cancel_btn");
	if (percent>=0&&percent<100){
		ulbtn.text(percent + "%");
		ulbtn.button("refresh");
	}else if (percent==100){
		ulbtn.text(msg?msg:"上傳完成");
		ulbtn.attr("data-flag",1);
		ulbtn.button("refresh");
		ccbtn.text("關閉");
		ccbtn.button("refresh");
	}else{
		ulbtn.text(msg?msg:"上傳失敗");
		ulbtn.parent().buttonMarkup({theme:"e"});
		ulbtn.attr("data-flag",1);
		ulbtn.button("refresh");
		ccbtn.text("關閉");
		ccbtn.button("refresh");
	}
}

//定义获取图片信息的函数
function getAttachFiles(e) {
	$("#attach_pop_upload_btn").parent().buttonMarkup({theme:"b"});
    e = e || window.event;
    //获取file input中的图片信息列表
    var files = e.target.files,
    //验证是否是图片文件的正则
    reg = /image\/.*/i;
    for (var i = 0,f; f = files[i]; i++) {
        //把这个if判断去掉后，也能上传别的文件
		var ft = f.type;
		if(!ft) ft = "image/" + f.name.split(".").pop().toLowerCase();
        if (!reg.test(ft)) {
            alert("無效的照片格式！");
			$("#UploadPicForm").trigger("reset");
            //跳出循环
            continue;
        }else{
			var reader = new FileReader();
			reader.onload = (function(file) {
				//获取图片相关的信息
				if (file.size>MaxUploadFileLength){
					alert("單次上傳的文件總大小不能超過"+convertFileSize(MaxUploadFileLength)+"！");
					$("#UploadPicForm").trigger("reset");
				}else{
					var fileSize = (file.size / 1024).toFixed(2),fileName = file.name,fileType = file.type;
					if(!fileType) fileType = "image/" + fileName.split(".").pop().toLowerCase();
					return function(e) {
						//获取图片的宽高
						var img = new Image();
						img.src = e.target.result;
						initAttachUploadPopup();
						showLoadingMsg();
						img.addEventListener("load", function(){
							showSheetUploadInfo(fileName,fileType,fileSize,img.width,img.height,e.target.result,false);
							hideMsg();
						}, false);
					}
				}
			})(f);
			//读取文件内容
			reader.readAsDataURL(f);
		}
    }
}

function renderStep3AttachList(){
	var attachCount = 0;
	var attachSizeSum = 0;
	if (!isEmpty(AttachList)&&AttachList.length>0){
		attachCount = AttachList.length;
		for (var i=0;i<AttachList.length;i++)
			attachSizeSum += AttachList[i].FileSize;
	}
	var limitexceed = (attachCount>=MaxUploadFileCount||attachSizeSum>=MaxUploadFileLength);
	$("#step3_upload_attach_btn").button(limitexceed?"disable":"enable").button("refresh");
	$("#attach_upload_toolbar span div b:nth-child(1)").html(attachCount);
	$("#attach_upload_toolbar span div b:nth-child(2)").html(convertFileSize(attachSizeSum));
}

var frameInterval = false;
var uploadStart = false;
var uploadComplete = function(){
	var diff = (new Date()).getTime()-uploadStart.getTime();
	if (diff/1000<30){ //30秒超时
		var responseText = $("#UploadPicFrame").contents().find("body").html();
		if (responseText!=null && responseText!=""){
			var msgObj = $.secureEvalJSON(responseText);
			if (msgObj){
				if (msgObj.IsOK){
					setAttachUploadPercent(100);
					if (!isEmpty(msgObj.ResultObject)) AttachList=msgObj.ResultObject;
					else AttachList = null;
					renderStep3AttachList();
				}else{
					setAttachUploadPercent(-1,"上传失败");
					if (!isEmpty(msgObj.ResultObject)&&msgObj.ResultObject.length>0) AttachList=msgObj.ResultObject;
					renderStep3AttachList();
					//alert(msgObj.SysMsg);
				}
			}else{
				setAttachUploadPercent(-1,"服务器响应错误");
				//alert("服務器響應信息錯誤！");
			}
		}else return;
	}else{
		setAttachUploadPercent(-1,"网络超时");
	}
	if (frameInterval) clearInterval(frameInterval);
	$("#UploadPicForm").trigger("reset");
	//$("#UploadPicFrame").contents().find("body").html("");
	$("#UploadPicFrame").remove();
	hideMsg();
}

function pageDataInit_Step3(){
	$("#step3_2_btn").unbind("click");
	$("#step3_2_btn").bind("click",function(event){
		if (initDataInput_Step3())
			$.mobile.changePage("step-2.html?ver="+version, {reloadPage : false, transition: "slide", reverse:true});
	});
	$("#step3_smt_btn").unbind("click");
	$("#step3_smt_btn").bind("click",function(event){
		if (!initDataInput_Step3()) return;
		ajaxSubmitProposal();
	});
	$('#step3 input.number').each(function(){
		$(this).unbind("focus");
		$(this).bind("focus",function(){
			$(this).prop("type","number");
		});
		$(this).unbind("blur");
		$(this).bind("blur",function(){
			$(this).prop("type","text");
		});
		$(this).unbind("change");
		$(this).bind("change",function(){
			var numval = parseInt($(this).val());
			if (isNaN(numval)){
				alert("请输入数字！");
				$(this).val("");
			}else $(this).val(numval);
		});
		/*
		$(this).keydown(function(e){
			if (e.keyCode<48||e.keyCode>57) return false;
			return true;
		});
		$(this).keyup(function(e){
			if (e.keyCode<48||e.keyCode>57) return false;
			return true;
		});
		*/
	});
	$("#st3_eqid").unbind("blur");
	$("#st3_eqid").bind("blur",function(event){
		var eqid = $(this).val().trim().replaceAll('-','');
		if (eqid.length==0) return;
		var fmteqid = eqid.charAt(0);
		if (eqid.length>1) fmteqid += '-'+eqid.charAt(1);
		if (eqid.length>2) fmteqid += '-'+eqid.substr(2,3);
		if (eqid.length>5) fmteqid += '-'+eqid.substr(5);
		$(this).val(fmteqid.toUpperCase());
	});
	$("#st3_sonum").unbind("change");
	$("#st3_sonum").bind("change",function(){
		$(this).val($(this).val().toUpperCase().trim());
		ajaxGetSEIName($(this).val());
	});
	/*
	$("#st3_itname").unbind("change");
	$("#st3_itname").bind("change",function(){
		setSelectVal("st3_itname",$(this).val());
	});
	*/
	if (window.File && window.FileList && window.FileReader && window.Blob) {
		$("#step3_attach1").unbind("change");
		$("#step3_attach1").bind("change",getAttachFiles);
	} else {
		alert("本機不支持文件上傳！");
	}

	$("#step3_upload_attach_btn").unbind("click");
	$("#step3_upload_attach_btn").bind("click",function(){
		 $('#step3_attach1').trigger('click');
		 return false;
	});
	$("#step3_view_attach_btn").unbind("click");
	$("#step3_view_attach_btn").bind("click",function(){
		 return false;
	});

	$("#attach_pop_upload_btn").unbind("click");
	$("#attach_pop_upload_btn").bind("click",function(){
		if ($("#step3_attach1").val()==""){
			alert("请选择要上传的文件！");
		}else{
			$("#UploadPicForm").prop("action",UploadFile);
			$("#UploadPicFrame").remove();
			//$("#UploadPicFormDiv").children("iframe").remove();
			$("#UploadPicFormDiv").append('<iframe name="UploadPicFrame" id="UploadPicFrame" src=""></iframe>');
			$("#UploadPicForm").prop("target","UploadPicFrame");
			$(this).button("disable");
			$(this).text("正在上傳 ...");
			$(this).button("refresh");
			showLoadingMsg("正在上传 ...");
			uploadStart = new Date();
			$('#UploadPicForm').submit();
			if (frameInterval) clearInterval(frameInterval);
			frameInterval = setInterval(uploadComplete,100);
		}
	});
	$("#attach_pop_cancel_btn").unbind("click");
	$("#attach_pop_cancel_btn").bind("click",function(){
		var flag = $("#attach_pop_upload_btn").attr("data-flag");
		if (flag && flag=="0") alert("照片上傳中，暫不能取消，請稍候...");
		else{
			$("#attach_upload_info").popup("close");
			$("#UploadPicForm").trigger("reset");
		}
	});

	autoHideFooter();
}

function pageInit_StepDone(){
	LCProposal = false;
	var smtNum = getUrlParameterByName(window.location.href,"smt-num");
	if (smtNum == ""){
		var dataUrl = $("#stepdone" ).attr("data-url");
		smtNum = getUrlParameterByName(dataUrl,"smt-num");
	}
	if (smtNum!=""){
		$("#pNumberShow").children("b").html(smtNum);
	}else{
		$("#pNumberShow").css("display","none");
	}
}
function pageDataInit_StepDone(){
	$("#step1").remove();
	$("#step2").remove();
	$("#step3").remove();
	$("#return_wx_btn").unbind("click");
	$("#return_wx_btn").bind("click",closeMyWindow);
	if (window.parent&&window.parent.ajaxData_proposalSum){
		window.parent.ajaxData_proposalSum();
	}
}

setupKeyboardHandler(27,function(){
	var page = window.location.pathname;
	page = page.substr(page.lastIndexOf('/')+1,page.length);
	if (page=='step-3.html'){
		$("#step3_2_btn").trigger("click");
	}else if (page=='step-2.html'){
		$("#step2_1_btn").trigger("click");
	}else if (page=='step-1.html'){
		if (confirm("确定要放弃提案录入？")){
			closeMyWindow();
		}
	}else{
		var popups = $(".ui-popup-active");
		if (popups.length>0){
			var popid = popups.prop("id");
			popid = popid.substr(0,popid.lastIndexOf("-popup"));
			$("#"+popid).popup("close");
			return;
		}
		closeMyWindow();
	}
});