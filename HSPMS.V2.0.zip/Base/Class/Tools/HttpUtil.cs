﻿using System;
using System.Text;
using System.Web;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;

namespace LEO.Project.Tools
{
    public class HttpUtil
    {

        private static System.Net.WebProxy defaultWebProxy = null;//new WebProxy("192.168.56.101", 3128);
        private static NetworkCredential proxyCredential = null;//new NetworkCredential("ntlogin", "pass", "hsgroup");

        /// <summary>
        /// 读取请求对象的内容
        /// 只能读一次
        /// </summary>
        /// <param name="request">HttpRequest对象</param>
        /// <returns>string</returns>
        public static string ReadRequest(HttpRequest request)
        {
            string reqStr = string.Empty;
            using (Stream s = request.InputStream)
            {
                using (StreamReader reader = new StreamReader(s, Encoding.UTF8))
                {
                    reqStr = reader.ReadToEnd();
                }
            }
            return reqStr;
        }

        /// <summary>
        /// 使用Get方法获取字符串结果（没有加入Cookie）
        /// </summary>
        /// <param name="url"></param>
        /// <param name="encoding"></param>
        /// <returns></returns>
        public static string HttpWebClientGet(string url, Encoding encoding)
        {
            WebClient wc = new WebClient();
            wc.Encoding = encoding ?? Encoding.UTF8;
            return wc.DownloadString(url);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="url"></param>
        /// <param name="encoding"></param>
        /// <returns></returns>
        public static string HttpGet(string url, Encoding encoding)
        {
            System.Net.HttpWebRequest request = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(url);

            // add by jimyli ---
            if (proxyCredential!=null) defaultWebProxy.Credentials = proxyCredential;
            if (defaultWebProxy!=null) request.Proxy = defaultWebProxy;
            // add by jimyli ---

            request.Method = "get";

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            using (Stream responseStream = response.GetResponseStream())
            {
                using (StreamReader myStreamReader = new StreamReader(responseStream, encoding ?? Encoding.GetEncoding("utf-8")))
                {
                    string retString = myStreamReader.ReadToEnd();
                    return retString;
                }
            }

        }

        public static string HttpPost(string url, string postData, Encoding encoding, CookieContainer cookieContainer)
        {
            var postBytes = postData == null ? new byte[0] : Encoding.UTF8.GetBytes(postData);


            HttpWebRequest request = WebRequest.Create(url) as HttpWebRequest;

            // add by jimyli ---
            defaultWebProxy.Credentials = proxyCredential;
            request.Proxy = defaultWebProxy;
            // add by jimyli ---

            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = postBytes.Length;
            request.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8";
            request.KeepAlive = true;

            if (cookieContainer != null)
            {
                request.CookieContainer = cookieContainer;
            }


            //直接写入流
            Stream requestStream = request.GetRequestStream();
            requestStream.Write(postBytes, 0, postBytes.Length);

 
            requestStream.Close();//关闭文件访问

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            if (cookieContainer != null)
            {
                response.Cookies = cookieContainer.GetCookies(response.ResponseUri);
            }

            using (Stream responseStream = response.GetResponseStream())
            {
                using (StreamReader myStreamReader = new StreamReader(responseStream, encoding ?? Encoding.GetEncoding("utf-8")))
                {
                    string retString = myStreamReader.ReadToEnd();
                    return retString;
                }
            }
        }

        public static string GetRequestIPAddress(HttpRequest request)
        {
            if (request == null) return "";
            string ipAddress = request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (!string.IsNullOrEmpty(ipAddress))
            {
                string[] addresses = ipAddress.Split(',');
                if (addresses.Length != 0)
                {
                    return addresses[0];
                }
            }

            return request.ServerVariables["REMOTE_ADDR"];
        }

        public static string GetRemoteIPAddress(HttpRequest request)
        {
            string IpAddress = (HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] != null
            && HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] != String.Empty)
            ? HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"]
            : HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
            return IpAddress;
        }

        public static string GetClientIPAddress(HttpRequest request)
        {
            string result = String.Empty;

            result = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (result != null && result != String.Empty)
            {
                //可能有代理 
                if (result.IndexOf(".") == -1)    //没有“.”肯定是非IPv4格式 
                    result = null;
                else
                {
                    if (result.IndexOf(",") != -1)
                    {
                        //有“,”，估计多个代理。取第一个不是内网的IP。 
                        result = result.Replace(" ", "").Replace("'", "");
                        string[] temparyip = result.Split(",;".ToCharArray());
                        for (int i = 0; i < temparyip.Length; i++)
                        {
                            if (IsIPAddress(temparyip[i])
                                && temparyip[i].Substring(0, 3) != "10."
                                && temparyip[i].Substring(0, 7) != "192.168"
                                && temparyip[i].Substring(0, 7) != "172.16.")
                            {
                                return temparyip[i];    //找到不是内网的地址 
                            }
                        }
                    }
                    else if (IsIPAddress(result)) //代理即是IP格式 
                        return result;
                    else
                        result = null;    //代理中的内容 非IP，取IP 
                }

            }

            string IpAddress = (HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] != null && HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] != String.Empty) ? HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] : HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
            if (null == result || result == String.Empty)
                //result = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                result = IpAddress;

            if (result == null || result == String.Empty)
                result = HttpContext.Current.Request.UserHostAddress;

            return result; 
        }

        /**/
        /// <summary>
        /// 判断是否是IP地址格式 0.0.0.0
        /// </summary>
        /// <param name="str1">待判断的IP地址</param>
        /// <returns>true or false</returns>
        public static bool IsIPAddress(string str1)
        {
            if (str1 == null || str1 == string.Empty || str1.Length < 7 || str1.Length > 15) return false;

            string regformat = @"^\d{1,3}[\.]\d{1,3}[\.]\d{1,3}[\.]\d{1,3}$";

            Regex regex = new Regex(regformat, RegexOptions.IgnoreCase);
            return regex.IsMatch(str1);
        }

        public static string GetHttpContextNTFullName(HttpContext httpContext)
        {
            if (httpContext != null && httpContext.User != null && httpContext.User.Identity != null &&
                !string.IsNullOrEmpty(httpContext.User.Identity.Name))
            {
                return httpContext.User.Identity.Name;
            }
            else return null;
        }

        public static string GetHttpContextNTName(HttpContext httpContext)
        {
            string name = GetHttpContextNTFullName(httpContext);
            if (string.IsNullOrEmpty(name)) return null;
            string[] arr = name.Split('\\');
            return arr.Length > 0 ? arr[arr.Length - 1] : "";
        }

    }
}
