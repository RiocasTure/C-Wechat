﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LEO.Project.Tools
{
    public class WriteLog
    {

        public static void AppInfo(string msg)
        {
            Dictionary<string, object> dic = new Dictionary<string, object>();
            dic.Add("AppMsg", string.IsNullOrEmpty(msg) ? "N/A" : msg);
            Microsoft.Practices.EnterpriseLibrary.Logging.Logger.Write(string.Empty, "APPINFO", dic);
        }

        public static void Info(string msg)
        {
            Dictionary<string, object> dic = new Dictionary<string, object>();
            dic.Add("InfoMsg", string.IsNullOrEmpty(msg) ? "N/A" : msg);
            Microsoft.Practices.EnterpriseLibrary.Logging.Logger.Write(string.Empty, "INFORMATION", dic);
        }

        public static void Error(string msg, Exception error)
        {
            Dictionary<string, object> dic = new Dictionary<string, object>();
            dic.Add("ErrMsg", string.IsNullOrEmpty(msg) ? "N/A" : msg);
            if (error == null)
                Microsoft.Practices.EnterpriseLibrary.Logging.Logger.Write(string.Empty, "ERROR", dic);
            else
                Microsoft.Practices.EnterpriseLibrary.Logging.Logger.Write(error, "ERROR", dic);
        }

        public static string FlattenException(Exception exception)
        {
            var stringBuilder = new StringBuilder();

            while (exception != null)
            {
                stringBuilder.Insert(0, "\r\n");
                stringBuilder.Insert(0, exception.StackTrace);
                stringBuilder.Insert(0, exception.Message);

                exception = exception.InnerException;
            }

            return stringBuilder.ToString();
        }

    }
}
