﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using Microsoft.International.Converters.TraditionalChineseToSimplifiedConverter;

namespace LEO.Project.Tools
{
    public class StringUtils
    {
        public static string ToString(object obj)
        {
            if (obj == null) return "";
            if (obj is DateTime?)
            {
                DateTime? dt = (DateTime?)obj;
                if (dt.HasValue) return dt.Value.ToString(DateTimeUtil.FormatDMY);
                return "";
            }
            return obj.ToString();
        }

        /**
         * 转全角的函数(SBC case)
         * 任意字符串 -> 全角字符串
         * 全角空格为12288，半角空格为32
         * 其他字符半角(33-126)与全角(65281-65374)的对应关系是：均相差65248
         */
        public static String ToSBC(String input)
        {
            char[] c = input.ToCharArray();
            for (int i = 0; i < c.Length; i++)
            {
                if (c[i] == 32)
                {
                    c[i] = (char)12288;
                    continue;
                }
                if (c[i] < 127)
                    c[i] = (char)(c[i] + 65248);
            }
            return new String(c);
        }

        /**
         * 转半角的函数(DBC case)
         * 任意字符串 -> 半角字符串
         * 全角空格为12288，半角空格为32
         * 其他字符半角(33-126)与全角(65281-65374)的对应关系是：均相差65248
         */
        public static String ToDBC(String input)
        {
            char[] c = input.ToCharArray();
            for (int i = 0; i < c.Length; i++)
            {
                if (c[i] == 12288)
                {
                    c[i] = (char)32;
                    continue;
                }
                if (c[i] > 65280 && c[i] < 65375)
                    c[i] = (char)(c[i] - 65248);
            }
            return new String(c);
        }

        public static string ByteArrayToString(byte[] ba)
        {
            StringBuilder hex = new StringBuilder(ba.Length * 2);
            foreach (byte b in ba)
                hex.AppendFormat("{0:x2}", b);
            return hex.ToString();
            /*
            string hex = BitConverter.ToString(ba);
            return hex.Replace("-", "");
            */
        }

        public static byte[] StringToByteArray(String hex)
        {
            int NumberChars = hex.Length / 2;
            byte[] bytes = new byte[NumberChars];
            using (var sr = new StringReader(hex))
            {
                for (int i = 0; i < NumberChars; i++)
                    bytes[i] =
                      Convert.ToByte(new string(new char[2] { (char)sr.Read(), (char)sr.Read() }), 16);
            }
            return bytes;
            /*
            int NumberChars = hex.Length;
            byte[] bytes = new byte[NumberChars / 2];
            for (int i = 0; i < NumberChars; i += 2)
                bytes[i / 2] = Convert.ToByte(hex.Substring(i, 2), 16);
            return bytes;
            */
        }

        public static string ReplaceEndStr(string src, string oldstr, string newstr)
        {
            if (string.IsNullOrEmpty(src) || string.IsNullOrEmpty(oldstr)) return src;
            if (src.EndsWith(oldstr)) return src.Substring(0, src.Length - oldstr.Length)+(string.IsNullOrEmpty(newstr)?"":newstr);
            return src;
        }

        static string randomSeed = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ~_-";
        public static string RandomString()
        {
            Random r = new Random();
            string result = string.Empty;

            //生成一个8位长的随机字符，具体长度可以自己更改
            for (int i = 0; i < 12; i++)
            {
                int m = r.Next(0, randomSeed.Length);//这里下界是0，随机数可以取到，上界应该是75，因为随机数取不到上界，也就是最大74，符合我们的题意
                string s = randomSeed.Substring(m, 1);
                result += s;
            }

            return result;
        }

        public static int ConvertToInt(string str)
        {
            if (!string.IsNullOrEmpty(str))
            try
            {
                return Convert.ToInt32(str);
            }
            catch { }
            return 0;
        }
    }

    public class ChineseConvert
    {
        private static readonly char[,] SepcialChars = new char[,] {
            { '钟', '锺' }, { '升', '昇' }, { '勋', '勳' }, { '扎', '紮' }, { '征', '徵' }, { '伙', '夥' }, 
            { '镕', '熔' }, { '鹍', '鶤' }, { '于', '於' }, { '秾', '穠' }, { '凌', '淩' }
        };
        //,  { '杰', '傑' }, { '萬', '万' }, { '云', '雲' }, { '愿', '願' }, { '余', '餘' }, { '洁', '潔' }, { '钻', '鑽' }, { '圣', '聖' }, { '里', '裡' }, { '并', '並' }, { '发', '發' }, { '迭', '疊' }, { '艳', '豔' }, { '松', '鬆' }, { '岳', '嶽' }, { '梁', '樑' }, { '红', '紅' }, { '丽', '麗' }, { '范', '範' }, { '姜', '薑' }, { '润', '潤' } 
        private static string regExpression = "[\u4e00-\u9fa5]";
        public static bool CheckChineseMatch(string src, string dst)
        {
            if (string.IsNullOrEmpty(src) || string.IsNullOrEmpty(dst)) return false;
            if (src.Length != dst.Length) return false;
            for (int i = 0; i < src.Length; i++)
            {
                if (src[i] != dst[i])
                {
                    string t = new string(src[i], 1), s = new string(dst[i], 1);
                    if (Regex.IsMatch(t, regExpression) && Regex.IsMatch(s, regExpression))
                    {
                        t = ChineseConverter.Convert(t, ChineseConversionDirection.TraditionalToSimplified);
                        s = ChineseConverter.Convert(s, ChineseConversionDirection.TraditionalToSimplified);
                        if (t != s)
                        {
                            bool bMatch = false;
                            for (int j = 0; j < SepcialChars.GetLength(0); j++)
                            {
                                if (t[0] == SepcialChars[j, 0] || t[0] == SepcialChars[j, 1])
                                {
                                    if (s[0] == SepcialChars[j, 0] || s[0] == SepcialChars[j, 1])
                                    {
                                        bMatch = true;
                                        break;
                                    }
                                    else return false;
                                }
                            }
                            if (!bMatch) return false;
                        }
                    }
                    else return false;
                }
            }
            return true;
        }
    }

    public class RegValid
    {
        public static bool IsMobile(string mobile)
        {
            bool bl = Regex.IsMatch(mobile, @"^0?(13[0-9]|15[012356789]|17[0678]|18[0-9]|14[57])[0-9]{8}$");
            return bl;
        }
    }

    public class RegexHelper
    {
        public static string[] ExtractByReg(string str, string pattern)
        {
            List<string> lst = new List<string>();
            MatchCollection matches = Regex.Matches(str, pattern);
            if (matches.Count > 0)
                foreach (Match m in matches) lst.Add(m.Groups[1].ToString());
            return lst.ToArray();
        }
    }

}
