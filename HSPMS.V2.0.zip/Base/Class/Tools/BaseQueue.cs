﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Threading;

namespace LEO.Project.Tools
{
    public abstract class BaseQueue<T> : IDisposable where T : class
    {
        object locker = new object();
        bool loop = true;
        Thread worker;
        Queue<T> msgQ = new Queue<T>();
        public BaseQueue()
        {
            (worker = new Thread(Process)).Start();
        }
        public void Dispose()
        {
            PushMsg(null);
            loop = false;
            worker.Join();
        }

        public void PushMsg(T msg)
        {
            lock (locker)
            {
                if (msg == null) msgQ.Clear();
                else msgQ.Enqueue(msg);
                Monitor.PulseAll(locker);
            }
        }

        public int Count
        {
            get
            {
                return msgQ.Count;
            }
        }

        void Process()
        {
            while (loop)
            {
                T msg;
                lock (locker)
                {
                    while (msgQ.Count == 0) Monitor.Wait(locker);
                    msg = msgQ.Dequeue();
                }
                if (!loop) break;
                Handle(msg);
            }
        }

        public abstract void Handle(T msg);
    }
}
