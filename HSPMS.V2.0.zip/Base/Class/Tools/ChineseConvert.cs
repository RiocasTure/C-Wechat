    public class ChineseConvert
    {
        ///
        /// 使用系統 kernel32.dll 進行轉換
        ///
        private const int LocaleSystemDefault = 0x0800;
        private const int LcmapSimplifiedChinese = 0x02000000;
        private const int LcmapTraditionalChinese = 0x04000000;
        private static readonly char[,] SepcialChars = new char[,] {
            { '钟', '锺' }, { '升', '昇' }, { '勋', '勳' }, { '扎', '紮' }, { '征', '徵' }, { '伙', '夥' }, 
            { '镕', '熔' }, { '鹍', '鶤' }, { '于', '於' }, { '秾', '穠' }, { '凌', '淩' }
        };
        //,  { '杰', '傑' }, { '萬', '万' }, { '云', '雲' }, { '愿', '願' }, { '余', '餘' }, { '洁', '潔' }, { '钻', '鑽' }, { '圣', '聖' }, { '里', '裡' }, { '并', '並' }, { '发', '發' }, { '迭', '疊' }, { '艳', '豔' }, { '松', '鬆' }, { '岳', '嶽' }, { '梁', '樑' }, { '红', '紅' }, { '丽', '麗' }, { '范', '範' }, { '姜', '薑' }, { '润', '潤' } 
        private static string regExpression = "[\u4e00-\u9fa5]";

        [DllImport("kernel32", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern int LCMapString(int locale, int dwMapFlags, string lpSrcStr, int cchSrc,
                                              [Out] string lpDestStr, int cchDest);

        public static string ToSimplified(string argSource)
        {
            var t = new String(' ', argSource.Length);
            LCMapString(LocaleSystemDefault, LcmapSimplifiedChinese, argSource, argSource.Length, t, argSource.Length);
            /*
            StringBuilder sb = new StringBuilder(t.Length);
            for (int i = 0; i < t.Length; i++)
            {
                var bMatch = false;
                for (int j = 0; j < SepcialChars.GetLength(0); j++)
                {
                    if (t[i] == SepcialChars[j,1])
                    {
                        bMatch = true;
                        sb.Append(SepcialChars[j, 0]);
                        break;
                    }
                }
                if (!bMatch) sb.Append(t[i]);
            }
            */
            return t;//sb.ToString();
        }

        public static string ToTraditional(string argSource)
        {
            var t = new String(' ', argSource.Length);
            LCMapString(LocaleSystemDefault, LcmapTraditionalChinese, argSource, argSource.Length, t, argSource.Length);
            /*
            StringBuilder sb = new StringBuilder(t.Length);
            bool bMatch = false;
            for (int i = 0; i < t.Length; i++)
            {
                bMatch = false;
                for (int j = 0; j < SepcialChars.GetLength(0); j++)
                {
                    if (t[i] == SepcialChars[j, 0])
                    {
                        bMatch = true;
                        sb.Append(SepcialChars[j, 1]);
                        break;
                    }
                }
                if (!bMatch) sb.Append(t[i]);
            }
            */
            return t;//sb.ToString();
        }

        public static bool CheckChineseMatch(string src, string dst)
        {
            if (string.IsNullOrEmpty(src) || string.IsNullOrEmpty(dst)) return false;
            if (src.Length != dst.Length) return false;
            for (int i = 0; i < src.Length; i++)
            {
                if (src[i] != dst[i])
                {
                    string t = new string(src[i], 1),s = new string(dst[i], 1), tmp = " ";
                    if (Regex.IsMatch(t, regExpression) && Regex.IsMatch(s, regExpression))
                    {
                        LCMapString(LocaleSystemDefault, LcmapSimplifiedChinese, t, t.Length, tmp, t.Length);
                        t = new string(tmp[0], 1);
                        LCMapString(LocaleSystemDefault, LcmapSimplifiedChinese, s, s.Length, tmp, s.Length);
                        s = new string(tmp[0], 1);
                        if (t != s)
                        {
                            bool bMatch = false;
                            for (int j = 0; j < SepcialChars.GetLength(0); j++)
                            {
                                if (t[0] == SepcialChars[j, 0] || t[0] == SepcialChars[j, 1])
                                {
                                    if (s[0] == SepcialChars[j, 0] || s[0] == SepcialChars[j, 1])
                                    {
                                        bMatch = true;
                                        break;
                                    }
                                    else return false;
                                }
                            }
                            if (!bMatch) return false;
                        }
                    }
                    else return false;
                }
            }
            return true;
        }
    }
