﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json.Linq;
using System.Reflection;

namespace LEO.Project.Tools
{
    public class JsonConvertHelper
    {
        static void JTokenIteration(Object obj, JToken root, JToken tk)
        {
            if (obj == null) return;
            string p = tk.Path;
            string[] pth = p.Split('.');
            PropertyInfo propertyInfo = obj.GetType().GetProperty(pth[pth.Length - 1]);
            if (propertyInfo == null) return;
            if (tk.HasValues)
            {
                JToken jt = root.SelectToken("$." + p);
                List<JToken> childs = jt.Children().ToList();
                if (childs.Count > 0)
                {
                    for (int i = 0; i < childs.Count; i++)
                    {
                        JTokenIteration(propertyInfo.GetValue(obj, null), root, childs[i]);
                    }
                }
                else
                {
                    ReflectionHelper.SetObjectPropertyValue(obj, propertyInfo, jt.ToString());
                }
            }
        }

        public static void SetObjectProperties(Object obj, string json)
        {
            if (obj == null || string.IsNullOrEmpty(json)) return;
            try
            {
                JObject o = JObject.Parse(json);
                List<JToken> childs = o.Children().ToList();
                for (int i = 0; i < childs.Count; i++)
                {
                    JTokenIteration(obj, o, childs[i]);
                }
            }
            catch (Exception ex)
            {
                WriteLog.Error(string.Format("JsonConvertHelper.SetObjectProperties Error:json={0}",json), ex);
            }
        }
    }
}
