﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Reflection;
using System.Configuration;
using System.Text.RegularExpressions;
using System.Collections;

namespace LEO.Project.Tools
{
    public class ReflectionHelper
    {
        public static readonly Regex ArrTagReg = new Regex(@"^[a-zA-Z_][a-zA-Z0-9_]*\[\d+\]$");
        public static readonly string ArrTagExtract_Var = @"(.*?)\[\d+\]$";
        public static readonly string ArrTagExtract_Index = @"^[a-zA-Z_][a-zA-Z0-9_]*\[(.*?)\]$";

        public static void SetObjectPropertyValue(object obj, PropertyInfo prop, object value)
        {
            if (prop == null || obj == null) return;
            Type tp = prop.PropertyType;
            try
            {
                if (tp == typeof(int))
                {
                    prop.SetValue(obj, Convert.ToInt32(value), null);
                }
                else if (tp == typeof(byte))
                {
                    prop.SetValue(obj, Convert.ToByte(value), null);
                }
                else if (tp == typeof(long))
                {
                    prop.SetValue(obj, Convert.ToInt64(value), null);
                }
                else if (tp == typeof(string))
                {
                    prop.SetValue(obj, Convert.ToString(value), null);
                }
                else if (tp == typeof(bool))
                {
                    prop.SetValue(obj, Convert.ToBoolean(value), null);
                }
                else if (tp == typeof(DateTime?))
                {
                    prop.SetValue(obj, DateTimeUtil.ParseDateTime(DateTimeUtil.FormatYMD, value==null?"":value.ToString()), null);
                }else
                    prop.SetValue(obj, Convert.ChangeType(value, prop.PropertyType), null);
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("SetObjectPropertyValue Error: obj={0},prop={1},value={2}", obj.GetType().ToString(), prop.Name,value), e);
            }
        }

        public static void SetFieldValue(FieldInfo field, object value)
        {
            if (field == null || value == null) return;
            object fv = field.GetValue(null);
            try
            {
                if (fv is int)
                {
                    field.SetValue(null, Convert.ToInt32(value));
                }
                else if (fv is byte)
                {
                    field.SetValue(null, Convert.ToByte(value));
                }
                else if (fv is long)
                {
                    field.SetValue(null, Convert.ToInt64(value));
                }
                else if (fv is string)
                {
                    field.SetValue(null, Convert.ToString(value));
                }
                else if (fv is bool)
                {
                    field.SetValue(null, Convert.ToBoolean(value));
                }
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("SetFieldValue Error: field={0},value={1}", field.ToString(), value.ToString()), e);
            }
        }

        public static void SetFieldValue(Assembly assem,string classField, object value)
        {
            if (classField == null || value == null) return;
            int idx = classField.LastIndexOf('.');
            if (idx <= 0 || idx == classField.Length) return;
            string className = classField.Substring(0, idx);
            string fieldName = classField.Substring(idx + 1);
            Type t = assem!=null?assem.GetType(className):Type.GetType(className);
            if (t == null) return;
            FieldInfo f = t.GetField(fieldName);
            SetFieldValue(f, value);
        }

        public static MemberInfo GetObjectMemberInfo(object obj, string memberName)
        {
            Type type = obj.GetType();
            MemberInfo info = type.GetField(memberName) as MemberInfo ?? type.GetProperty(memberName) as MemberInfo;
            return info;
        }

        public static PropertyInfo GetObjectProperty(object obj, string propName)
        {
            if (obj == null || string.IsNullOrEmpty(propName)) return null;
            return obj.GetType().GetProperty(propName);
        }

        public static object GetObjectPropertyValue(object obj, string propName)
        {
            PropertyInfo pi = GetObjectProperty(obj, propName);
            return pi!=null?pi.GetValue(obj, null):null;
        }

        public static object GetObjectMemberValue(object obj, string memberName)
        {
            Type type = obj.GetType();
            MemberInfo info = type.GetField(memberName) as MemberInfo ?? type.GetProperty(memberName) as MemberInfo;
            if (info == null)
            {
                return null;
            }
            object val = null;
            switch (info.MemberType)
            {
                case MemberTypes.Property:
                    PropertyInfo pi = (PropertyInfo)info;
                    val = pi.GetValue(obj, null);
                    break;
                case MemberTypes.Field:
                    FieldInfo fi = (FieldInfo)info;
                    val = fi.GetValue(obj);
                    break;
            }
            return val;
        }

        public static object GetObjectValueByExpression(Object obj, string expression)
        {
            if (obj == null || string.IsNullOrEmpty(expression)) return null;
            int idx = expression.IndexOf('.');
            if (idx > 0)
            {
                return GetObjectValueByExpression(GetObjectValueByExpression(obj,expression.Substring(0, idx)), expression.Substring(idx + 1));
            }
            if (ArrTagReg.IsMatch(expression))
            {
                string[] _vars = RegexHelper.ExtractByReg(expression, ArrTagExtract_Var);
                string[] _idxs = RegexHelper.ExtractByReg(expression, ArrTagExtract_Index);
                if (_vars.Length == 1 && _idxs.Length == 1)
                {
                    object _arrlst = GetObjectValueByExpression(obj, _vars[0]);
                    int _idx = Int32.Parse(_idxs[0]);
                    if (_arrlst!=null && _arrlst.GetType().IsArray)
                    {
                        object[] arr = (object[])_arrlst;
                        return (_idx>=0 && _idx<arr.Length)?arr[_idx]:null;
                    }
                    if (_arrlst != null && _arrlst.GetType().IsGenericType && _arrlst is IEnumerable)
                    {
                        IList<object> _list = (_arrlst as IEnumerable).Cast<object>().ToList();
                        return (_idx >= 0 && _idx < _list.Count) ? _list[_idx] : null;
                    }
                }
            }
            if (obj is Dictionary<string, object>)
            {
                Dictionary<string, object> dict = (Dictionary<string, object>)obj;
                if (dict.ContainsKey(expression)) return dict[expression];
                return null;
            }
            else
            {
                return GetObjectMemberValue(obj,expression);//GetObjectPropertyValue(obj, expression);
            }
        }
    }
}
