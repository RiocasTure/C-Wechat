﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Globalization;

namespace LEO.Project.Tools
{
    public static class DateTimeUtil
    {
        private static readonly DateTime Jan1St1970 = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        /// <summary>Get extra long current timestamp</summary>
        public static long CurrentMillis { get { return (long)((DateTime.UtcNow - Jan1St1970).TotalMilliseconds); } }

        public static long GetMillis(DateTime datetime)
        {
            return (long)((datetime.ToUniversalTime() - Jan1St1970).TotalMilliseconds);
        }

        public static DateTime ToDateTimeFromMillis(long millis)
        {
            return (new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).AddMilliseconds(millis).ToLocalTime();
        }

        public static DateTime? ParseDateTime(string format, string datetimeStr)
        {
            DateTime? date = null;
            if (!string.IsNullOrEmpty(datetimeStr))
            {
                try
                {
                    date = DateTime.ParseExact(datetimeStr, format, CultureInfo.InvariantCulture);

                }
                catch (Exception)
                {
                }
            }
            return date;
        }

        public static readonly string FormatYMD = "yyyy-MM-dd";
        public static readonly string FormatDMY = "dd/MM/yyyy";
        public static readonly string FormatDMYHM = "dd/MM/yyyy HH:mm";

    }
}
