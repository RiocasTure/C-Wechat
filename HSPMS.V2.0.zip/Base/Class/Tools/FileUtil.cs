﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.IO;
using LEO.Project.WXProposal.Data.Entity;
using System.Runtime.Serialization.Formatters.Binary;

namespace LEO.Project.Tools
{
    public class FileUtil
    {
        public static AttachmentInfo SaveUploadFile(string baseFolder, HttpPostedFile httpPostedFile)
        {
            if (string.IsNullOrEmpty(baseFolder) || httpPostedFile == null) return null;
            DateTime now = DateTime.Now;
            string dayFolder = now.ToString("yyyyMMdd");
            string fileId = Guid.NewGuid().ToString("N").ToLower();
            string fileSaveFolder = Path.Combine(baseFolder, dayFolder);
            string fileSavePath = Path.Combine(fileSaveFolder, fileId);
            try
            {
                if (!Directory.Exists(fileSaveFolder))
                {
                    Directory.CreateDirectory(fileSaveFolder);
                }
                httpPostedFile.SaveAs(fileSavePath);
                AttachmentInfo a = new AttachmentInfo();
                a.FileDate = now;
                a.FileName = httpPostedFile.FileName;
                if (string.IsNullOrEmpty(a.FileName)) a.FileName = fileId;
                int idx = a.FileName.LastIndexOf('\\');
                if (idx >= 0 && idx < a.FileName.Length - 1) a.FileName = a.FileName.Substring(idx + 1);
                a.FilePath = fileId;
                return a;
            }
            catch (Exception ex)
            {
                WriteLog.Error(string.Format("SaveUploadFile Exception:FileName={0},FileSize={1},SavePath={2}", httpPostedFile.FileName, httpPostedFile.ContentLength, fileSavePath), ex);
            }
            return null;

        }

        /*
        public static AttachmentInfo SaveUploadInputStream(string baseFolder, Stream inputStream)
        {
            if (string.IsNullOrEmpty(baseFolder) || inputStream == null) return null;
            DateTime now = DateTime.Now;
            string dayFolder = now.ToString("yyyyMMdd");
            string fileId = Guid.NewGuid().ToString("N").ToLower();
            string fileSaveFolder = Path.Combine(baseFolder, dayFolder);
            string fileSavePath = Path.Combine(fileSaveFolder, fileId);
            try
            {
                if (!Directory.Exists(fileSaveFolder))
                {
                    Directory.CreateDirectory(fileSaveFolder);
                }
                httpPostedFile.SaveAs(fileSavePath);
                AttachmentInfo a = new AttachmentInfo();
                a.FileDate = now;
                a.FileName = httpPostedFile.FileName;
                if (string.IsNullOrEmpty(a.FileName)) a.FileName = fileId;
                int idx = a.FileName.LastIndexOf('\\');
                if (idx >= 0 && idx < a.FileName.Length - 1) a.FileName = a.FileName.Substring(idx + 1);
                a.FilePath = fileId;
                return a;
            }
            catch (Exception ex)
            {
                WriteLog.Error(string.Format("SaveUploadFile Exception:FileName={0},FileSize={1},SavePath={2}", httpPostedFile.FileName, httpPostedFile.ContentLength, fileSavePath), ex);
            }
            return null;
        }
        */

        public static string SaveUploadBinFile(string baseFolder, HttpPostedFile httpPostedFile)
        {
            if (string.IsNullOrEmpty(baseFolder) || httpPostedFile == null) return null;
            DateTime now = DateTime.Now;
            string fileName = now.ToString("yyyyMMddHHmmss");
            string fileSavePath = Path.Combine(baseFolder, fileName);
            try
            {
                if (!Directory.Exists(baseFolder))
                {
                    Directory.CreateDirectory(baseFolder);
                }
                httpPostedFile.SaveAs(fileSavePath);
                return fileSavePath;
            }
            catch (Exception ex)
            {
                WriteLog.Error(string.Format("SaveUploadBinFile Exception:FileName={0},FileSize={1},SavePath={2}", httpPostedFile.FileName, httpPostedFile.ContentLength, fileSavePath), ex);
            }
            return null;

        }

        public static void ClearFileData(string filePath)
        {
            if (string.IsNullOrEmpty(filePath)) return;
            FileInfo fi = new FileInfo(filePath);
            if (fi.Exists)
            {
                try
                {
                    FileStream fcreate = File.Open(filePath, FileMode.Create); // will create the file or overwrite it if it already exists
                    StreamWriter x = new StreamWriter(fcreate);
                    x.WriteLine();
                    x.Flush();
                    x.Close();
                }
                catch (Exception ex)
                {
                    WriteLog.Error("ClearFileData Exception:" + filePath, ex);
                }
            }
            /*
            FileInfo fi = new FileInfo(saveFilePath);
            string folder = fi.Directory.FullName;
            //fi.Delete();
            //fi.Directory.Delete();
            File.Delete(saveFilePath);
            Directory.Delete(folder);
            //fi.Directory.FullName;
            */
        }

        public static long GetFileSize(string absolutePath)
        {
            try
            {
                //FileAttributes attr = File.GetAttributes(absolutePath);
                //if ((attr & FileAttributes.Directory) == FileAttributes.Directory)
                if (File.Exists(absolutePath))
                {
                    return new FileInfo(absolutePath).Length;
                }
            }
            catch (Exception ex)
            {
                WriteLog.Error("GetFileSize Exception" ,ex);
            }
            return -1;
        }

        public static string GetFile(string relativePath)
        {
            string fileContent = string.Empty;
            string path = string.Empty;
            try
            {
                Encoding encoding = Encoding.UTF8;
                path = HttpContext.Current.Request.PhysicalApplicationPath;
                path += relativePath;
                if (File.Exists(path))
                {
                    StreamReader sr = new StreamReader(path, encoding);
                    fileContent = sr.ReadToEnd();
                    sr.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return fileContent;
        }

        public static Stream GetFileStream(string absolutePath)
        {
            Stream stream = null;
            if (File.Exists(absolutePath))
            {
                StreamReader sr = new StreamReader(absolutePath);
                stream = sr.BaseStream;
            }
            return stream;
        }

        public static Stream GetExcelTemplate(string relativePath)
        {
            Stream stream = null;
            string excelPath = AppDomain.CurrentDomain.BaseDirectory;
            excelPath += relativePath;
            if (File.Exists(excelPath))
            {
                StreamReader sr = new StreamReader(excelPath);
                stream = sr.BaseStream;
            }
            return stream;
        }

        public static void DownloadLargeFile(string filePath, string fileName)
        {
            HttpResponse Response = HttpContext.Current != null ? HttpContext.Current.Response : null;
            HttpRequest Request = HttpContext.Current != null ? HttpContext.Current.Request : null;
            if (Response == null || Request == null) return;
            System.IO.Stream iStream = null;

            // Buffer to read 10K bytes in chunk:
            byte[] buffer = new Byte[10000];

            // Length of the file:
            int length;

            // Total bytes to read:
            long dataToRead;

            // Identify the file to download including its path.
            //string filepath = "DownloadFileName";

            // Identify the file name.
            //string filename = System.IO.Path.GetFileName(filepath);

            try
            {
                // Open the file.
                iStream = new System.IO.FileStream(filePath, System.IO.FileMode.Open,
                            System.IO.FileAccess.Read, System.IO.FileShare.Read);


                // Total bytes to read:
                dataToRead = iStream.Length;

                string encodedFileName = fileName;//for Firefox, Chrome, Safari, Opera
                //if (Request.UserAgent.ToLower().Contains("msie")) encodedFileName = Uri.EscapeDataString(fileName);//for IE
                if (Request.Browser.Browser == "InternetExplorer" || Request.UserAgent.ToLower().Contains("msie")) encodedFileName = Uri.EscapeDataString(fileName);//for IE

                Response.ContentType = "application/octet-stream";
                Response.AddHeader("Content-Disposition", "attachment; filename=" + encodedFileName);

                // Read the bytes.
                while (dataToRead > 0)
                {
                    // Verify that the client is connected.
                    if (Response.IsClientConnected)
                    {
                        // Read the data in buffer.
                        length = iStream.Read(buffer, 0, 10000);

                        // Write the data to the current output stream.
                        Response.OutputStream.Write(buffer, 0, length);

                        // Flush the data to the HTML output.
                        //Response.Flush();

                        buffer = new Byte[10000];
                        dataToRead = dataToRead - length;
                    }
                    else
                    {
                        //prevent infinite loop if user disconnects
                        dataToRead = -1;
                    }
                }
            }
            catch (Exception ex)
            {
                WriteLog.Error("DownloadLargeFile Exception:", ex);
                // Trap the error, if any.
                Response.Write("Error : " + ex.Message);
            }
            finally
            {
                try
                {
                    if (iStream != null)
                    {
                        //Close the file.
                        iStream.Close();
                    }
                    Response.OutputStream.Flush();
                    Response.OutputStream.Close();
                    Response.Flush();
                    Response.Close();
                    //Response.End();
                }
                catch (Exception e)
                {
                    WriteLog.Error("Close Response Exception:", e);
                }
            }
        }

        public static void DownloadFile(string filepath, string fileName)
        {
            HttpResponse Response = HttpContext.Current!=null?HttpContext.Current.Response:null;
            HttpRequest Request = HttpContext.Current!=null?HttpContext.Current.Request:null;
            if (Response == null || Request == null) return;
            try
            {
                using (FileStream fs = File.OpenRead(filepath))
                {
                    int length = (int)fs.Length;
                    byte[] buffer;

                    using (BinaryReader br = new BinaryReader(fs))
                    {
                        buffer = br.ReadBytes(length);
                    }
                    Response.Clear();
                    Response.Buffer = true;
                    string encodedFileName = fileName;//for Firefox, Chrome, Safari, Opera
                    //if (Request.UserAgent.ToLower().Contains("msie")) encodedFileName = Uri.EscapeDataString(fileName);//for IE
                    if (Request.Browser.Browser == "InternetExplorer" || Request.UserAgent.ToLower().Contains("msie")) encodedFileName = Uri.EscapeDataString(fileName);//for IE
                    Response.AddHeader("Content-Disposition", "attachment;filename=" + encodedFileName);
                    Response.ContentType = "application/octet-stream";
                    Response.BinaryWrite(buffer);
                }
            }
            catch (Exception ex)
            {
                WriteLog.Error("DownloadFile Exception:", ex);
            }
            finally
            {
                try
                {
                    Response.OutputStream.Flush();
                    Response.OutputStream.Close();
                    Response.Flush();
                    Response.Close();
                    Response.End();
                }
                catch (Exception e)
                {
                    WriteLog.Error("Close Response Exception:", e);
                }
            }
        }

        public static void Download(MemoryStream Memory, string strFileName)
        {
            HttpResponse Response = HttpContext.Current.Response;
            Response.Clear();
            Response.AddHeader("Content-Disposition", "attachment;filename=" + strFileName);
            Response.ContentType = "application/octet-stream";
            Response.OutputStream.Write(Memory.GetBuffer(), 0, Memory.GetBuffer().Length);
            Response.OutputStream.Flush();
            Response.OutputStream.Close();
            Response.Flush();
            Response.Close();
        }

        public static void Download(byte[] bytes, string strFileName)
        {
            HttpResponse Response = HttpContext.Current.Response;
            Response.Clear();
            Response.AddHeader("Content-Disposition", "attachment;filename=" + strFileName);
            Response.ContentType = "application/octet-stream";
            Response.BinaryWrite(bytes);
            Response.Flush();
            Response.Close();
        }
        public static void DownloadExcel(byte[] bytes, string strFileName)
        {
            HttpResponse Response = HttpContext.Current != null ? HttpContext.Current.Response : null;
            HttpRequest Request = HttpContext.Current != null ? HttpContext.Current.Request : null;
            if (Response == null || Request == null) return;
            Response.ClearHeaders();
            Response.ClearContent();
            Response.Clear();
            string encodedFileName = strFileName;//for Firefox, Chrome, Safari, Opera
            //if (Request.UserAgent.ToLower().Contains("msie")) encodedFileName = Uri.EscapeDataString(strFileName);//for IE
            if (Request.Browser.Browser == "InternetExplorer" || Request.UserAgent.ToLower().Contains("msie")) encodedFileName = Uri.EscapeDataString(strFileName);//for IE
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            Response.AddHeader("content-disposition", "attachment;  filename=" + encodedFileName);
            Response.ContentEncoding = System.Text.Encoding.GetEncoding("UTF-8");
            Response.BinaryWrite(bytes);
            Response.Flush();
            Response.Close();
        }

        public static string ConvertFileSize(long bytes)
        {
            int thresh = 1024;
            if (Math.Abs(bytes) < thresh)
            {
                return bytes.ToString() + "B";
            }
            string[] units = new string[] { "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB" };
            int u = -1;
            do
            {
                bytes /= thresh;
                ++u;
            } while (Math.Abs(bytes) >= thresh && u < units.Length - 1);
            return bytes.ToString() + units[u];
        }

    }

    public class Object2FileUtil
    {
        /// <summary>
        /// Writes the given object instance to a binary file.
        /// <para>Object type (and all child types) must be decorated with the [Serializable] attribute.</para>
        /// <para>To prevent a variable from being serialized, decorate it with the [NonSerialized] attribute; cannot be applied to properties.</para>
        /// </summary>
        /// <typeparam name="T">The type of object being written to the XML file.</typeparam>
        /// <param name="filePath">The file path to write the object instance to.</param>
        /// <param name="objectToWrite">The object instance to write to the XML file.</param>
        /// <param name="append">If false the file will be overwritten if it already exists. If true the contents will be appended to the file.</param>
        public static void WriteToBinaryFile<T>(string filePath, T objectToWrite)
        {
            Stream stream = null;
            BinaryFormatter binaryFormatter = null;
            try
            {
                bool append = false;
                stream = File.Open(filePath, append ? FileMode.Append : FileMode.Create, FileAccess.Write, FileShare.Read);
                binaryFormatter = new BinaryFormatter();//System.Runtime.Serialization.Formatters.Binary.
                binaryFormatter.Serialize(stream, objectToWrite);
            }
            catch (Exception ex)
            {
                WriteLog.Error("Object2FileUtil.WriteToBinaryFile Error", ex);
                throw ex;
            }
            finally
            {
                if (stream != null)
                {
                    try { stream.Close(); stream.Dispose(); }
                    catch (Exception e) { WriteLog.Error("WriteToBinaryFile close stream exception", e); }
                }
            }
        }

        /// <summary>
        /// Reads an object instance from a binary file.
        /// </summary>
        /// <typeparam name="T">The type of object to read from the XML.</typeparam>
        /// <param name="filePath">The file path to read the object instance from.</param>
        /// <returns>Returns a new instance of the object read from the binary file.</returns>
        public static T ReadFromBinaryFile<T>(string filePath)
        {
            Stream stream = null;
            if (!File.Exists(filePath)) return default(T);
            try
            {
                using (stream = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    var binaryFormatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                    return (T)binaryFormatter.Deserialize(stream);
                }
            }
            catch (Exception ex)
            {
                WriteLog.Error("Object2FileUtil.ReadFromBinaryFile Error", ex);
                throw ex;
            }
            finally
            {
                if (stream != null)
                {
                    try { stream.Close(); stream.Dispose(); }
                    catch (Exception e) { WriteLog.Error("ReadFromBinaryFile close stream exception", e); }
                }
            }
        }
    }

}
