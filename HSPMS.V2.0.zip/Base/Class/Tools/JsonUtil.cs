﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace LEO.Project.Tools
{
    public class JsonUtil<T>
    {
        public static string JsonSerializerObject(T t) 
        {
            string JsonStr ="";
            if (t is DataTable)
            {
                JsonStr = JsonConvert.SerializeObject(t, new Newtonsoft.Json.Converters.DataTableConverter());
            }
            else if (t is DataSet)
            {
                JsonStr = JsonConvert.SerializeObject(t, new Newtonsoft.Json.Converters.DataSetConverter());
            }
            else
            {
                JsonStr = JsonConvert.SerializeObject(t);
            }
            return JsonStr;
        }


        public static T JsonDeserializeObject(string JsonStr)
        {
            if (JsonStr == null) return default(T);
            try
            {
                return JsonConvert.DeserializeObject<T>(JsonStr.Replace("&quot;", "\"").Replace("&apos;","\'"));
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("JsonDeserializeObject Error: JsonStr={0}", JsonStr), e);
                return default(T);
            }
        }

        public static T ConvertJson(string url)
        {
            string content = HttpUtil.HttpGet(url,null);
            T result = JsonConvert.DeserializeObject<T>(content);
            return result;
        }

        public static T ConvertJson(string url, string postData)
        {
            string content = HttpUtil.HttpPost(url, postData,null,null);

            T result = JsonConvert.DeserializeObject<T>(content);
            return result;
        }
    }

}
