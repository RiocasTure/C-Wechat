﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;
using WebChatInterface.Class.Tencent.WXMsg.Receive.Event;

namespace WebChatInterface.Class.Tencent.WXMsg.Receive
{
    //public enum WebChatMsgType {Text,Image,Voice,Video,Location};
    public class BaseReceive
    {
        public BaseReceive(string msgType) {
            this.MsgType = msgType;
        }
        public BaseReceive(XmlNode node)
        {
            this.ToUserName = node["ToUserName"].InnerText;
            this.FromUserName = node["FromUserName"].InnerText;
            this.CreateTime = node["CreateTime"].InnerText;
            this.MsgType = node["MsgType"].InnerText;
            this.MsgId = node["MsgId"]!=null?node["MsgId"].InnerText:"";
            this.AgentID = node["AgentID"]!=null?node["AgentID"].InnerText:"";
        }
        public static BaseReceive ParseWebChatMsg(string xml)
        {
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xml);
            XmlNode root = doc.FirstChild;
            string msgType = root["MsgType"].InnerText.ToLower();
            if (msgType == "text") return new ReceiveText(root);
            else if (msgType == "image") return new ReceiveImage(root);
            else if (msgType == "voice") return new ReceiveVoice(root);
            else if (msgType == "video") return new ReceiveVideo(root);
            else if (msgType == "location") return new ReceiveLocation(root);
            else if (msgType == "event")
            {
                string eventType = root["Event"].InnerText.ToLower();
                if (eventType == "view") return new ViewUrl(root);
                else if (eventType == "click") return new MenuClick(root);
                else if (eventType == "enter_agent") return new EnterAgent(root);
                //else if (eventType == "LOCATION") return new WebChatLocationEventMsg(root);
                else return new BaseEvent(root);
            }
            else return new ReceiveText(root);
        }

        public string ToUserName { get; set; }
        public string FromUserName { get; set; }
        public string CreateTime { get; set; }
        public string MsgType { get; set; }
        //public string Content { get; set; }
        public string MsgId { get; set; }//消息ID基本无用
        public string AgentID { get; set; }
    }
}
