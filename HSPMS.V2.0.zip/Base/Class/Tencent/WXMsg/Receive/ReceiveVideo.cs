﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;

namespace WebChatInterface.Class.Tencent.WXMsg.Receive
{
    public class ReceiveVideo:BaseReceive
    {
        public ReceiveVideo()
            : base("video")
        {
        }
        public ReceiveVideo(XmlNode node)
            : base(node)
        {
            this.MediaId = node["MediaId"].InnerText;
            this.ThumbMediaId = node["ThumbMediaId"].InnerText;
            //this.MsgType = "video";//node["MsgType"].InnerText;
        }
        /// <summary>
        /// 视频媒体文件id，可以调用获取媒体文件接口拉取数据
        /// </summary>
        public string MediaId { get; set; }
        /// <summary>
        /// 视频消息缩略图的媒体id，可以调用获取媒体文件接口拉取数据 
        /// </summary>
        public string ThumbMediaId { get; set; }
    }
}
