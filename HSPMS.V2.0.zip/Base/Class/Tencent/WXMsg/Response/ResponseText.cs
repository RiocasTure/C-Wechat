﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebChatInterface.Class.Tencent.WXMsg.Response
{
    public class ResponseText:BaseResponse
    {
        public ResponseText()
            : base("text")
        {
        }

        public override string ResponseXML()
        {
            //在CDATA内部的所有内容都会被解析器忽略
            return "<Content><![CDATA[" + Content + "]]></Content>";
        }

        /// <summary>
        /// 文本消息内容
        /// </summary>
        public string Content { get; set; }
    }
}
