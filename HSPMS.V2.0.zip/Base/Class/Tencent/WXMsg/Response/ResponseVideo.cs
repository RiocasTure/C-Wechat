﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebChatInterface.Class.Tencent.WXMsg.Response
{
    public class ResponseVideo:BaseResponse
    {
        public ResponseVideo()
            : base("video")
        {
        }

        public override string ResponseXML()
        {
            //在CDATA内部的所有内容都会被解析器忽略
            return "<Video><MediaId><![CDATA[" + MediaId + "]]></MediaId>"+
                "<Title><![CDATA[" + Title + "]]></Title>"+
                "<Description><![CDATA[" + Description + "]]></Description></Video>";
        }

        /// <summary>
        /// 视频文件id，可以调用上传媒体文件接口获取 
        /// </summary>
        public string MediaId { get; set; }
        /// <summary>
        /// 视频消息的标题 
        /// </summary>
        public string Title { get; set; }
        /// <summary>
        /// 视频消息的描述
        /// </summary>
        public string Description { get; set; }
    }
}
