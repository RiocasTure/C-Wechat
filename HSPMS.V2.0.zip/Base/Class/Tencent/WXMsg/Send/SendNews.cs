﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebChatInterface.Class.Tencent.WXMsg.Response;

namespace WebChatInterface.Class.Model.WXMsg.Send
{
    public class SendNews:BaseSend
    {
        public SendNews()
            : base("news")
        {
        }
        public override string BodyJSON
        {
            get
            {
                string jsons = "";
                for (int i = 0; i < articles.Count; i++)
                {
                    jsons += " {" + Environment.NewLine + "\"title\":\"" + articles[i].Title + "\"," + Environment.NewLine +
                        "\"description\":\"" + articles[i].Description + "\"," + Environment.NewLine +
                        "\"url\":\"" + articles[i].Url + "\"," + Environment.NewLine +
                        "\"picurl\":\"" + articles[i].PicUrl + "\"" + Environment.NewLine + "}";
                    if (i < articles.Count - 1) jsons += "," + Environment.NewLine;
                }
                return "\"articles\":[" + Environment.NewLine +jsons + Environment.NewLine + "]";
            }
        }
        public override string SafeJSON
        {
            get
            {
                return "";
            }
        }
        /// <summary>
        /// 图文条数，默认第一条为大图。图文数不能超过10，否则将会无响应 
        /// 图文消息的图片链接，支持JPG、PNG格式，较好的效果为大图640*320，小图80*80。如不填，在客户端不显示图片
        /// </summary>
        public List<NewsItem> Articles
        {
            get { return articles; }
        }
        public void AddNewsItem(string Title, string Description, string PicUrl, string Url)
        {
            NewsItem article = new NewsItem();
            article.Title = Title;
            article.Description = Description;
            article.PicUrl = PicUrl;
            article.Url = Url;
            articles.Add(article);
        }
        private List<NewsItem> articles = new List<NewsItem>();
    }
}
