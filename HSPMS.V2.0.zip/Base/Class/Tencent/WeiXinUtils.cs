﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json.Linq;
using System.Text;
using System.IO;
using LEO.Project.Tools;
using LEO.Project.WXProposal.Data.Entity;
using System.Threading;

namespace WebChatInterface.Class.Tencent
{
    public class WeiXinUtils
    {
        /// <summary>
        /// 用Code换取Openid
        /// </summary>
        /// <param name="Code"></param>
        /// <returns></returns>
        public static WXUserInfo GetWXUserInfoByCode(string Code)
        {
            string url = string.Format("https://api.weixin.qq.com/sns/oauth2/access_token?appid={0}&secret={1}&code={2}&grant_type=authorization_code", Account.AppID, Account.AppSecret, Code);
            string jsonText = HttpUtil.HttpGet(url, Encoding.UTF8);
            if (string.IsNullOrEmpty(jsonText)) return null;
            WeiXinUtils.LogJson(jsonText);
            JObject o = JObject.Parse(jsonText);
            JToken accessToken = o.SelectToken("$.access_token");
            JToken openid = o.SelectToken("$.openid");
            //JToken expireSecond = o.SelectToken("$.expires_in");
            //JToken refreshToken = o.SelectToken("$.refresh_token");
            //JToken scope = o.SelectToken("$.scope");
            //JToken unionid = o.SelectToken("$.unionid");
            if (accessToken == null || openid == null) return null;
            string userInfoUrl = string.Format("https://api.weixin.qq.com/sns/userinfo?access_token={0}&openid={1}&lang=zh_CN", accessToken.ToString(), openid.ToString());
            string userInfoJson = HttpUtil.HttpGet(userInfoUrl, Encoding.UTF8);
            if (string.IsNullOrEmpty(userInfoJson)) return null;
            WeiXinUtils.LogJson(userInfoJson);
            try
            {
                o = JObject.Parse(userInfoJson);
                if (o == null) return null;
                WXUserInfo wxu = new WXUserInfo();
                wxu.OpenID = o.SelectToken("$.openid").ToString();
                wxu.NickName = o.SelectToken("$.nickname").ToString();
                wxu.Sex = o.SelectToken("$.sex").ToString();
                wxu.City = o.SelectToken("$.city").ToString();
                wxu.Province = o.SelectToken("$.province").ToString();
                wxu.Country = o.SelectToken("$.country").ToString();
                return wxu;
            }
            catch (Exception ex)
            {
                WriteLog.Error("GetWXUserInfoByCode Exception",ex);
                return null;
            }
            //o.SelectToken("$.language");
            //o.SelectToken("$.headimgurl");
            //o.SelectToken("$.privilege");
            //return (openid != null)?openid.ToString():null;
        }

        public static string GetAccessToken()
        {
            JObject o = null;
            JToken timestamp = null;
            JToken expireSecond = null;
            JToken accessToken = null;
            string tokenFile = HttpContext.Current.Server.MapPath("~/accessToken.json");
            string tokenJson = ReadTextFromFile(tokenFile);
            if (tokenJson != null)
            {
                o = JObject.Parse(tokenJson);
                accessToken = o.SelectToken("$.access_token");
                timestamp = o.SelectToken("$.last_access_time");
                expireSecond = o.SelectToken("$.expires_in");
            }
            if (accessToken != null && timestamp != null && expireSecond != null)
            {
                long ts = long.Parse(timestamp.ToString());
                long expire = int.Parse(expireSecond.ToString()) * 1000;
                long now = DateTimeUtil.CurrentMillis;
                if (ts + expire > now + 2000) //滞后2秒
                {
                    //如果上次获取的未过期则直接返回
                    return accessToken.ToString();
                }
            }

            //到服务器获取
            string getUrl = Account.Url_GetToken.Replace("${Account.AppID}", Account.AppID).Replace("${Account.AppSecret}",Account.AppSecret);
            string getResponse = HttpUtil.HttpGet(getUrl, Encoding.UTF8);
            o = JObject.Parse(getResponse);
            if (o == null) return null;

            accessToken = o.SelectToken("$.access_token");
            timestamp = o.SelectToken("$.last_access_time");
            if (accessToken != null)
            {
                if (timestamp != null) timestamp.Remove();
                timestamp = JToken.Parse("" + DateTimeUtil.CurrentMillis + "");
                o.Add("last_access_time", timestamp);
            }
            WriteTextToFile(tokenFile, o.ToString());
            if (accessToken != null) return accessToken.ToString();
            return null;
        }

        public static string ReadTextFromFile(string path)
        {
            if (!File.Exists(path))
            {
                return null;
            }
            StringBuilder json = new StringBuilder();
            //异常检测开始
            try
            {
                StreamReader sr = new StreamReader(path, Encoding.UTF8);
                //使用StreamReader类来读取文件
                sr.BaseStream.Seek(0, SeekOrigin.Begin);
                String line;
                while ((line = sr.ReadLine()) != null)
                {
                    if (json.Length > 0) json.Append('\r').Append('\n');
                    json.Append(line);
                }
                //关闭此StreamReader对象
                sr.Close();
            }
            catch
            {
            }
            //异常检测结束
            return json.ToString();
        }

        private static FileLogQueue<FileLogInfo> fileLogQueue;
        private static FileLogQueue<FileLogInfo> LogQueue
        {
            get
            {
                if (fileLogQueue == null) fileLogQueue = new FileLogQueue<FileLogInfo>();
                return fileLogQueue;
            }
        }

        public static void WriteTextToFile(string filepath, string text)
        {
            LogQueue.PushMsg(FileLogInfo.Log(filepath, text, false));
        }

        public static void LogJson(string json)
        {
            LogQueue.PushMsg(FileLogInfo.Log(HttpContext.Current.Server.MapPath("~/Log/jsons/" + "info-" + DateTime.Now.ToString("yyyyMMdd") + ".log"), json));
        }

    }

    class FileLogQueue<T> : BaseQueue<T> where T : class
    {
        public override void Handle(T msg)
        {
            if (msg is FileLogInfo)
            {
                FileLogInfo log = (FileLogInfo)(Object)msg;
                Thread.Sleep(1);
                StreamWriter strWriter = null;
                try
                {
                    strWriter = new StreamWriter(log.LogFilePath, log.LogAppend, Encoding.UTF8);//overwrite, not append
                    if (log.LogAppend) strWriter.WriteLine("=======================[" + DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss") + "]=======================");
                    strWriter.WriteLine(log.LogMsg);
                    if (log.LogAppend) strWriter.WriteLine();
                }
                catch (Exception e)
                {
                    WriteLog.Error("FileLog", e);
                }
                finally
                {
                    if (strWriter != null)
                    {
                        try { strWriter.Flush(); strWriter.Close(); strWriter.Dispose(); }
                        catch (Exception ex) { WriteLog.Error("FileLog.CloseWriter", ex); }
                    }
                }
            }
        }
    }

    class FileLogInfo
    {
        public string LogMsg { get; set; }
        public string LogFilePath { get; set; }
        public bool LogAppend { get; set; }
        public static FileLogInfo Log(string logFilePath, string logMsg)
        {
            return Log(logFilePath, logMsg, true);
        }
        public static FileLogInfo Log(string logFilePath, string logMsg, bool logAppend)
        {
            FileLogInfo fli = new FileLogInfo();
            fli.LogMsg = logMsg;
            fli.LogFilePath = logFilePath;
            fli.LogAppend = logAppend;
            return fli;
        }
    }

}
