﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebChatInterface.Class.Tencent
{
    public class Account
    {
        /* 申请的测试帐号 */
        public static readonly string Token = "7RT4pYbO1vxbavFIEMDSePOTzX";//该Token系为企业号<发消息/验证数据>时所设置的，对订阅号、服务号无用
        public static readonly string AppID = "wx7c1177ec4d57a8ac";
        public static readonly string AppSecret = "d4624c36b6795d1d99dcf0547af5443d";
        /*
        */
        /* 申请的正式仿真帐号 */
        /*
        public static readonly string Token = "7RT4pYbO1vxbavFIEMDSePOTzX";
        public static readonly string AppID = "wx5fb6ebe0243cc6f2";
        public static readonly string AppSecret = "m3Nz9WPchQx4Yuil9tiqD69Lr05lucbaBH88wOdYDtE";
        */
        /* 申请的正式帐号-雅圖仕應用中心 */
        /*
        public static readonly string Token = "7RT4pYbO1vxbavFIEMDSePOTzX";
        public static readonly string AppID = "wx9700ac251a3ea551";
        public static readonly string AppSecret = "9594d3342c5195a4538bbf0f5974f1c2";
        */
        public static readonly string EncodingAESKey = "VHhiWPJKMMJc9mfzkeCreXg5M81H3Nb6N8sNghqBH7Y";

        //public static readonly string Url_SendMessage = "https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=${ACCESS_TOKEN}";
        public static readonly string Url_CreateMenu = "https://api.weixin.qq.com/cgi-bin/menu/create?access_token=${ACCESS_TOKEN}";
        public static readonly string Url_GetToken = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=${Account.AppID}&secret=${Account.AppSecret}";// + Account.AppID + "&secret=" + Account.AppSecret
    }
}
