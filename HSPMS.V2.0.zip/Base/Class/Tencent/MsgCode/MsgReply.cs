﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebChatInterface.Class.Tencent.WXMsg.Response;
using WebChatInterface.Class.Tencent.WXMsg.Receive;

namespace WebChatInterface.Class.Tencent.MsgCode
{
    public class MsgReply
    {
        public static BaseResponse ReplyText(BaseReceive src, string reply)
        {
            ResponseText replyMsg = new ResponseText();
            replyMsg.FromUserName = src.ToUserName;
            replyMsg.ToUserName = src.FromUserName;
            replyMsg.CreateTime = src.CreateTime;
            replyMsg.Content = reply;
            return replyMsg;
        }
        public static BaseResponse ReplyOneNews(BaseReceive src, string title, string desc, string picurl, string url)
        {
            ResponseNews replyMsg = new ResponseNews();
            replyMsg.FromUserName = src.ToUserName;
            replyMsg.ToUserName = src.FromUserName;
            replyMsg.CreateTime = src.CreateTime;
            replyMsg.AddNewsItem(title, desc, picurl, url);
            return replyMsg;
        }
    }
}
