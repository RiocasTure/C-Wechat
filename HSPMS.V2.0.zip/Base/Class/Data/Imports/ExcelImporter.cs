﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Data.Common;
using LEO.Project.WXProposal.Data.Entity;
using LEO.Project.Tools;

namespace LEO.Project.WXProposal.Data.Imports
{
    public class ExcelImporter
    {
        public static List<string> GetExcelSheetNameList(string xlsPath)
        {
            if (!File.Exists(xlsPath)) return null;
            try
            {
                var connStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + xlsPath + ";Extended Properties=\"Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text\""; ;
                DbProviderFactory objDbFactory = DbProviderFactories.GetFactory("System.Data.OleDb");
                DbDataAdapter objDbAdapter = null;
                objDbAdapter = objDbFactory.CreateDataAdapter();
                DbConnection objDbConnection = objDbFactory.CreateConnection();
                objDbConnection.ConnectionString = connStr;
                objDbConnection.Open();
                DataTable objSheetNames = objDbConnection.GetSchema("Tables");
                List<string> sheetNames = new List<string>();
                foreach (DataRow row in objSheetNames.Rows)
                {
                    string tbname = row["TABLE_NAME"].ToString();
                    int idx = tbname.IndexOf('$');
                    if (idx >= 0) tbname = tbname.Substring(0, idx);
                    if (!sheetNames.Contains(tbname)) sheetNames.Add(tbname);
                }
                return sheetNames;
            }
            catch (Exception ex)
            {
                //throw ex;
                WriteLog.Error(string.Format("GetExcelSheetNameList Error:xlsPath={0}", xlsPath), ex);
                return null;
            }
        }

        public static DataTable ImportSheetData(string xlsPath, string sheetName)
        {
            if (!File.Exists(xlsPath)) return null;
            /*
            string ext = Path.GetExtension(xlsPath);
            if (string.IsNullOrEmpty(ext) || !(ext.ToLower().Equals(".xls") || ext.ToLower().Equals(".xlsx"))) return null;
            string extendedProperties = "Excel 8.0";
            if (ext.ToLower().Equals(".xlsx")) extendedProperties = "Excel 9.0";
            */
            try
            {
                //string connStr = "Provider='Microsoft.Jet.OLEDB.4.0';Extended Properties='" + extendedProperties + ";HDR=Yes;IMEX=2';data source=" + xlsPath;
                //string connStr = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + xlsPath + ";Extended Properties='" + extendedProperties + ";HDR=Yes;IMEX=1';";
                var connStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + xlsPath + ";Extended Properties=\"Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text\""; ;
                string excelSheetName = sheetName == string.Empty ? "Sheet1" : sheetName;
                string sql = "SELECT * FROM [" + excelSheetName + "$]";
                DataSet ds = new DataSet();
                OleDbDataAdapter da = new OleDbDataAdapter(sql, connStr);

                da.Fill(ds);

                return ds.Tables[0];
            }
            catch (Exception ex)
            {
                //throw ex;
                WriteLog.Error(string.Format("ImportSheetData Error:xlsPath={0},sheetName={1}",xlsPath,sheetName), ex);
                return null;
            }
        }

    }
}
