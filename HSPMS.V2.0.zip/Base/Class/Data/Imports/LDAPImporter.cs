﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.DirectoryServices;
using LEO.Project.Tools;
using LEO.Project.WXProposal.Data.Entity;

namespace LEO.Project.WXProposal.Data.Imports
{
    public class LDAPImporter
    {
        public static List<ADUser> GetADUserList()
        {
            List<ADUser> adulst = new List<ADUser>();
            try
            {
                string queryString = "(&(objectClass=user)(objectClass=person)(objectCategory=CN=Person,CN=Schema,CN=Configuration,DC=leogroup,DC=ad))";
                string defaultPath = "LDAP://hsdc01.hsgroup.leogroup.ad/DC=hsgroup,DC=leogroup,DC=ad";//string defaultPath = string.Empty;
                /*
                using (DirectoryEntry ent = new DirectoryEntry("LDAP://RootDSE"))
                    defaultPath = (String)ent.Properties["defaultNamingContext"][0];
                using (DirectoryEntry root = new DirectoryEntry("LDAP://" + defaultPath))
                */

                using (DirectoryEntry root = new DirectoryEntry(defaultPath))
                using (DirectorySearcher dsSearcher = new DirectorySearcher(root, queryString))
                {
                    dsSearcher.SearchScope = SearchScope.Subtree;
                    dsSearcher.PageSize = 10000;
                    //ID
                    dsSearcher.PropertiesToLoad.Add("objectGUID");
                    //工号
                    dsSearcher.PropertiesToLoad.Add("postOfficeBox");
                    //Name
                    dsSearcher.PropertiesToLoad.Add("sAMAccountName");
                    //中文名-電話
                    dsSearcher.PropertiesToLoad.Add("telephoneNumber");
                    //部門
                    dsSearcher.PropertiesToLoad.Add("department");
                    //科组
                    dsSearcher.PropertiesToLoad.Add("physicalDeliveryOfficeName");
                    //Title
                    dsSearcher.PropertiesToLoad.Add("title");
                    //訪問控制
                    dsSearcher.PropertiesToLoad.Add("userAccountControl");
                    using (SearchResultCollection results = dsSearcher.FindAll())
                    {
                        foreach (SearchResult result in results)
                        {
                            if ((int)result.Properties["userAccountControl"][0] == 0)
                                continue;
                            ADUser adu = new ADUser();
                            adu.Guid = (result.Properties["objectGUID"]!=null && result.Properties["objectGUID"].Count>0)?((byte[])result.Properties["objectGUID"][0]):null;
                            adu.AccountName = (result.Properties["sAMAccountName"]!=null && result.Properties["sAMAccountName"].Count>0)?result.Properties["sAMAccountName"][0].ToString():null;
                            adu.JobNumber = (result.Properties["postOfficeBox"] != null && result.Properties["postOfficeBox"].Count > 0) ? result.Properties["postOfficeBox"][0].ToString() : null;
                            string telName = (result.Properties["telephoneNumber"] != null && result.Properties["telephoneNumber"].Count > 0) ? result.Properties["telephoneNumber"][0].ToString() : "";
                            string[] arr = telName.Split('-');
                            adu.CNName = arr != null && arr.Length > 0 ? arr[0].Trim() : "";
                            adu.Tel = arr != null && arr.Length > 1 ? arr[1].Trim() : "";
                            adu.Department = (result.Properties["department"] != null && result.Properties["department"].Count > 0) ? result.Properties["department"][0].ToString() : null;
                            adu.Branch = (result.Properties["physicalDeliveryOfficeName"] != null && result.Properties["physicalDeliveryOfficeName"].Count > 0) ? result.Properties["physicalDeliveryOfficeName"][0].ToString() : null;
                            adu.JobTitle = (result.Properties["title"] != null && result.Properties["title"].Count > 0) ? result.Properties["title"][0].ToString() : null;
                            if (!(string.IsNullOrEmpty(adu.CNName) || string.IsNullOrEmpty(adu.Department) || string.IsNullOrEmpty(adu.Branch))) adulst.Add(adu);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                WriteLog.Error("GetADUserList Error:", ex);
            }
            return adulst;
        }

    }
}
