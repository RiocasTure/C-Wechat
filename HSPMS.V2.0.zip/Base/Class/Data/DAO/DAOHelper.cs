﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using IBatisNet.DataMapper.Configuration.Statements;
using IBatisNet.DataMapper;
using IBatisNet.DataMapper.MappedStatements;
using IBatisNet.Common;
using IBatisNet.DataMapper.Scope;
using IBatisNet.DataMapper.Configuration;
using IBatisNet.DataMapper.SessionStore;

namespace LEO.Project.WXProposal.Data.DAO
{
    public class DAOHelper
    {
        private static DomSqlMapBuilder builder = new DomSqlMapBuilder();//其作用是根据配置文件创建SqlMap实例。
        private static volatile ISqlMapper mapper = mapper = builder.Configure("SqlMap.config") as SqlMapper;//SqlMapper是iBatisNet的核心组件，提供数据库操作的基础平台。SqlMapper可通过DomSqlMapBuilder创建。;

    }
}
