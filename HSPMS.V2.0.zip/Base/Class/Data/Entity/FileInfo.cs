﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace LEO.Project.WXProposal.Data.Entity
{
    [Serializable]
    public class AttachmentInfo
    {
        public string RelatedKey { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public int FileSize { get; set; }
        public DateTime? FileDate { get; set; }
    }
}
