﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LEO.Project.WXProposal.Data.Entity
{
    public class ADUser
    {
        public byte[] Guid { get; set; } //objectGUID
        public string JobNumber { get; set; } //postOfficeBox
        public string AccountName { get; set; }//sAMAccountName
        public string Tel { get; set; } //telephoneNumber
        public string CNName { get; set; }//telephoneNumber
        public string Department { get; set; }//department
        public string Branch { get; set; }//physicalDeliveryOfficeName
        public string JobTitle { get; set; }//title
        public byte Status { get; set; }
        public DateTime? LastUpdate { get; set; }
    }
}
