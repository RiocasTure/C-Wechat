﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LEO.Project.WXProposal.Data.Entity
{
    public class WXUserInfo
    {
        #region properties
        public string OpenID { get; set; }
        public string NickName { get; set; }
        public string Sex { get; set; }
        public string Country { get; set; }
        public string Province { get; set; }
        public string City { get; set; }
        public DateTime? LastUpdate { get; set; }

        /// <summary>
        /// 0=无效,1=有效
        /// </summary>
        public byte Status { get; set; }
        /// <summary>
        /// 該微信OpenID對應的員工工號
        /// </summary>
        public string JobNumber { get; set; }
        #endregion
    }
}
