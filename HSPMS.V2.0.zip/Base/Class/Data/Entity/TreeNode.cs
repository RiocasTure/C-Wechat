﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LEO.Project.WXProposal.Data.Entity
{
    public class TreeNode
    {
        public string NodeName { get; set; }
        public List<TreeNode> Childrens { get; set; }
    }
}
