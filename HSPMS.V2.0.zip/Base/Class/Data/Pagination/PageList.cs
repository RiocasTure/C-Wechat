﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LEO.Project.WXProposal.Model.Pagination
{
    public class PageList
    {
        public int PageSize { get; set; }
        public int PageIndex { get; set; }
        public int RowsCount { get; set; }
        public int PageCount { get; set; }
        public string RowRange { get; set; }
        public void Calulate()
        {
            if (PageSize <= 0)
            {
                PageCount = RowsCount > 0 ? 1 : 0;
                PageIndex = PageCount;
                RowRange = RowsCount > 0 ? string.Format("{0}~{1}", 1, RowsCount) : "0";
            }
            else
            {
                int r = RowsCount % PageSize;
                int start = (PageIndex - 1) * PageSize + 1;
                PageCount = (RowsCount - r) / PageSize + (r>0?1:0);
                PageIndex = (PageIndex <= 0 ? 1 : PageIndex > PageCount ? PageCount : PageIndex);
                RowRange = string.Format("{0}~{1}", start, start-1+(PageIndex==PageCount?r:PageSize));
            }
        }
        public List<object> PageData { get; set; }
    }
}
