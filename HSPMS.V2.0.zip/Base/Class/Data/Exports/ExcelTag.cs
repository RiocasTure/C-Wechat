﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text.RegularExpressions;
using LEO.Project.Tools;

namespace LEO.Project.WXProposal.Data.Exports
{
    public class ExcelTag
    {
        public static readonly Regex TemplateTagReg_Var = new Regex(@"\$\{[a-zA-Z_][a-zA-Z0-9_]*(\[\d+\])?([.][a-zA-Z_][a-zA-Z0-9_]*(\[\d+\])?)*\}");
        public static readonly string TemplateTagExtract_Var = @"\$\{(.*?)\}";

        public string var { get; set; }
        public object varObj { get; set; }
        public string tagStr { get; set; }

        public virtual bool IsTag()
        {
            if (string.IsNullOrEmpty(tagStr)) return false;
            return TemplateTagReg_Var.IsMatch(tagStr);
        }

        public virtual void Extract()
        {
            if (!IsTag()) return;
            string[] vars = RegexHelper.ExtractByReg(tagStr, TemplateTagExtract_Var);
            if (vars.Length == 1)
            {
                this.var = vars[0];
            }
        }

        public ExcelTag(string tagstr)
        {
            this.tagStr = tagstr;
            Extract();
        }

    }
}
