﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using OfficeOpenXml;
using LEO.Project.Tools;
using System.Text.RegularExpressions;
using System.Collections;

namespace LEO.Project.WXProposal.Data.Exports
{
    public class ExcelExporter
    {
        private static readonly string ExcelTemplatePath = @"\SysAdmin\data\template\excel\";
        private static readonly string DefaultExportFileName = "Export.xlsx";

        private static string GetTrimCellText(ExcelWorksheet sheet, int row, int col)
        {
            if (sheet == null) return null;
            string cellTxt = sheet.Cells[row, col].Text;
            if (!string.IsNullOrEmpty(cellTxt)) return cellTxt.Trim();
            return string.Empty;
        }

        public static void ExportByTemplate(string templateFileName,Dictionary<string,object> dict,string exportName)
        {
            try
            {

                string excelPath = ExcelTemplatePath + templateFileName;

                ExcelPackage wPackage = null;
                ExcelPackage rPackage = null;
                Stream stream = null;


                try
                {

                    stream = FileUtil.GetExcelTemplate(excelPath);

                    if (stream != null)
                    {
                        wPackage = new ExcelPackage(new MemoryStream(), stream);
                        rPackage = new ExcelPackage(new MemoryStream(), stream);
                        for (int i = 1; i <= rPackage.Workbook.Worksheets.Count; i++)
                        {
                            ExcelWorksheet rSheet = rPackage.Workbook.Worksheets[i];
                            ExcelWorksheet wSheet = wPackage.Workbook.Worksheets[i];
                            var rowCnt = rSheet.Dimension!=null?rSheet.Dimension.End.Row:0;
                            var colCnt = rSheet.Dimension!=null?rSheet.Dimension.End.Column:0;
                            int wR = 0;
                            for (int r = 1; r <= rowCnt; r++)
                            {
                                wR++;
                                int wC = 0;
                                for (int c = 1; c <= colCnt; c++)
                                {
                                    wC++;
                                    string cellTxt = GetTrimCellText(rSheet, r, c);
                                    if (!string.IsNullOrEmpty(cellTxt))
                                    {
                                        if (ExcelLoopTag.TemplateTagReg_Loop.IsMatch(cellTxt))
                                        {
                                            ExcelLoopTag loop = new ExcelLoopTag(cellTxt);
                                            if (c == 1)
                                            {
                                                loop.startRow = r + 1;
                                                //found end loop tag
                                                for (int x = loop.startRow; x <= rowCnt; x++)
                                                {
                                                    string _cellTxt = GetTrimCellText(rSheet, x, 1);
                                                    if (ExcelLoopTag.TemplateTag_LoopEnd == _cellTxt)
                                                    {
                                                        loop.endRow = x - 1;
                                                        break;
                                                    }
                                                }
                                                if (!string.IsNullOrEmpty(loop.items) && !string.IsNullOrEmpty(loop.var) && !string.IsNullOrEmpty(loop.varStat) && loop.startRow > 0 && loop.endRow > 0)
                                                {
                                                    wSheet.DeleteRow(wR, loop.endRow - loop.startRow + 3, true);
                                                    if (loop.startRow <= loop.endRow)
                                                    {
                                                        object arrlst = ReflectionHelper.GetObjectValueByExpression(dict, loop.items);
                                                        int count = 0;
                                                        if (arrlst != null && (arrlst.GetType().IsArray || (arrlst.GetType().IsGenericType && arrlst is IEnumerable)))
                                                        {
                                                            loop.itemsObj = arrlst;
                                                            loop.varStatObj = new LoopStat();
                                                            loop.varStatObj.Index = 0;
                                                            dict[loop.varStat]=loop.varStatObj;
                                                            count = arrlst.GetType().IsArray ? ((object[])arrlst).Length : ((arrlst.GetType().IsGenericType && arrlst is IEnumerable)?((List<object>)arrlst).Count:0);
                                                        }
                                                        for (int z = 0; z < count; z++)
                                                        {
                                                            loop.varStatObj.Index++;
                                                            loop.varObj = arrlst.GetType().IsArray ? ((object[])arrlst)[z] : ((arrlst.GetType().IsGenericType && arrlst is IEnumerable)?((List<object>)arrlst)[z]:null);
                                                            dict[loop.var] = loop.varObj;
                                                            for (int x = loop.startRow; x <= loop.endRow; x++)
                                                            {
                                                                wSheet.InsertRow(wR, 1);
                                                                for (int y = 1; y <= colCnt; y++)
                                                                {
                                                                    rSheet.Cells[x, y].Copy(wSheet.Cells[wR, y]);
                                                                    string _cellTxt = GetTrimCellText(rSheet, x, y);
                                                                    if (ExcelTag.TemplateTagReg_Var.IsMatch(_cellTxt))
                                                                    {
                                                                        ExcelTag tag = new ExcelTag(_cellTxt);
                                                                        wSheet.Cells[wR, y].Value = StringUtils.ToString(ReflectionHelper.GetObjectValueByExpression(dict, tag.var));
                                                                    }
                                                                }
                                                                wR++;
                                                            }
                                                        }
                                                    }
                                                    r = loop.endRow + 1;
                                                    c = colCnt;
                                                }
                                                else
                                                {
                                                    wSheet.Cells[wR, wC].Value = "Loop tag invalid!";
                                                }
                                            }
                                            else
                                            {
                                                wSheet.Cells[wR, wC].Value = "Loop tag must be placed in first column!";
                                            }
                                        }
                                        else if (ExcelTag.TemplateTagReg_Var.IsMatch(cellTxt))
                                        {
                                            ExcelTag tag = new ExcelTag(cellTxt);
                                            wSheet.Cells[wR, wC].Value = StringUtils.ToString(ReflectionHelper.GetObjectValueByExpression(dict, tag.var));
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (wPackage != null)
                    {
                        byte[] bytePackage = wPackage.GetAsByteArray();
                        FileUtil.DownloadExcel(bytePackage, string.IsNullOrEmpty(exportName) ? DefaultExportFileName : exportName);
                    }
                }
                catch (Exception e)
                {
                    WriteLog.Error("ExportTest Error:", e);
                }
                finally
                {
                    if (stream != null) stream.Close();
                    if (wPackage != null) wPackage.Dispose();
                    if (rPackage != null) rPackage.Dispose();
                }
            }
            catch (Exception ex)
            {
                WriteLog.Error("ExportTest Error:", ex);
            }
        }
    }
}
