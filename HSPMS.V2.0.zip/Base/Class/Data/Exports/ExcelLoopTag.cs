﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text.RegularExpressions;
using LEO.Project.Tools;

namespace LEO.Project.WXProposal.Data.Exports
{
    public class ExcelLoopTag:ExcelTag
    {
        public static readonly Regex TemplateTagReg_Loop = new Regex(@"<loop\s+items=[""']?\$\{[a-zA-Z_][a-zA-Z0-9_]*(\[\d+\])?([.][a-zA-Z_][a-zA-Z0-9_]*(\[\d+\])?)*\}[""']?\s+var=[""']?[a-zA-Z_][a-zA-Z0-9_]*[""']?\s+varStat=[""']?[a-zA-Z_][a-zA-Z0-9_]*[""']?>$");
        public static readonly string TemplateTagExtract_LoopItems = @"items=[""']?\$\{(.*?)\}[""']";
        public static readonly string TemplateTagExtract_LoopVar = @"var=[""']?(.*?)[""']";
        public static readonly string TemplateTagExtract_VarStat = @"varStat=[""']?(.*?)[""']";
        public static readonly string TemplateTag_LoopEnd = "</loop>";

        public string items { get; set; }
        public object itemsObj { get; set; }
        public string varStat { get; set; }
        public LoopStat varStatObj { get; set; }
        public int startRow { get; set; }
        public int endRow { get; set; }

        public override bool IsTag()
        {
            if (string.IsNullOrEmpty(tagStr)) return false;
            return TemplateTagReg_Loop.IsMatch(tagStr);
        }

        public override void Extract()
        {
            if (!IsTag()) return;
            string[] _items = RegexHelper.ExtractByReg(tagStr, TemplateTagExtract_LoopItems);
            if (_items.Length == 1) items = _items[0];
            string[] _var = RegexHelper.ExtractByReg(tagStr, TemplateTagExtract_LoopVar);
            if (_var.Length == 1) var = _var[0];
            string[] _varStat = RegexHelper.ExtractByReg(tagStr, TemplateTagExtract_VarStat);
            if (_varStat.Length == 1) varStat = _varStat[0];
        }

        public ExcelLoopTag(string tagstr)
            : base(tagstr)
        {
        }

    }

    public class LoopStat
    {
        public int Index { get; set; }
    }
}
