function initPage(pageId){
	var pageInitFun = "pageDataInit_"+pageId;
	if (typeof window[pageInitFun] == "function"){
		$("#"+pageId).unbind("pageinit");
		$("#"+pageId).bind("pageinit", window[pageInitFun]);
	}
	var pageShowFun = "pageEventInit_"+pageId;
	if (typeof window[pageShowFun] == "function"){
		$("#"+pageId).unbind("pageshow");
		$("#"+pageId).bind("pageshow", window[pageShowFun]);
	}
}

var popFrameId = "MyPopIframe";
var maskSuffix = "_mask";
var closeSuffix = "_close";
function closePopFrame(){
	var popFrameMask = $("#"+popFrameId+maskSuffix);
	if (popFrameMask.length>0){
		popFrameMask.fadeOut("fast",function(){
			$("#"+popFrameId+closeSuffix).off("click");
			$("#"+popFrameId+maskSuffix).remove();
		});
	}
}
function isPopFrameOpen(){
	return ($("#"+popFrameId).length==1);
}
function popFrame(url){
	var pageObj = $("#"+$.mobile.activePage.attr("id"));
	if (pageObj.length!=1) pageObj = $(document.body);
	$("#"+popFrameId+maskSuffix).remove();
	pageObj.append('<div id="'+popFrameId+maskSuffix+'"><div id="'+popFrameId+closeSuffix+'"></div><iframe frameborder=0 marginheight=0 marginwidth=0 src="'+url+'" id="'+popFrameId+'"></iframe></div>');
	$("#"+popFrameId+maskSuffix).fadeIn("fast",function(){
		$("#"+popFrameId+closeSuffix).off("click");
		$("#"+popFrameId+closeSuffix).on("click",closePopFrame);
	});
	$("#"+popFrameId).off("load");
	$("#"+popFrameId).on("load", function(){
		$("#"+popFrameId).fadeIn("fast",function(){
			$(document.getElementById(popFrameId).contentDocument.body).removeProp("marginwidth").removeProp("marginheight");
			//$("#"+popFrameId).css("opacity","1");
			$("#"+popFrameId).animate({"opacity":"1"}, "fast");
		});
		//$('#'+popFrameId).contents().find('body');
		//$(window[popFrameId].document.getElementsByTagName("body")[0]).
	});
}


function ajaxData_proposalSum(){
	$("#p_count_ul").removeClass("leo-data-loaderr").removeClass("leo-data-loading").addClass("leo-data-loading");
	$("#p_count_ul").children("li.loading-li").off("click");
	$("#p_count_ul").children("li.loading-li").html("正在加载...");
	$.ajax({
		type: DataMethod,
		url: noCacheUrl(DataFeederBase+QuerySummary),
		dataType: "json",
		contentType: "application/json; charset=utf-8",
		success: function(data){
			if (data && data.d && data.d.IsOK){
				if (data.d.ResultObject){
					pageDataRender_proposalSum(data.d.ResultObject);
				}else{
					//alert("抱歉！因系统数据异常，本次請求失败！");
					pageDataRender_proposalSum(false);
				}
				processQueueToken = 0;
			}else{
				/*
				if (data && data.d && data.d.SysMsg) alert(data.d.SysMsg);
				else alert("抱歉！"+DataProcessError+"，请稍候再试！");
				*/
				pageDataRender_proposalSum(false);
			}
		},
		error: function (jqXHR, textStatus, errorThrown) {
			//alert("抱歉！因"+DataTransError+"的原因，系统未能处理您的數據请求！");
			pageDataRender_proposalSum(false);
		},
		timeout: 8000
	});
}

function pageDataRender_proposalSum(sumData){
	if (sumData){
		initObjectProp2Input(sumData,"");
		$("#p_count_ul").removeClass("leo-data-loaderr").removeClass("leo-data-loading");
	}else{
		$("#p_count_ul").removeClass("leo-data-loading").addClass("leo-data-loaderr");
		$("#p_count_ul").children("li.loading-li").html("匯總數據加載失敗！請點擊重試。");
		$("#p_count_ul").children("li.loading-li").on("click",ajaxData_proposalSum);
	}
}

function pageDataInit_userIndex(){
	ajaxData_proposalSum();
}
function pageEventInit_userIndex(){
	$("#leo-pms-home-list a").each(function(){
		if ($(this).attr("data-ref")=="frame"){
			$(this).off("click");
			$(this).on("click",function(){
				var link = $(this);
				var href = link.prop("href");
				if (!isEmpty(href)&&href.length>0) popFrame(link.prop("href"));
				setTimeout(function(){link.trigger("blur");},600);
				return false;
			});
		}
	});
	setupKeyboardHandler(27,function(){
		if (isPopFrameOpen()) closePopFrame();
	});
}
