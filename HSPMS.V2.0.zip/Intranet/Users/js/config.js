/** Constants **/
var DataMethod = "POST",
	DataFeederBase = "./WS/Proposal.asmx/",
	QuerySummary = "QuerySummary";

var DataTransError = "网络传输异常";
var DataProcessError = "系统未能及时响应";
