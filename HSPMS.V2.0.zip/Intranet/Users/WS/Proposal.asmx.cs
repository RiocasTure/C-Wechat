﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Globalization;
using LEO.Project.WXProposal.Model.Session;
using LEO.Project.WXProposal.Control;
using LEO.Project.WXProposal.Data.Entity;
using LEO.Project.WXProposal.Data.DAO;
using LEO.Project.Tools;
using JsonView;
using LEO.Project.WXProposal.Model.Pagination;
using System.IO;
using System.Xml.Serialization;
using LEO.Project.WXProposal.Control.Validator;
using LEO.Project.WXProposal.Validator;
using LEO.Project.WXProposal.Web;
using Intranet.ICPService;

namespace WebChatInterface.WS
{
    /// <summary>
    /// Summary description for Proposal
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    [XmlInclude(typeof(AttachmentInfo))]
    [XmlInclude(typeof(WSResult))]
    public class ProposalWS : System.Web.Services.WebService
    {

        [WebMethod]
        public WSResult SubmitProposal(string dataArr, string fileArr, string uJobNum, string uName)
        {
            return WebHandler.SubmitProposal(dataArr, fileArr, uJobNum, uName);
        }

        [WebMethod]
        public WSResult QueryProposals(string keyword, string dateBegin, string dateEnd, string status, int pageIndex)
        {
            return WebHandler.QueryProposals(keyword, dateBegin, dateEnd, status, pageIndex);
        }

        [WebMethod]
        public WSResult GetSEIInfo(string so)
        {
            WSResult ws = WebHandler.CheckSession();
            if (ws.IsOK && ws.ResultObject != null && ws.ResultObject is UserSession)
            {
                ICPService rws = new ICPService();
                string seiInfo = rws.GetSEIInfo(so);
                ws.ResultObject = seiInfo;
            }
            return ws;
        }

        [WebMethod]
        public WSResult QuerySummary()
        {
            return WebHandler.QuerySummary();
        }

    }
}
