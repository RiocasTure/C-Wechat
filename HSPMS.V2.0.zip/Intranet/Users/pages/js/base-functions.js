function escapeRegExp(str) {
  return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}
if (!String.prototype.trim) {
	String.prototype.trim = function () {
		return this.replace(/^\s+|\s+$/g, '');
	};
}
if (!String.prototype.endWith) {
	String.prototype.endWith=function(s){
		var i=this.indexOf(s);
		return (i>=0)&&(this.length-s.length)==i;
	}
}
if (!String.prototype.startWith) {
	String.prototype.startWith=function(s){
		return this.indexOf(s)==0;
	}
}
if (!String.prototype.replaceAll){
	String.prototype.replaceAll=function(find,replace){
		return this.replace(new RegExp(escapeRegExp(find), 'g'), replace);
	}
}
function getSubStr(str,maxlen){
	if (str&&str.length&&str.length>maxlen)
		return str.substr(0,maxlen);
	return str;
}
function ellipsStr(str,maxlen){
	var ellips = "..";
	if (str.length>=(maxlen+ellips.length)){
		return str.substr(0,maxlen)+ellips;
	}
	return str;
}
function connectStrWithMinus(str1,str2){
	var prx = (str1!=''&&str1!=null);
	var sfx = (str2!=''&&str2!=null);
	if (prx && sfx){
		if (str1.indexOf(str2)>=0) return str1;
		if (str2.indexOf(str1)>=0) return str2;
	}
	return (prx?str1:'')+(sfx?((prx?' - ':'')+str2):'');
}
function hasQuoteChar(str){
	return (str && str!=null && str.length>0 && (str.indexOf("\'")>=0||str.indexOf("\"")>=0));
}
function escapeQuotation(str){
	var q = hasQuoteChar(str);
	if (q) return str.replaceAll("\"","\\&quot;").replaceAll("\'","\\&apos;");
	return str;
}

function getUrlParameterByName(url, paramName){ 
	var strGET = url.substr(url.indexOf('?')+1,url.length - url.indexOf('?')); 
	var arrGET = strGET.split("&"); 
	var paramValue = '';
	for(i=0;i<arrGET.length;i++){ 
		var aux = arrGET[i].split("="); 
		if (aux[0] == paramName){
			paramValue = aux[1];
			break;
		}
	} 
	return paramValue;
}

function getLocationParams(paramName){
	var strGET = location.search; 
	if (strGET.indexOf("?")==0) strGET = strGET.substr(1,strGET.length);
	var arrGET = strGET.split("&"); 
	var paramValue = '';
	for(i=0;i<arrGET.length;i++){ 
		var aux = arrGET[i].split("="); 
		if (aux[0] == paramName){
			paramValue = aux[1];
			break;
		}
	} 
	return paramValue;
}
function convertFileSize(bytes) {
    var thresh = 1024;
    if(Math.abs(bytes) < thresh) {
        return bytes + ' B';
    }
    var units = ['KB','MB','GB','TB','PB','EB','ZB','YB'];
    var u = -1;
    do {
        bytes /= thresh;
        ++u;
    } while(Math.abs(bytes) >= thresh && u < units.length - 1);
    return bytes.toFixed(1)+' '+units[u];
}

/***********************************
 Date Functions
 ***********************************/
var DateTimeTReg = /^((?:19|20)\d\d)-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])T(0\d{1}|1\d{1}|2[0-3]):[0-5]\d{1}:([0-5]\d{1})/;
var DateTimeReg = /^((?:19|20)\d\d)-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])\s(0\d{1}|1\d{1}|2[0-3]):[0-5]\d{1}:([0-5]\d{1})/;

function parseDateTime(yyyyMMddHHmm){
	if (DateTimeTReg.test(yyyyMMddHHmm)||DateTimeReg.test(yyyyMMddHHmm)){
		var dt = yyyyMMddHHmm.substr(0,19).replace('T',' ');
		var a=dt.split(" ");
		var d=a[0].split("-");
		var t=a[1].split(":");
		return new Date(d[0],(d[1]-1),d[2],t[0],t[1],t[2]);
	}
	return false;
}

if (!Date.prototype.format) {
	Date.prototype.format = function(fmt)
	{  
		var o = {
			"M+" : this.getMonth()+1,                 //月份
			"d+" : this.getDate(),                    //日
			"h+" : this.getHours(),                   //小时
			"m+" : this.getMinutes(),                 //分
			"s+" : this.getSeconds(),                 //秒
			"q+" : Math.floor((this.getMonth()+3)/3), //季度
			"S"  : this.getMilliseconds()             //毫秒
		};
		if(/(y+)/.test(fmt)) fmt=fmt.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length));
		for(var k in o)
			if(new RegExp("("+ k +")").test(fmt))
				fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));
		return fmt;
	}
}
var InputTypes = new Array();
if (InputTypes){
	var iptTest = document.createElement("input");
	iptTest.setAttribute("type", "date");
	InputTypes["date"] = (iptTest.type !== "text");
}
function initDateInput(inputObj){
	inputObj.unbind("focus");
	inputObj.bind("focus",function(){
		if (!InputTypes.date){
			$(this).blur();
			return;
		}
		$(this).prop("type","date");
		$(this).click();
	});
	inputObj.unbind("blur");
	inputObj.bind("blur",function(){
		if (!InputTypes.date) return;
		var date = $(this).get(0).valueAsDate;
		if (!date){
			$(this).prop("type","text");
			$(this).val("");
		}
	});
	if (InputTypes.date) inputObj.prop("type","date");
	else inputObj.mobiscroll(mobiOption);
}
function getDateInputValue(inputObj){
	var dateStr = "";
	if (!InputTypes.date){
		dateStr = inputObj.val();
	}else{
		dateStr = inputObj.get(0).valueAsDate;
		dateStr = (!dateStr||dateStr==null)?"":dateStr.format("yyyy-MM-dd");
	}
	return dateStr;
}

function nowUTC(){
	var date = new Date();
	return Date.UTC(date.getFullYear(),date.getMonth() + 1,date.getDate(),date.getHours(),date.getMinutes(),date.getSeconds(),date.getMilliseconds()); 
}

/***********************************
 System Functions
 ***********************************/
function bindWindowEvent(evts,fun){
	if (window.addEventListener){
		window.addEventListener(evts,fun,false);
	}else if (window.attachEvent){
		window.attachEvent("on"+evts,fun);
	}
}

function bindWindowLoad(func) {
	if (document.addEventListener) {
		window.addEventListener("load", func, false);
	}
	else if (window.attachEvent) {
		window.attachEvent("onload", func);
	}
	else {
		var f_onLoad = window.onload;
		if (typeof window.onload != "function") {
			window.onload = func;
		}
		else {
			window.onload = function() {
				f_onLoad();
				func();
			}
		}
	}
}

function noCacheUrl(url){
	var rad = Math.floor(Math.random() * ( 1000 + 1));
	/*
	if (url.indexOf("?")>=0) return url+"&utc="+nowUTC();
	return url+"?utc="+nowUTC();
	*/
	if (url.indexOf("?")>=0) return url+"&random="+rad;
	return url+"?random="+rad;
}

/***********************************
 Url Functions
 ***********************************/
function convertObj2UrlParams(obj){
	var params="";
	for (var param in obj){
		if (params=="") params+="?";
		else params+="&";
		params+=param+"="+obj[param];
	}
	return params;
}

function convertObj2AjaxData(obj){
	var data="{";
	for (var param in obj){
		if (data!="{") data+=",";
		data+="'"+param+"':'"+obj[param]+"'";
	}
	data+="}";
	return data;
}
/***********************************
 Keyboard Functions
 ***********************************/
var lastKeyDown = -1;
function setupKeyboardHandler(keycode,func) {
	$(document).keydown(function(e){
		lastKeyDown = e.keyCode;
	});
	$(document).keyup(function(e){
		var key = e.keyCode;
		if (key == keycode && lastKeyDown == keycode){
			e.preventDefault();
			lastKeyDown = -1;
			func();
		}
	});
}

//**********************  End with key press/up/down function  **********************

/***********************************
 jQuery Mobile Button Click Hold
 ***********************************/
function clickHold(btn,disabled){
	$.mobile.loading('show');
	if (btn.is("button")){
		btn.button("disable")
	}else if (btn.is("a")){
		btn.removeClass("ui-disabled").addClass("ui-disabled");
	}
	if (disabled){
		setTimeout(function(){
			$.mobile.loading('hide');
		},300);
	}else{
		setTimeout(function(){
			$.mobile.loading('hide');
			if (btn.is("button")){
				btn.button("enable");
			}else if (btn.is("a")){
				btn.removeClass("ui-disabled");
			}
		},300);
	}
}
/***********************************
 Object Functions
 ***********************************/
/*
 * 检测对象是否是空对象(不包含任何可读属性)。
 * 方法既检测对象本身的属性，也检测从原型继承的属性(因此没有使hasOwnProperty)。
 */
function isEmpty(obj){
    for (var name in obj){
        return false;
    }
	if (!isNaN(parseInt(obj))) return false;
    return true;
}

function escapeObj(obj){
    for (var prop in obj){
        if (typeof obj[prop] == 'object') escapeObj(obj[prop]);
		else if (typeof obj[prop] == 'string'){
			if (obj[prop].indexOf('\\')>=0) obj[prop] = obj[prop].replaceAll('\\','\\\\');
			if (hasQuoteChar(obj[prop])) obj[prop] = obj[prop].replaceAll("\"","\\\"").replaceAll("\'","&apos;");
		}
    }
	return obj;
}

function toJSONStr(obj){
	return $.toJSON(escapeObj(obj));
}

/***********************************
 Cookie Functions
 ***********************************/
/**
 * 設置cookie名称、值以及过期天数
 *  - 我们首先将天数转换为有效的日期，然后，我们将 cookie 名称、值及其过期日期存入 document.cookie 对象。
 */
function setCookie(c_name,value,expiredays){
	var exdate=new Date();
	exdate.setDate(exdate.getDate()+expiredays);
	document.cookie=c_name+ "=" +escape(value)+((expiredays==null) ? "" : ";expires="+exdate.toGMTString());
}
function setPageCookie(c_name,value){
	document.cookie=c_name+ "=" +escape(value)+";";
}

/**
 * 检查是否已设置 cookie
 * - 检查 document.cookie 对象中是否存有 cookie。
 * - 假如 document.cookie 对象存有某些 cookie，那么会继续检查我们指定的 cookie 是否已储存。
 * - 如果找到了所要的 cookie，就返回值，否则返回空字符串。
 */
function getCookie(c_name){
	if (document.cookie.length>0){
		c_start=document.cookie.indexOf(c_name + "=");
		if (c_start!=-1){
			c_start=c_start + c_name.length+1;
			c_end=document.cookie.indexOf(";",c_start);
			if (c_end==-1) c_end=document.cookie.length;
			return unescape(document.cookie.substring(c_start,c_end))
		}
	}
	return "";
}

/***********************************
 Info Dialog
 ***********************************/
function showLoadingMsg(msg){
	var showMsg = (msg?msg:"正在加載")+" ...";
	$("#loading_mask").remove();
	$(document.body).append('<div id="loading_mask"><p><span>'+showMsg+'</span></p></div>');
	$("#loading_mask").fadeIn("fast",function(){});
}

function showAlertMsg(msg){
	$("#loading_mask").remove();
	$(document.body).append('<div id="loading_mask" class="alert"><p><span>'+msg+'</span></p></div>');
	$("#loading_mask").fadeIn("fast",function(){});
}

function hideMsg(){
	$("#loading_mask").fadeOut("fast",function(){$("#loading_mask").remove();});
}

var popupToastTimeout;
function popToast(msg,time){
	$("#popupToast").popup("close");
	$("#popupToast").remove();
	if (msg=="") return;
	$(document.body).append('<div data-role="popup" id="popupToast" class="ui-content" data-theme="a"><p class="msg">'+msg+'<p></div>');
	$("#popupToast").popup();
	$("#popupToast").popup("open");
	//$('#popupToast' ).popup( 'reposition', 'positionTo: window' );
	if (popupToastTimeout) clearTimeout(popupToastTimeout);
	var showtime = time?time:3000;
	popupToastTimeout = setTimeout(function(){
		$("#popupToast").popup("close");
		$("#popupToast").remove();
	},showtime);
}
showLoadingMsg();
bindWindowLoad(userChecking);

/***********************************
 Check User Login
 ***********************************/
function userChecking(){
	var sessionId=getCookie("AuthSessionID");
	if (sessionId!=""){
		hideMsg();
	}else{
		hideMsg();
	}
}


$(document).bind("mobileinit", function(){
	$.mobile.defaultTransition = "none";
	/*
	$.fn.animationComplete = function(callback) {
		if ($.support.cssTransitions) {
			var superfy= "WebKitTransitionEvent" in window ? "webkitAnimationEnd" : "animationend";
			return $(this).one(superfy, callback);
		} else {
			setTimeout(callback, 0);
			return $(this);
		}
	};
	*/
});
