﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Text;
using System.Web.Security;
using LEO.Project.Tools;
using WebChatInterface.Class.Tencent.WXMsg.Receive;
using WebChatInterface.Class.Tencent.WXMsg.Response;
using WebChatInterface.Class.Tencent.WXMsg.Receive.Event;
using WebChatInterface.Class.Tencent.MsgCode;
using WebChatInterface.Class.Tencent;
using WebChatInterface.WS;
using LEO.Project.WXProposal.Control;
using LEO.Project.WXProposal.Data.Entity;
using LEO.Project.WXProposal.Data.DAO;
using LEO.Project.WXProposal.Model.Session;
using LEO.Project.WXProposal.Control.Validator;
using LEO.Project.WXProposal.Validator;
using LEO.Project.WXProposal.Web;

namespace WebChatInterface
{
    public class Handler : IHttpHandler
    {
        public void ProcessRequest(HttpContext context)
        {
            string action = context.Request.Params["action"];
            if (!string.IsNullOrEmpty(action))
            {
                if (HttpContext.Current.Request.HttpMethod.ToUpper() == "POST" && action == "upload")
                {
                    WSResult ws = FileHandler.UploadProposalFileForUser(context);
                    context.Response.Write(JsonUtil<WSResult>.JsonSerializerObject(ws));
                    return;
                }
            }
            context.Response.Write("Welcome");
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

    }
}
