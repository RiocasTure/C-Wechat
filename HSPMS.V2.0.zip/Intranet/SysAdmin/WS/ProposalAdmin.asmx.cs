﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using JsonView;
using System.Globalization;
//using Newtonsoft.Json.Linq;
using LEO.Project.WXProposal.Control;
using LEO.Project.WXProposal.Data.Entity;
using LEO.Project.WXProposal.Model.QueryFilter;
using LEO.Project.WXProposal.Model.Pagination;
using LEO.Project.WXProposal.Data.DAO;
using LEO.Project.Tools;
using LEO.Project.WXProposal.Data.Imports;
using System.IO;
using LEO.Project.WXProposal;
using Intranet.ICPService;
using LEO.Project.WXProposal.Validator;
using LEO.Project.WXProposal.Control.Validator;
using LEO.Project.WXProposal.Control.RPC;

namespace WebChatInterface.WS
{
    /// <summary>
    /// Summary description for Proposal
    /// </summary>
    [System.Web.Script.Services.ScriptService]
    public class ProposalAdminWS : System.Web.Services.WebService
    {
        [WebMethod]
        public string RPCCallTest()
        {
            //return ProposalSerialNumIPC.GetServerIPC().count();
            //return ProposalSerialNumPipe.GetPipeMsg();
            using (NamedPipeClient client = new NamedPipeClient(".", "test"))
            {
                string result = client.Query("eee");
                client.Dispose();
                return result;
            }
        }

        [WebMethod]
        public WSResult QueryProposalsForAdmin(string dataArr)
        {
            UserRole ur = AdminControl.GetCurrntNTUserURole(HttpContext.Current);
            if (ur == null || !UserRole.CheckRoleIntersection(ur.RoleName, AdminControl.ValidUserRoles))
                return WSResult.Result(false, -1, "Permission Deny!");
            ProposalFilter f = null;
            try
            {
                f = JsonUtil<ProposalFilter>.JsonDeserializeObject(dataArr); ;
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("QueryProposalsForAdmin Error:dataArr={0}", dataArr), e);
            }
            if (f == null)
            {
                f = new ProposalFilter();
                f.PageIndex = 1;
                f.PageSize = 10;
            }
            /*
            DateTime? dtb = DateTimeUtil.ParseDateTime(DateTimeUtil.FormatYMD, f.DateBegin);
            DateTime? dte = DateTimeUtil.ParseDateTime(DateTimeUtil.FormatYMD, f.DateEnd);
            f.JobNumber = string.IsNullOrEmpty(f.JobNumber) ? "" : f.JobNumber.Trim();
            f.Company = string.IsNullOrEmpty(f.Company) || f.Company == "~" ? "" : f.Company.Trim();
            f.Organ = string.IsNullOrEmpty(f.Organ) || f.Organ == "~" ? "" : f.Organ.Trim();
            f.Depart = string.IsNullOrEmpty(f.Depart) || f.Depart == "~" ? "" : f.Depart.Trim();
            f.EmpCategory = string.IsNullOrEmpty(f.EmpCategory) || f.EmpCategory == "~" ? "" : f.EmpCategory.Trim();
            f.Number = string.IsNullOrEmpty(f.Number) ? "" : f.Number.Trim();
            f.Category = string.IsNullOrEmpty(f.Category) || f.Category == "~" ? "" : f.Category.Trim();
            f.Status = string.IsNullOrEmpty(f.Status) || f.Status == "~" ? "" : f.Status.Trim();
            f.Audit = string.IsNullOrEmpty(f.Audit) || f.Audit == "~" ? "" : f.Audit.Trim();
            f.DateBegin = dtb.HasValue?dtb.Value.ToString(DateTimeUtil.FormatYMD):"";
            f.DateEnd = dte.HasValue ? dte.Value.ToString(DateTimeUtil.FormatYMD) : "";
            */
            f.WebFormOrganize();
            WSResult ws = WSResult.Result(true, 0, "Session Valid.");
            PageList pl = new PageList();//每頁10條記錄
            pl.PageSize = (f.PageSize > 5 && f.PageSize < 100) ? f.PageSize : 10;
            pl.PageIndex = f.PageIndex;
            ProposalInfoDAO.PaginationQueryForAdmin(ur, f, pl, false);
            ws.ResultObject = pl;
            return ws;
        }

        [WebMethod]
        public WSResult QueryProposalsReportForAdmin(string dataArr)
        {
            UserRole ur = AdminControl.GetCurrntNTUserURole(HttpContext.Current);
            if (ur == null || !UserRole.CheckRoleIntersection(ur.RoleName, AdminControl.ValidUserRoles))
                return WSResult.Result(false, -1, "Permission Deny!");
            ProposalFilter f = null;
            try
            {
                f = JsonUtil<ProposalFilter>.JsonDeserializeObject(dataArr); ;
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("QueryProposalsReportForAdmin Error:dataArr={0}", dataArr), e);
            }
            if (f == null)
            {
                f = new ProposalFilter();
                f.PageIndex = 1;
                f.PageSize = 10;
            }
            /*
            DateTime? dtb = DateTimeUtil.ParseDateTime(DateTimeUtil.FormatYMD, f.DateBegin);
            DateTime? dte = DateTimeUtil.ParseDateTime(DateTimeUtil.FormatYMD, f.DateEnd);
            f.JobNumber = string.IsNullOrEmpty(f.JobNumber) ? "" : f.JobNumber.Trim();
            f.Company = string.IsNullOrEmpty(f.Company) || f.Company == "~" ? "" : f.Company.Trim();
            f.Organ = string.IsNullOrEmpty(f.Organ) || f.Organ == "~" ? "" : f.Organ.Trim();
            f.Depart = string.IsNullOrEmpty(f.Depart) || f.Depart == "~" ? "" : f.Depart.Trim();
            //f.EmpCategory = string.IsNullOrEmpty(f.EmpCategory) || f.EmpCategory == "~" ? "" : f.EmpCategory.Trim();
            f.FollowProgress = string.IsNullOrEmpty(f.FollowProgress) || f.FollowProgress == "~" ? "" : f.FollowProgress.Trim();
            f.Number = string.IsNullOrEmpty(f.Number) ? "" : f.Number.Trim();
            f.Category = string.IsNullOrEmpty(f.Category) || f.Category == "~" ? "" : f.Category.Trim();
            f.Status = string.IsNullOrEmpty(f.Status) || f.Status == "~" ? "" : f.Status.Trim();
            f.Audit = string.IsNullOrEmpty(f.Audit) || f.Audit == "~" ? "" : f.Audit.Trim();
            f.DateBegin = dtb.HasValue ? dtb.Value.ToString(DateTimeUtil.FormatYMD) : "";
            f.DateEnd = dte.HasValue ? dte.Value.ToString(DateTimeUtil.FormatYMD) : "";
            */
            f.WebFormOrganize();
            WSResult ws = WSResult.Result(true, 0, "Session Valid.");
            PageList pl = new PageList();//每頁10條記錄
            pl.PageSize = (f.PageSize > 5 && f.PageSize < 100) ? f.PageSize : 10;
            pl.PageIndex = f.PageIndex;
            ProposalInfoDAO.PaginationQueryForAdmin(ur, f, pl, true);
            //if (!UserRole.CheckRole(urole, UserRole.Role_Super) && !UserRole.CheckRole(urole, UserRole.Role_Admin))
            if (!UserRole.CheckRoleIntersection(ur.RoleName, AdminControl.ValidAdminRoles))
            {
                ProposalAudit blank = new ProposalAudit();
                foreach (ProposalInfo pi in pl.PageData)
                    pi.AuditInfo.CopyOrganInfo(blank);
            }
            ws.ResultObject = pl;
            return ws;
        }

        [WebMethod]
        public WSResult QueryEmpProposalSummaryReportForAdmin(string dataArr)
        {
            UserRole ur = AdminControl.GetCurrntNTUserURole(HttpContext.Current);
            if (ur == null || !UserRole.CheckRoleIntersection(ur.RoleName, AdminControl.ValidUserRoles))
                return WSResult.Result(false, -1, "Permission Deny!");
            ProposalFilter f = null;
            try
            {
                f = JsonUtil<ProposalFilter>.JsonDeserializeObject(dataArr); ;
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("QueryEmpProposalSummaryReportForAdmin Error:dataArr={0}", dataArr), e);
            }
            if (f == null)
            {
                f = new ProposalFilter();
                f.PageIndex = 1;
                f.PageSize = 10;
            }
            DateTime? dtb = DateTimeUtil.ParseDateTime(DateTimeUtil.FormatYMD, f.DateBegin);
            DateTime? dte = DateTimeUtil.ParseDateTime(DateTimeUtil.FormatYMD, f.DateEnd);
            f.DateBegin = dtb.HasValue ? dtb.Value.ToString(DateTimeUtil.FormatYMD) : "";
            f.DateEnd = dte.HasValue ? dte.Value.ToString(DateTimeUtil.FormatYMD) : "";
            WSResult ws = WSResult.Result(true, 0, "Session Valid.");
            PageList pl = new PageList();//每頁10條記錄
            pl.PageSize = (f.PageSize > 5 && f.PageSize < 100) ? f.PageSize : 10;
            pl.PageIndex = f.PageIndex;
            ProposalInfoDAO.PaginationQueryProposalEmpSummaryForAdmin(ur, f, pl);
            ProposalInfoDAO.FillProposalEmpSumNumsForAdmin(ur, f, pl);
            ws.ResultObject = pl;
            return ws;
        }

        [WebMethod]
        public WSResult QueryEmployeesForAdmin(string dataArr)
        {
            if (AdminControl.GetCurrntNTUserRole(HttpContext.Current) == UserRole.Role_None)
                return WSResult.Result(false, -1, "Permission Deny!");
            EmployeeFilter f = null;
            try
            {
                f = JsonUtil<EmployeeFilter>.JsonDeserializeObject(dataArr); ;
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("QueryEmployeesForAdmin Error:dataArr={0}", dataArr), e);
            }
            if (f == null)
            {
                f = new EmployeeFilter();
                f.PageIndex = 1;
                f.PageSize = 10;
            }
            WSResult ws = WSResult.Result(true, 0, "Session Valid.");
            PageList pl = new PageList();
            pl.PageSize = (f.PageSize > 5 && f.PageSize<100)?f.PageSize:10;
            pl.PageIndex = f.PageIndex;
            EmployeeDAO.PaginationQuery(f,pl);
            ws.ResultObject = pl;
            return ws;
        }

        [WebMethod]
        public WSResult QueryWXUsersForAdmin(string dataArr)
        {
            if (AdminControl.GetCurrntNTUserRole(HttpContext.Current) == UserRole.Role_None)
                return WSResult.Result(false, -1, "Permission Deny!");
            WXUserFilter f = null;
            try
            {
                f = JsonUtil<WXUserFilter>.JsonDeserializeObject(dataArr); ;
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("QueryEmployeesForAdmin Error:dataArr={0}", dataArr), e);
            }
            if (f == null)
            {
                f = new WXUserFilter();
                f.PageIndex = 1;
                f.PageSize = 10;
            }
            WSResult ws = WSResult.Result(true, 0, "Session Valid.");
            PageList pl = new PageList();
            pl.PageSize = (f.PageSize > 5 && f.PageSize<100)?f.PageSize:10;
            pl.PageIndex = f.PageIndex;
            WXUserInfoDAO.PaginationQuery(f,pl);
            ws.ResultObject = pl;
            return ws;
        }

        /*
        [WebMethod]
        public WSResult GetOrganizationForAdmin(int Level)
        {
            UserRole ur = AdminControl.GetCurrntNTUserURole(HttpContext.Current);
            if (ur == null || !UserRole.CheckRoleIntersection(ur.RoleName, AdminControl.ValidUserRoles))
                return WSResult.Result(false, -1, "Permission Deny!");

            WSResult ws = WSResult.Result(true, 0, "Session Valid.");
            ws.ResultObject = EmployeeDAO.GetEmployeeOrganization(ur,Level);
            return ws;
        }
        */

        [WebMethod]
        public WSResult GetOrganizationTreeForAdmin(int Level)
        {
            /*
            if (AdminControl.GetCurrntNTUserRole(HttpContext.Current) == UserRole.Role_None)
                return WSResult.Result(false, -1, "Permission Deny!");
            */
            UserRole ur = AdminControl.GetCurrntNTUserURole(HttpContext.Current);
            if (ur == null || !UserRole.CheckRoleIntersection(ur.RoleName, AdminControl.ValidUserRoles))
                return WSResult.Result(false, -1, "Permission Deny!");
            WSResult ws = WSResult.Result(true, 0, "Session Valid.");
            ws.ResultObject = EmployeeDAO.GetEmployeeOrganizationTree(ur,Level);
            return ws;
        }

        [WebMethod]
        public WSResult GetProposalByNumberForAdmin(string pNumber)
        {
            if (AdminControl.GetCurrntNTUserRole(HttpContext.Current) == UserRole.Role_None)
                return WSResult.Result(false, -1, "Permission Deny!");
            WSResult ws = WSResult.Result(true, 0, "Session Valid.");
            ProposalInfo pi = ProposalInfoDAO.GetProposalByNumber(pNumber);
            if (pi != null)
            {
                EventLog log = EventLog.ProposalGetEvent(HttpContext.Current.Request.UserHostAddress, "", HttpUtil.GetHttpContextNTName(HttpContext.Current), pNumber);
                int logresult = EventLogDAO.InsertEventLog(log);
                if (logresult <= 0) WriteLog.Error("Log event fail in GetProposalByNumberForAdmin", null);
                if (pi.Attachments != null && pi.Attachments.Count > 0)
                {
                    string UploadPath = Path.Combine(HttpRuntime.AppDomainAppPath, SysConfig.Proposal_Attach_Path);
                    foreach (AttachmentInfo a in pi.Attachments)
                    {
                        a.FileSize = (int)FileUtil.GetFileSize(Path.Combine(UploadPath, a.FileDate.Value.ToString("yyyyMMdd")+'\\'+a.FilePath));
                    }
                }
                ws.ResultObject = pi;
            }
            return ws;
        }

        /*
        [WebMethod]
        public WSResult GetWXUserListByJobNumbersForAdmin(string jobNums)
        {
            if (string.IsNullOrEmpty(jobNums)) return WSResult.Result(false, 1, "請輸入職員工工號");
            string[] jobNumbers = jobNums.Split(',');
            List<WXUserInfo> wxulst = WXUserInfoDAO.GetWXUserListByJobNumbers(new List<string>(jobNumbers));
            if (wxulst == null) return WSResult.Result(false, 2, "職員工工號不存在");
            WSResult ws = WSResult.Result(true, 0, "Session Valid.");
            ws.ResultObject = wxulst;
            return ws;
        }
        */

        [WebMethod]
        public WSResult GetEmployeeWXUserByJobNumberForAdmin(string jobNumber)
        {
            /*
            if (AdminControl.GetCurrntNTUserRole(HttpContext.Current) == UserRole.Role_None)
                return WSResult.Result(false, -1, "Permission Deny!");
            */
            UserRole ur = AdminControl.GetCurrntNTUserURole(HttpContext.Current);
            //if (AdminControl.GetCurrntNTUserRole(HttpContext.Current) == UserRole.Role_None)
            if (ur == null || !UserRole.CheckRoleIntersection(ur.RoleName, AdminControl.ValidUserRoles))
                return WSResult.Result(false, -1, "Permission Deny!");

            if (string.IsNullOrEmpty(jobNumber)) return WSResult.Result(false, 1, "請輸入職員工工號");
            EmployeeView empv = EmployeeDAO.GetEmployeeWXUserByJobNumber(jobNumber);
            if (empv == null) return WSResult.Result(false, 2, "職員工工號不存在");
            //检查是否在管辖的事业部下属职员工
            bool empUnderManage = true;
            if (ur.OrganOperators != null && ur.OrganOperators.Count > 0)
            {
                empUnderManage = false;
                for (int i = 0; i < ur.OrganOperators.Count; i++)
                {
                    if (empv.Company == ur.OrganOperators[i].Company && empv.Organ == ur.OrganOperators[i].Organ)
                    {
                        empUnderManage = true;
                        break;
                    }
                }
            }
            if (!empUnderManage) return WSResult.Result(false, 3, "該職員工不屬於所管轄的事業部");
            WSResult ws = WSResult.Result(true, 0, "Session Valid.");
            ws.ResultObject = empv;
            return ws;
        }

        [WebMethod]
        public WSResult QuerySummary()
        {
            /*
            string ur = AdminControl.GetCurrntNTUserRole(HttpContext.Current);
            if (ur == UserRole.Role_None)
                return WSResult.Result(false, -1, "Permission Deny!");
            */
            UserRole ur = AdminControl.GetCurrntNTUserURole(HttpContext.Current);
            //if (AdminControl.GetCurrntNTUserRole(HttpContext.Current) == UserRole.Role_None)
            if (ur == null || !UserRole.CheckRoleIntersection(ur.RoleName, AdminControl.ValidUserRoles))
                return WSResult.Result(false, -1, "Permission Deny!");

            WSResult ws = WSResult.Result(true, 0, "Session Valid.");
            Dictionary<string, string> dict = null;
            if (UserRole.CheckRoleIntersection(ur.RoleName, AdminControl.ValidAdminRoles))
            {
                Dictionary<string, string> pDict = ProposalInfoDAO.Summary();
                Dictionary<string, string> eDict = EmployeeDAO.Summary();
                Dictionary<string, string> wDict = WXUserInfoDAO.Summary();
                dict = pDict.Concat(eDict).Concat(wDict).GroupBy(d => d.Key).ToDictionary(d => d.Key, d => d.First().Value);
                dict.Add("SumType", UserRole.Role_Admin);
            }
            else if (UserRole.Role_Operator == ur.RoleName)
            {
                dict = ProposalInfoDAO.Summary(ur.OrganOperators);
                dict.Add("SumType",UserRole.Role_Operator);
            }
            if (dict != null)
            {
                ADUser adu = ADUserDAO.instance.GetADUserByNTAccount(HttpUtil.GetHttpContextNTName(HttpContext.Current));
                dict.Add("nt_fullname", adu != null ? adu.CNName : "--");
                ws.ResultObject = dict;
            }
            return ws;
        }

        /*
        private WSResult ValidateProposalInput(ProposalInfo pi, string empArr, string fileArr)
        {
            if (pi == null) return WSResult.Result(false, 1, "輸入的提案信息有誤！");
            string[] emps = JsonUtil<string[]>.JsonDeserializeObject(empArr);
            if (emps == null || emps.Length == 0) return WSResult.Result(false, 1, "您未設定提案的職員工工號！");
            if (!ProposalCategory.CategoryExist(pi.Category))
                return WSResult.Result(false, 3, "未指定正确的改善类别！");
            if (!pi.FormDate.HasValue)
                return WSResult.Result(false, 3, "未指定提案日期！");
            if (string.IsNullOrEmpty(pi.Title) || pi.Title.Length < 1 || pi.Title.Length > 20)
                return WSResult.Result(false, 3, "提案名称输入內容長度不符合要求！");
            if (string.IsNullOrEmpty(pi.Description) || pi.Description.Length < 1 || pi.Description.Length > 200)
                return WSResult.Result(false, 3, "问题描述输入內容長度不符合要求！");
            if (string.IsNullOrEmpty(pi.Advice) || pi.Advice.Length < 1 || pi.Advice.Length > 200)
                return WSResult.Result(false, 3, "改善建议输入內容長度不符合要求！");
            if (!string.IsNullOrEmpty(pi.AuditInfo.FollowDesc) && pi.AuditInfo.FollowDesc.Length > 200)
                return WSResult.Result(false, 3, "補充描述不能超過200字！");
            if ((!string.IsNullOrEmpty(pi.AuditInfo.MajorAudit) && pi.AuditInfo.MajorAudit == ProposalStatus.Reject && (string.IsNullOrEmpty(pi.AuditInfo.MajorAuditDesc) || pi.AuditInfo.MajorAuditDesc.Trim().Length < 4)) ||
                (!string.IsNullOrEmpty(pi.AuditInfo.MajorAuditDesc) && pi.AuditInfo.MajorAuditDesc.Trim().Length > 60))
                return WSResult.Result(false, 3, "審核建議输入內容長度不符合要求！");
            if ((!string.IsNullOrEmpty(pi.AuditInfo.OrganAudit) && pi.AuditInfo.OrganAudit == ProposalStatus.Reject && (string.IsNullOrEmpty(pi.AuditInfo.OrganAuditDesc) || pi.AuditInfo.OrganAuditDesc.Trim().Length < 4)) ||
                (!string.IsNullOrEmpty(pi.AuditInfo.OrganAuditDesc) && pi.AuditInfo.OrganAuditDesc.Trim().Length > 60))
                return WSResult.Result(false, 3, "審批建議输入內容長度不符合要求！");
            if (!string.IsNullOrEmpty(pi.AuditInfo.FollowPlan) && pi.AuditInfo.FollowPlan.Length > 200)
                return WSResult.Result(false, 3, "後續啟動項目概述不能超過200字！");
            if (!string.IsNullOrEmpty(pi.YieldingInfo.SONum) && string.IsNullOrEmpty(pi.YieldingInfo.ItemName))
                return WSResult.Result(false, 3, "未指定產品名稱！");
            if (!string.IsNullOrEmpty(pi.YieldingInfo.OtherResult) && pi.YieldingInfo.OtherResult.Length > 20)
                return WSResult.Result(false, 3, "其他改善成效不能超過20字！");
            if (pi.Submitters == null) pi.Submitters = new List<EmployeeView>();
            pi.Submitters.Clear();
            foreach (string jobnum in emps)
            {
                EmployeeView emp = EmployeeDAO.GetEmployeeWXUserByJobNumber(jobnum);
                if (emp != null && pi.Submitters.FirstOrDefault(s => s.JobNumber == emp.JobNumber) == null) pi.Submitters.Add(emp);
            }
            if (pi.Submitters.Count == 0) return WSResult.Result(false, 4, "輸入的提案者工号有誤！");
            if (pi.Submitters.Count > 2) return WSResult.Result(false, 4, "提案者數量不能超過2個！");
            pi.AuthorJobNumber = pi.Submitters[0].JobNumber;//默認提案者為第一個
            if (!string.IsNullOrEmpty(pi.WXOpenID))
            {
                WXUserInfo wui = WXUserInfoDAO.GetWXUserInfoByOpenId(pi.WXOpenID);
                if (wui == null) return WSResult.Result(false, 5, "指定的微信帳號不存在！");
                if (emps.Contains(wui.JobNumber))
                {
                    pi.AuthorJobNumber = wui.JobNumber;//如果指定了微信帳號，則提案者為微信帳號對應的工號
                    pi.WXUser = wui;
                }
                else return WSResult.Result(false, 5, "指定的微信帳號有誤！");
            }
            string[] files = JsonUtil<string[]>.JsonDeserializeObject(fileArr);
            if (files != null)
            {
                if (pi.Attachments == null) pi.Attachments = new List<AttachmentInfo>();
                foreach (string filePath in files)
                {
                    AttachmentInfo att = ProposalFileDAO.GetByFilePath(filePath);
                    if (att != null && (string.IsNullOrEmpty(att.RelatedKey) || att.RelatedKey == pi.Number)) pi.Attachments.Add(att);
                }
            }
            return null;
        }
        */

        [WebMethod]
        public WSResult SubmitProposalForAdmin(string dataArr,string empArr,string fileArr)
        {
            try
            {
                /*
                string ur = AdminControl.GetCurrntNTUserRole(HttpContext.Current);
                if (string.IsNullOrEmpty(ur) || ur == UserRole.Role_None || !UserRole.CheckRoleIntersection(ur, AdminControl.ValidUserRoles)) //Array.IndexOf(permitRoles,ur);
                    return WSResult.Result(false, -1, "Permission Deny!");
                */
                UserRole ur = AdminControl.GetCurrntNTUserURole(HttpContext.Current);
                //if (AdminControl.GetCurrntNTUserRole(HttpContext.Current) == UserRole.Role_None)
                if (ur == null || !UserRole.CheckRoleIntersection(ur.RoleName, AdminControl.ValidUserRoles))
                    return WSResult.Result(false, -1, "Permission Deny!");

                ProposalInfo pi = JsonUtil<ProposalInfo>.JsonDeserializeObject(dataArr);
                ValidateResult vr = ProposalInputValidator.ValidateInputData(ur, pi, empArr, fileArr);
                if (!vr.IsOK) return WSResult.Result(vr);
                ProposalInfo src = null;
                bool addRec = true;
                if (!string.IsNullOrEmpty(pi.Number))//更新
                {
                    src = ProposalInfoDAO.GetProposalByNumber(pi.Number);
                    if (src == null) return WSResult.Result(false, 2, "提案編號：" + pi.Number + " 對應的記錄不存在！");
                    pi.SubmitJobNumber = src.SubmitJobNumber;
                    pi.Status = src.Status;
                    pi.SubmitTime = src.SubmitTime.HasValue ? src.SubmitTime : DateTime.Now;
                    if (src.AuditInfo == null) src.AuditInfo = new ProposalAudit();
                    if (string.IsNullOrEmpty(src.AuditInfo.FollowPlanFD))//未完成
                    {
                        src.CopyBase(pi);
                        src.YieldingInfo = pi.YieldingInfo;
                        //src.AuditInfo = pi.AuditInfo;
                        src.AuditInfo.CopyAuditInfo(pi.AuditInfo);
                        src.Submitters = pi.Submitters;
                        src.WXUser = pi.WXUser;
                        src.Attachments = pi.Attachments;
                    }
                    //只有管理員才能填寫總部提案中心的審批內容
                    if (UserRole.CheckRoleIntersection(ur.RoleName, AdminControl.ValidAdminRoles))
                    {
                        src.AuditInfo.CopyOrganInfo(pi.AuditInfo);
                        if (!string.IsNullOrEmpty(src.AuditInfo.OrganAudit)) src.Status = src.AuditInfo.OrganAudit;
                    }
                    addRec = false;
                }
                else//新增
                {
                    src = pi;
                    src.Status = ProposalStatus.Received;
                    src.Number = ProposalInfoDAO.GenerateSerialNumber();
                    src.SubmitTime = DateTime.Now;
                }
                /******狀態自動轉換*******/
                if (src.Status == ProposalStatus.Bonus || src.Status == ProposalStatus.Reject || src.Status == ProposalStatus.Accepted)
                {
                    //TODO:已完成狀態是否允許修改？
                }
                else
                {
                    if (src.Status == ProposalStatus.Received && (src.AuditInfo.MajorAudit == ProposalStatus.Accepted || src.AuditInfo.MajorAudit == ProposalStatus.Reject))
                    {
                        src.Status = ProposalStatus.Audited;
                    }
                    else if (src.Status == ProposalStatus.Audited && (src.AuditInfo.OrganAudit == ProposalStatus.Accepted || src.AuditInfo.OrganAudit == ProposalStatus.Reject))
                    {
                        src.Status = src.AuditInfo.OrganAudit;
                    }
                }
                int updateCount = ProposalInfoDAO.SaveProposalInfo(src);
                if (updateCount > 0)
                {
                    string ip = HttpContext.Current.Request.UserHostAddress;
                    EventLog log = addRec ?
                        EventLog.ProposalAddEvent(ip, "", HttpUtil.GetHttpContextNTName(HttpContext.Current), src.Number) :
                        EventLog.ProposalModEvent(ip, "", HttpUtil.GetHttpContextNTName(HttpContext.Current), src.Number);
                    int logresult = EventLogDAO.InsertEventLog(log);
                    if (logresult <= 0) WriteLog.Error("Log event fail in SubmitProposalForAdmin", null);
                    WSResult ws = WSResult.Result(true, 0, "提案保存成功！");
                    ws.ResultObject = src.Number;
                    return ws;
                }
                else return WSResult.Result(false, -1, "提案保存失敗！");
            }
            catch (Exception ex)
            {
                WriteLog.Error("SubmitProposalForAdmin Exception", ex);
                return WSResult.Result(false, -1, "系統處理異常！請聯繫GISS(2955)。");
            }
        }

        [WebMethod]
        public WSResult SynAD(string password)
        {
            if (string.IsNullOrEmpty(password)) return WSResult.Result(false, -1, "安全密碼不能為空！");
            UserRole ur = UserRoleDAO.instance.GetUserRoleByUserID(HttpUtil.GetHttpContextNTName(HttpContext.Current));
            if (ur == null || !UserRole.CheckRole(ur.RoleName, UserRole.Role_Super))
                return WSResult.Result(false, -1, "Permission Deny!");
            if (!ur.CheckSecureCode(password)) return WSResult.Result(false, -1, "安全密碼錯誤！");
            //syn
            int count = DataImporter.ImportADUserData();
            if (count>0) return WSResult.Result(true, 0, "成功同步 "+count+" 條AD帳號記錄！");
            else return WSResult.Result(false, -1, "同步失敗！請聯繫開發人員處理。");
        }

        [WebMethod]
        public WSResult SubmitWXUserDeleteForAdmin(string dataArr,string password)
        {
            if (string.IsNullOrEmpty(password)) return WSResult.Result(false, -1, "安全密碼不能為空！");
            UserRole ur = UserRoleDAO.instance.GetUserRoleByUserID(HttpUtil.GetHttpContextNTName(HttpContext.Current));
            if (ur == null || (!UserRole.CheckRole(ur.RoleName, UserRole.Role_Super) && !UserRole.CheckRole(ur.RoleName, UserRole.Role_DBA)))
                return WSResult.Result(false, -1, "Permission Deny!");
            if (!ur.CheckSecureCode(password)) return WSResult.Result(false, -1, "安全密碼錯誤！");
            string[] openIds = null;
            try
            {
                openIds = JsonUtil<string[]>.JsonDeserializeObject(dataArr); ;
            }
            catch (Exception e)
            {
                WriteLog.Error(string.Format("SubmitWXUserDeleteForAdmin Error:dataArr={0}", dataArr), e);
            }
            if (openIds == null || openIds.Length == 0) return WSResult.Result(false, 1, "請選擇要刪除的微信帳號記錄！");
            else if (openIds.Length > 10) return WSResult.Result(false, 2, "您所選擇的記錄過多！");
            int result = WXUserInfoDAO.DeleteWXUserInfos(openIds);
            if (result > 0)
            {
                ////SessionDaemon.getInstance().RemoveUserSessionsByUserKeys(openIds,UserSessionType.WechatUser);
                return WSResult.Result(true, 0, "刪除成功！");
            }
            else return WSResult.Result(false, -2, "抱歉，因數據處理錯誤，刪除失敗！");
        }

        [WebMethod]
        public string GetPlatformUserRoleByNT()
        {
            string ur = AdminControl.GetCurrntNTUserRole(HttpContext.Current);
            string ntUser = HttpUtil.GetHttpContextNTName(HttpContext.Current);
            WriteLog.AppInfo("NT User Log: User=" + ntUser + ", Role=" + ur);
            return ur;
        }

        [WebMethod]
        public WSResult CheckSecurityCode(string code)
        {
            if (string.IsNullOrEmpty(code)) return WSResult.Result(false, -1, "安全密碼不能為空！");
            UserRole ur = UserRoleDAO.instance.GetUserRoleByUserID(HttpUtil.GetHttpContextNTName(HttpContext.Current));
            if (ur==null || (!UserRole.CheckRole(ur.RoleName, UserRole.Role_DBA) && !UserRole.CheckRole(ur.RoleName, UserRole.Role_Super)))
                return WSResult.Result(false, -1, "Permission Deny!");
            //check password
            if (ur.SecureCode == code) return WSResult.Result(true, 0, null);
            else return WSResult.Result(false, -1, "安全密碼錯誤！");
        }

        [WebMethod]
        public WSResult GetSEIInfo(string so)
        {
            string[] permitRoles = new string[] { UserRole.Role_Admin, UserRole.Role_Operator, UserRole.Role_DBA, UserRole.Role_Super };
            string ur = AdminControl.GetCurrntNTUserRole(HttpContext.Current);
            if (string.IsNullOrEmpty(ur) || ur == UserRole.Role_None || !UserRole.CheckRoleIntersection(ur, permitRoles)) //Array.IndexOf(permitRoles,ur);
                return WSResult.Result(false, -1, "Permission Deny!");
            ICPService rws = new ICPService();
            //SalesOrder sord = rws.GetSOInfo(so);
            //string seiInfo = rws.GetSEIInfo(so);
            WSResult ws = WSResult.Result(true, 0, "");
            ws.ResultObject = rws.GetSOInfo(so);
            return ws;
        }
    }
}
