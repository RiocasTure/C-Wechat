﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LEO.Project.WXProposal.Control;
using LEO.Project.WXProposal.Data.Entity;
using System.IO;
using LEO.Project.Tools;
using LEO.Project.WXProposal.Model.QueryFilter;
using LEO.Project.WXProposal.Model.Pagination;
using LEO.Project.WXProposal.Data.DAO;
using LEO.Project.WXProposal.Data.Exports;
using WebChatInterface.WS;
using System.Text.RegularExpressions;
using LEO.Project.WXProposal;
using LEO.Project.WXProposal.Data.Imports;
using LEO.Project.WXProposal.Web;

namespace Intranet.SysAdmin.WS
{
    /// <summary>
    /// Summary description for $codebehindclassname$
    /// </summary>
    public class Handler : IHttpHandler
    {


        public void ProcessRequest(HttpContext context)
        {
            try
            {
                string[] upFileRoles = new string[] { UserRole.Role_Admin, UserRole.Role_Operator };
                string[] upEmpRoles = new string[] { UserRole.Role_DBA, UserRole.Role_Super };
                string ur = AdminControl.GetCurrntNTUserRole(HttpContext.Current);
                if (string.IsNullOrEmpty(ur) || ur == UserRole.Role_None || (!UserRole.CheckRoleIntersection(ur, upFileRoles) && !UserRole.CheckRoleIntersection(ur, upEmpRoles)))
                {
                    context.Response.Write(JsonUtil<WSResult>.JsonSerializerObject(WSResult.Result(false, -1, "Permission Deny!")));
                    return;
                }

                string action = context.Request.Params["action"];
                if (!string.IsNullOrEmpty(action))
                {
                    if (action == "upload")
                    {
                        WSResult ws = FileHandler.UploadProposalFileForAdmin(context);//HttpContext.Current
                        context.Response.Write(JsonUtil<WSResult>.JsonSerializerObject(ws));
                        return;
                    }
                    else if (action == "download")
                    {
                        FileHandler.DownloadFileForAdmin(context);
                        return;
                    }
                    else if (action == "upload-employee")
                    {
                        WSResult ws = FileHandler.UploadEmployeeExcelForAdmin(context);//HttpContext.Current
                        context.Response.Write(JsonUtil<WSResult>.JsonSerializerObject(ws));
                        return;
                    }
                    else
                    {
                        FileHandler.ExportReportExcelForAdmin(context, action);//HttpContext.Current
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                WriteLog.Error(string.Format("Handler Exception!action={0},", context.Request.Params["action"]), ex);
                context.Response.Write(JsonUtil<WSResult>.JsonSerializerObject(WSResult.Result(false, 0, "系統異常！錯誤信息：" + ex.Message)));
                return;
            }
            context.Response.ContentType = "text/plain";
            context.Response.Write("404 Not Found");
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}
