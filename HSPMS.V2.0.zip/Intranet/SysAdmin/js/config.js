﻿var DataMethod = "POST",
	DataFeederBase = "./WS/ProposalAdmin.asmx/",
	GetSEIInfo = "GetSEIInfo",
	GetPlatformUserRoleByNT = "GetPlatformUserRoleByNT",
	GetOrganData = "GetOrganizationForAdmin",
	GetOrganTreeData = "GetOrganizationTreeForAdmin",
	QueryProposals = "QueryProposalsForAdmin",
	QueryProposalsReport = "QueryProposalsReportForAdmin",
	QueryEmpPropsSumReport = "QueryEmpProposalSummaryReportForAdmin",
	QueryEmployees = "QueryEmployeesForAdmin",
	QueryWXUsers = "QueryWXUsersForAdmin",
	GetSummary = "QuerySummary",
	GetWXUList = "GetWXUserListByJobNumbersForAdmin",
	GetEmployWXU = "GetEmployeeWXUserByJobNumberForAdmin",
	SaveProposal = "SubmitProposalForAdmin",
	DelWXUsers = "SubmitWXUserDeleteForAdmin",
	SynAD = "SynAD",
	CheckSecurityCode = "CheckSecurityCode";
	GetProposal = "GetProposalByNumberForAdmin",
	UploadFile = "./WS/Handler.ashx?action=upload",
	UploadEmpExcel = "./WS/Handler.ashx?action=upload-employee",
	ExportExcel = {"1":"./WS/Handler.ashx?action=proposal-q","2":"./WS/Handler.ashx?action=proposal-sum"},
	UploadPath = "../attach/";

var processQueueToken = 0;

var dataLoading = false;

/** Messages **/
var MSG_METHOD_RESPONSE_ERR = "系统响应错误！";
var DataTransError = "網絡傳輸異常";
var DataProcessError = "系统未能及时响应";

var LCProposals = false;
var LCProposalFilter = false;
//var LCProposal = false;
var DefaultPageSize = 10;
var MaxUploadFileLength = 5242880;
var DefaultSelect = {"EmptyValue":"~","EmptyText":"-- 不限 --"};