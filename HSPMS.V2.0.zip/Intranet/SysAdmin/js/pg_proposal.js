function ajaxAddEmployee(jobNumber){
	var dataObj = {"jobNumber":jobNumber};
	showLoadingMsg();
	$.ajax({
		type: DataMethod,
		url: noCacheUrl(DataFeederBase+GetEmployWXU),
		dataType: "json",
		contentType: "application/json; charset=utf-8",
		data: convertObj2AjaxData(dataObj),
		success: function(data){
			if (data && data.d && data.d.IsOK){
				if (data.d.ResultObject){
					renderEmployeeAdd(data.d.ResultObject);
				}else{
					alert("抱歉！因系统数据异常，本次操作失败！");
				}
				processQueueToken = 0;
			}else{
				if (data && data.d && data.d.SysMsg) alert(data.d.SysMsg);
				else alert("抱歉！"+DataProcessError+"，请稍候再试！");
			}
			hideLoadingMsg();
		},
		error: function (jqXHR, textStatus, errorThrown) {
			alert("抱歉！因"+DataTransError+"的原因，系统未能处理您的數據请求！");
			hideLoadingMsg();
		},
		timeout: 8000
	});
}
function ajaxLoadFilterData(){
	var TreeSelectArr = ["q_Company","q_Organ","q_Division","q_Depart","q_Group"];
	var dataObj = {"Level":TreeSelectArr.length};
	showLoadingMsg();
	$.ajax({
		type: DataMethod,
		url: noCacheUrl(DataFeederBase+GetOrganTreeData),
		data: convertObj2AjaxData(dataObj),
		dataType: "json",
		contentType: "application/json; charset=utf-8",
		success: function(data){
			if (!data.d || !data.d.IsOK){
				if (data.d && data.d.SysMsg) alert(data.d.SysMsg);
				else alert(MSG_METHOD_RESPONSE_ERR);
				return;
			}
			if (!data.d.ResultObject) return;
			var EmpOrganTree = {"NodeName":"root","Childrens":data.d.ResultObject.Companies};
			TreeSelect(EmpOrganTree,TreeSelectArr);
			$("ul#FilterList select").each(function(){setDefaultOption4Select($(this));});
			processQueueToken = 0;
		},
		error: function (jqXHR, textStatus, errorThrown) {
			alert("加載搜寻条件數據失敗("+DataTransError+")!");
			hideLoadingMsg();
		},
		timeout: 8000
	});
}

function ajaxLoadDataList(pageIdx){
	var pageIndex = pageIdx?parseInt(pageIdx):1;
	if (isNaN(pageIndex)) pageIndex = 1;
	if (!LCProposalFilter){
		LCProposalFilter = readInputDataToObjectProp($("ul#FilterList input,ul#FilterList select"),"q_");
		LCProposalFilter["PageSize"] = DefaultPageSize;
	}
	LCProposalFilter["PageIndex"] = pageIndex;
	var dataObj = {"dataArr":$.toJSON(LCProposalFilter)};
	showLoadingMsg();
	$.ajax({
		type: DataMethod,
		url: noCacheUrl(DataFeederBase+QueryProposals),
		dataType: "json",
		contentType: "application/json; charset=utf-8",
		data: convertObj2AjaxData(dataObj),
		success: function(data){
			if (data && data.d && data.d.IsOK){
				if (data.d.ResultObject){
					LCProposals = data.d.ResultObject;
					renderListData();
					initEventOfTable();
				}else{
					alert("抱歉！因系统数据异常，本次查询失败！");
				}
				processQueueToken = 0;
			}else{
				if (data && data.d && data.d.SysMsg) alert(data.d.SysMsg);
				else alert("抱歉！"+DataProcessError+"，请稍候再试！");
			}
			hideLoadingMsg();
		},
		error: function (jqXHR, textStatus, errorThrown) {
			alert("抱歉！因"+DataTransError+"的原因，系统未能处理您的查询请求！");
			hideLoadingMsg();
		},
		timeout: 8000
	});
}
function ajaxGetProposalData(number){
	var dataObj = {"pNumber":number};
	showLoadingMsg();
	$.ajax({
		type: DataMethod,
		url: noCacheUrl(DataFeederBase+GetProposal),
		dataType: "json",
		contentType: "application/json; charset=utf-8",
		data: convertObj2AjaxData(dataObj),
		success: function(data){
			if (data && data.d && data.d.IsOK){
				if (data.d.ResultObject){
					renderProposal(data.d.ResultObject);
				}else{
					alert("抱歉！因系统数据异常，本次查询失败！");
				}
				processQueueToken = 0;
			}else{
				if (data && data.d && data.d.SysMsg) alert(data.d.SysMsg);
				else alert("抱歉！"+DataProcessError+"，请稍候再试！");
			}
			hideLoadingMsg();
		},
		error: function (jqXHR, textStatus, errorThrown) {
			alert("抱歉！因"+DataTransError+"的原因，系统未能处理您的查询请求！");
			hideLoadingMsg();
		},
		timeout: 8000
	});
}
function ajaxSaveProposalData(dataObj){
	showLoadingMsg();
	$.ajax({
		type: DataMethod,
		url: noCacheUrl(DataFeederBase+SaveProposal),
		dataType: "json",
		contentType: "application/json; charset=utf-8",
		data: convertObj2AjaxData(dataObj),
		success: function(data){
			if (data && data.d && data.d.IsOK){
				if (data.d.SysMsg && data.d.SysMsg.length>0) alert(data.d.SysMsg);
				var pNumber = $("#i_Number").attr("data-val");
				if (pNumber==""){//如果系新增則清除篩選條件，否則按原篩選條件加載
					clearObjectProp(LCProposalFilter);
					LCProposalFilter["pNumber"] = (data.d.ResultObject?data.d.ResultObject:"");
					initObjectProp2Input(LCProposalFilter,"q_");
					LCProposalFilter["PageIndex"] = 1;
				}
				$("#ProposalWin").fadeOut("fast",function(){});
				ajaxLoadDataList(LCProposalFilter["PageIndex"]);
				processQueueToken = 0;
			}else{
				if (data && data.d && data.d.SysMsg) alert(data.d.SysMsg);
				else alert("抱歉！"+DataProcessError+"，请稍候再试！");
			}
			hideLoadingMsg();
		},
		error: function (jqXHR, textStatus, errorThrown) {
			alert("抱歉！因"+DataTransError+"的原因，系统未能处理您的數據请求！");
			hideLoadingMsg();
		},
		timeout: 8000
	});
}
function ajaxGetSEIName(sonum){//,setVal
	//$("#i_YieldingInfo\\.ItemName").prop('options').length=0;
	$("#i_YieldingInfo\\.ItemName").val("");
	if (sonum==""){
		$("#i_YieldingInfo\\.ItemName").val("");
		$("#i_YieldingInfo\\.SONum").val("");
		processQueueToken = 0;
		return;
	}
	showLoadingMsg("正在獲取工程單號"+sonum+"的產品名稱 ...");
	var dataObj = {"so":sonum};
	$.ajax({
		type: DataMethod,
		url: noCacheUrl(DataFeederBase+GetSEIInfo),
		dataType: "json",
		contentType: "application/json; charset=utf-8",
		data: convertObj2AjaxData(dataObj),
		success: function(data){
			if (data && data.d && data.d.IsOK){
				/*
				var seiOpts = $("#i_YieldingInfo\\.ItemName").prop('options');
				var seiArr = $.secureEvalJSON(data.d.ResultObject);
				if (isEmpty(seiArr)||!seiArr.length||seiArr.length<=0){
					alert("SO Number不存在："+sonum);
					$("#i_YieldingInfo\\.SONum").val("");
					$("#i_YieldingInfo\\.ItemName").val("");
				}else{
					var valInc = false;
					for (var i=0;i<seiArr.length;i++){
						if (setVal && !valInc && setVal==seiArr[i]["SEIName"]) valInc = true;
						seiOpts.add(new Option(seiArr[i]["SEIName"],seiArr[i]["SEIName"]));
					}
					if (valInc) $("#i_YieldingInfo\\.ItemName").val(setVal);
				}
				*/
				var ord = data.d.ResultObject;
				if (isEmpty(ord)||!ord.SONo||!ord.SOChiProgramName){
					alert("SO Number不存在："+sonum);
					$("#i_YieldingInfo\\.SONum").val("");
					$("#i_YieldingInfo\\.ItemName").val("");
				}else{
					$("#i_YieldingInfo\\.ItemName").val(ord.SOChiProgramName);
				}
			}else{
				if (data && data.d && data.d.SysMsg) alert(data.d.SysMsg);
				else alert("抱歉！"+DataProcessError+"，無法獲取對應的產品名稱，请稍候再试！");
				$("#i_YieldingInfo\\.SONum").val("");
				$("#i_YieldingInfo\\.ItemName").val("");
			}
			hideLoadingMsg();
			processQueueToken = 0;
		},
		error: function (jqXHR, textStatus, errorThrown) {
			alert("抱歉！因"+DataTransError+"的原因，無法獲取對應的產品名稱！");
			$("#i_YieldingInfo\\.SONum").val("");
			$("#i_YieldingInfo\\.ItemName").val("");
			hideLoadingMsg();
			processQueueToken = 0;
		},
		timeout: 8000
	});
}

function calProposalEffAmount(){
	var effAmtCal = calEffAmount(
		$("#i_YieldingInfo\\.WorkersNow").val(),		//改善前人數
		$("#i_YieldingInfo\\.WorkersOptimized").val(),	//改善後人數
		$("#i_YieldingInfo\\.EffNow").val(),			//改善前效率
		$("#i_YieldingInfo\\.EffOptimized").val(),		//改善後效率
		$("#i_YieldingInfo\\.OrderQty").val()			//訂單數量
	);
	$("#i_EffAmountCal").html(effAmtCal!=0?accounting.formatNumber(effAmtCal):'計算參數未完整');
}
function renderProposal(proposal){
	if (!proposal) return;
	renderProposalInput(proposal);
	$("#ProposalWin").fadeIn("fast",function(){
		$("#ProposalWin div.Content").scrollTop(0);
		setTimeout(calProposalEffAmount,500);
	});
}
function renderProposalInput(p){
	//重置清空輸入項
	$("#ProposalWin div.Content .i_a").each(function(){
		var nodeType = $(this).prop('nodeName').toLowerCase();
		if (nodeType=="input"||nodeType=="select"||nodeType=="textarea"){
			$(this).val("");
		}else if (nodeType=="span"){
			var dfval = $(this).attr("data-default");
			if (typeof(dfval)!="undefined") $(this).html(dfval);
			else $(this).html("");
			$(this).attr("data-val","");
		}
	});
	//$("#i_YieldingInfo\\.ItemName").prop('options').length=0;
	renderEmployeeClear();
	renderEmployeeWX();
	renderAttachClear();
	var pbe = $("div#ProposalBeforeEnd");
	var pe = $("div#ProposalEnd");
	var pbeInputs = $("div#ProposalBeforeEnd input,div#ProposalBeforeEnd textarea,div#ProposalBeforeEnd select");
	var pbeMask = $("div#ProposalBeforeEnd div.ReadonlyMask");
	pbeInputs.prop('disabled', false);
	pbeMask.css("display","none");
	$("li#EmployeeOptLi").css("display","block");
	$("li#FileOptLi").css("display","block");
	if (!p || typeof p != 'object') return;

	if (!isEmpty(p.Submitters)){
		for (var i=0;i<p.Submitters.length;i++){
			renderEmployeeAdd(p.Submitters[i]);
		}
	}
	if (!isEmpty(p.Attachments)){
		for (var i=0;i<p.Attachments.length;i++){
			renderAttachAdd(p.Attachments[i]);
		}
	}
	var isAdmin = hasUserRole(SysRole.Admin)||hasUserRole(SysRole.Super);
	$("#ProposalEnd").css("display",isAdmin?"block":"none");
	$("#AuditView").css("display",isAdmin?"none":"block");
	var isFininshed = p.AuditInfo && p.AuditInfo.FollowPlanFD && p.AuditInfo.FollowPlanFD!="";
	$("#pSaveBtn").css("display",(isAdmin||!isFininshed)?"inline-block":"none").prop("disable",(isAdmin||!isFininshed)?false:true);
	if (isFininshed){
		pbeInputs.prop('disabled', true);
		$("li#EmployeeOptLi").css("display","none");
		$("li#FileOptLi").css("display","none");
		pbeMask.fadeIn("fast",function(){
			var rect = $("div#ProposalBeforeEnd").get(0).getBoundingClientRect();
			$(this).css("top",rect.top+"px").css("height",(rect.bottom-rect.top)+"px");
			$("div#ProposalBeforeEnd a").css("display","none");
		});
	}
	//$("#i_WXOpenID").val(LCProposal.WXOpenID);
	initObjectProp2Input(p,"i_");
	initObjectProp2Input(p,"v_");
	/*
	ajaxGetSEIName(
		(!isEmpty(p.YieldingInfo) && !isEmpty(p.YieldingInfo.SONum))?p.YieldingInfo.SONum:null,
		(!isEmpty(p.YieldingInfo) && !isEmpty(p.YieldingInfo.ItemName))?p.YieldingInfo.ItemName:null
	);
	*/
	/*
	if (!isEmpty(p.YieldingInfo) && !isEmpty(p.YieldingInfo.SONum) && p.YieldingInfo.SONum!="")
		pushProcQueue(null,function(){ajaxGetSEIName(p.YieldingInfo.SONum);});
	pushProcQueue(null,function(){initObjectProp2Input(p,"i_");processQueueToken = 0;});
	*/
}
function renderEmployeeClear(){
	$("#iEJobNumber").val("");
	var wxuOpts = $("#i_WXOpenID").prop('options');
	wxuOpts.length=0;
	wxuOpts[wxuOpts.length] =  new Option("-- 無 --", "");
	$("table#i_Submitters tbody tr").remove();
}
function renderEmployeeAdd(emp){
	$("table#i_Submitters").children("tbody").append('<tr data-jobnum="'+emp.JobNumber+'"><td><input type="hidden" name="i_EmpJobNum" value="'
		+emp.JobNumber+'"/>'+emp.JobNumber+'</td><td>'+emp.FullName+'</td><td>'+emp.Category+'</td><td>'
		+emp.Company+'</td><td>'+emp.Organ+'</td><td>'+emp.Depart+'</td><td>'+nullStr(emp.SectionChiefName)+'</td><td class="CntTbOptTd"><a href="#">刪除</a></td></tr>');
	if (!isEmpty(emp.WXUserList)){
		var wxuOpts = $("#i_WXOpenID").prop('options');
		for (var j=0;j<emp.WXUserList.length;j++){
			wxuOpts[wxuOpts.length] =  new Option("工號："+emp.WXUserList[j].JobNumber+" / 暱稱："+emp.WXUserList[j].NickName, emp.WXUserList[j].OpenID);
		}
	}
	renderEmployeeWX();
	initEventOfEmployee();
}
function renderEmployeeWX(){
	var emptyTr = $("table#i_Submitters tbody tr").length<=0;
	$("li#emplist").css("display",emptyTr?"none":"list-item");
	$("li#wxlist").css("display",emptyTr?"none":"list-item");
}
function renderAttachClear(){
	$("table#i_Attachments tbody tr").remove();
	$("li#attlist").css("display","none");
}
function renderAttachAdd(attach){
	var dd = attach.FileDate;
	var folder = "";
	if (dd.startWith("\/Date(") && dd.endWith(")\/")){
		dd = dotNetDateConvert(dd);
	}else{
		if (DateTimeTReg.test(dd)||DateTimeReg.test(dd))
			dd = parseDateTime(dd);
	}
	if (dd instanceof Date){
		folder = dd.format("yyyyMMdd")+"/";
		dd = dd.format("yyyy-MM-dd hh:mm");
	}
	$("table#i_Attachments").children("tbody").append('<tr><td><input type="hidden" name="i_AttFilePath" value="'
		+attach.FilePath+'"/>'+(attach.FileSize>0?('<a href="'+UploadPath+folder+attach.FilePath+'/'+encodeURI(attach.FileName)+'" target="_blank">'):'')+attach.FileName+(attach.FileSize>0?'</a>':'')+'</td><td>'+(attach.FileSize>=0?convertFileSize(attach.FileSize):'<i>不存在</i>')+'</td><td>'+dd+'</td><td class="CntTbOptTd"><a href="#">刪除</a></td></tr>');
	$("li#attlist").css("display","list-item");
	initEventOfAttach();
}
function renderListData(){
	if (!LCProposals) return;
	$("#plist tbody tr").remove();
	var tbodyHtml = '';
	var baseIdx = (LCProposals.PageIndex-1)*LCProposals.PageSize+1;
	for (var i=0;i<LCProposals.PageData.length;i++){
		var p = LCProposals.PageData[i];
		tbodyHtml += 
			'<tr'+(i%2==0?'':' class="even"')+' data-idx="'+i+'"><th>'+(baseIdx+i)+'</th><td>'+p.Number+'</td><td>'+
			p.FormDate.substr(0,10)+'</td><td>'+p.SubmitTime+'</td><td>'+p.Author+'</td><td>'+p.JobNumber+'</td><td>'+
			p.Category+'</td><td>'+p.Title+'</td><td>'+p.Status+'</td></tr>';
	}
	var cols = $("#plist thead:last th").length-1;
	for (var i=LCProposals.PageData.length;i<DefaultPageSize;i++){
		tbodyHtml += '<tr class="blanktr'+(i%2==0?'':'_even')+'"><th>&nbsp;</th>';
		for (var j=0;j<cols;j++) tbodyHtml += '<td>&nbsp;</td>';
		tbodyHtml += '</tr>';
	}
	//if (tbodyHtml=='') tbodyHtml='<tr><th></th><td colspan="7">无记录</td></tr>';
	$("#plist").children("tbody").html(tbodyHtml);
	initObjectProp2Input(LCProposals,"",true);
	$("#PageNaviBtns").css("display",LCProposals.PageCount>1?"table-cell":"none");
	$("#PageNaviSum").css("display",LCProposals.PageCount>1?"table-cell":"none");
	$("#PageNaviRowCount").css("display",LCProposals.RowsCount>1?"inline":"none");
	$("#spanFirst").attr("pageVal",1);
	$("#spanPre").attr("pageVal",LCProposals.PageIndex-1);
	$("#spanNext").attr("pageVal",LCProposals.PageIndex+1);
	$("#spanLast").attr("pageVal",LCProposals.PageCount);
	$("#spanFirst").removeClass("pageClick");
	$("#spanPre").removeClass("pageClick");
	if (LCProposals.PageCount>1 && LCProposals.PageIndex>1){
		$("#spanFirst").addClass("pageClick");
		$("#spanPre").addClass("pageClick");
	}
	$("#spanNext").removeClass("pageClick");
	$("#spanLast").removeClass("pageClick");
	if (LCProposals.PageCount>1 && LCProposals.PageIndex<LCProposals.PageCount){
		$("#spanNext").addClass("pageClick");
		$("#spanLast").addClass("pageClick");
	}
}

var pUploadFormOptions = {
	beforeSend: function(){showLoadingMsg();},
	uploadProgress: function(event, position, total, percentComplete){},
	success: function(){},
	complete: function(response){
		hideLoadingMsg();
		$("#UploadForm").trigger("reset");
		if (response && response.responseText 
			//&& response.status && response.readyState && response.status==200 && response.readyState==4
			){
				var msgObj = $.secureEvalJSON(response.responseText);
				if (msgObj){
					if (msgObj.IsOK){
							if (!isEmpty(msgObj.ResultObject)){
								for (var i=0;i<msgObj.ResultObject.length;i++){
									renderAttachAdd(msgObj.ResultObject[i]);
								}
							}
					}else{
						alert(msgObj.SysMsg);
					}
				}else{
					alert("服務器響應信息錯誤！");
				}
		}else alert("服務器響應未完成！");
		//alert($.toJSON(response));
		//
	}
};
function initEventOfTable(){
	$("td#PageNaviBtns span").unbind("click");
	$("td#PageNaviBtns span").bind("click",function(){
		var pI = parseInt($(this).attr("pageVal"));
		if (isNaN(pI)||pI>LCProposals.PageCount||pI<1)
			return;
		else{
			if (pI!=LCProposals.PageIndex) ajaxLoadDataList(pI);
		}
	});
	$("#PageIndex").unbind("blur");
	$("#PageIndex").bind("blur",function(){
		var pI = parseInt($(this).val());
		if (isNaN(pI)||pI>LCProposals.PageCount||pI<1)
			$(this).val(LCProposals.PageIndex);
		else{
			if (pI!=LCProposals.PageIndex) ajaxLoadDataList(pI);
		}
	});
	$("#plist tbody tr").each(function(){
		$(this).unbind("click");
		$(this).bind("click",function(){
			var dataIdx = $(this).attr("data-idx");
			if (LCProposals && LCProposals.PageData && LCProposals.PageData.length && LCProposals.PageData[dataIdx])
			ajaxGetProposalData(LCProposals.PageData[dataIdx].Number);
		});
	});
}
function initEventOfEmployee(){
	$("#emplist table tbody tr td.CntTbOptTd a").unbind("click");
	$("#emplist table tbody tr td.CntTbOptTd a").bind("click",function(){
		var tr = $(this).closest("tr");
		var jobNum = tr.attr("data-jobnum");
		$("#i_WXOpenID option").each(function(){
			var txt = $(this).text();
			if (txt.startWith("工號："+jobNum)) $(this).remove();
		});
		$(this).closest("tr").remove();
		renderEmployeeWX();
		return false;
	});
}
function initEventOfAttach(){
	$("#attlist table tbody tr td.CntTbOptTd a").unbind("click");
	$("#attlist table tbody tr td.CntTbOptTd a").bind("click",function(){
		$(this).closest("tr").remove();
		var emptyTr = $("table#i_Attachments tbody tr").length<=0;
		$("li#attlist").css("display",emptyTr?"none":"list-item");
		return false;
	});
}
function validateInputOfProposal(proposal){
	var emptyStr = "";
	if (proposal.AuditInfo.FollowProgress.length>0&&proposal.AuditInfo.FollowPlanBD.length==0)
		emptyStr+=(emptyStr==""?"":"、")+"計劃開始日期";
	if (proposal.AuditInfo.FollowProgress.length>0&&proposal.AuditInfo.FollowPlanED.length==0)
		emptyStr+=(emptyStr==""?"":"、")+"計劃完成日期";
	if (proposal.AuditInfo.FollowProgress=="已完成"&&proposal.AuditInfo.FollowPlanFD.length==0)
		emptyStr+=(emptyStr==""?"":"、")+"實際完成日期";
	if (proposal.AuditInfo.OrganAudit.length>0&&proposal.AuditInfo.OrganCfmDate.length==0)
		emptyStr+=(emptyStr==""?"":"、")+"審批日期";
	if (emptyStr.length>0) alert("以下內容為必填項：\n\n"+emptyStr);
	return emptyStr.length==0;
}
function initEventOfButtons(){
	$("#qSubmitBtn").unbind("click");
	$("#qSubmitBtn").bind("click",function(){
		LCProposalFilter = readInputDataToObjectProp($("ul#FilterList input,ul#FilterList select"),"q_");
		LCProposalFilter["oPageSize"] = DefaultPageSize;
		ajaxLoadDataList(1);
	});
	$("#pAddBtn").unbind("click");
	$("#pAddBtn").bind("click",function(){
		renderProposalInput();
		renderEmployeeClear();
		$("#ProposalWin").fadeIn("fast",function(){
			$("#ProposalWin div.Content").scrollTop(0);
		});
	});
	$("#pCancelBtn").unbind("click");
	$("#pCancelBtn").bind("click",function(){
		$("#ProposalWin div.Content").scrollTop(0);
		$("#ProposalWin").fadeOut("fast",function(){});
	});
	$("#iEAddBtn").unbind("click");
	$("#iEAddBtn").bind("click",function(){
		var emplst = getInputValueArrayByName("i_EmpJobNum");
		if (emplst.length>1){
			alert("共同提案人不能超過2個！");
			return;
		}
		var jobNumber = $("#iEJobNumber").val().trim();
		if (jobNumber==""||jobNumber.length!=7){
			alert("請輸入正確的職員工工號！");
			return;
		}
		if (emplst.indexOf(jobNumber)>=0){
			alert("該職員工已添加！");
			return;
		}
		ajaxAddEmployee(jobNumber);
	});
	$("#pSaveBtn").unbind("click");
	$("#pSaveBtn").bind("click",function(){
		var proposal = readInputDataToObjectProp($("#ProposalWin div.Content .i_a"),"i_");
		var empArr = getInputValueArrayByName("i_EmpJobNum");
		var fileArr = getInputValueArrayByName("i_AttFilePath");
		if (validateInputOfProposal(proposal)){
			var dataObj = {"dataArr":toJSONStr(proposal),"empArr":toJSONStr(empArr),"fileArr":toJSONStr(fileArr)};
			ajaxSaveProposalData(dataObj);
		}
	});
	$('#UploadForm').ajaxForm(pUploadFormOptions);
	$("#iPFileAddBtn").unbind("click");
	$("#iPFileAddBtn").bind("click",function(){
		if ($("#iPFile").val()==""){
			alert("請選擇要上傳的文件！");
		}else{
			$("#UploadForm").prop("action",UploadFile);
			$("#UploadForm").submit();
		}
	});
	//$('#ProposalWin input[type="number"]').each(function(){
	$('#ProposalWin input.number').each(function(){
		$(this).numericInput();
		$(this).unbind("change");
		$(this).change(calProposalEffAmount);
		//$(this).numeric();
	});
	$("#i_YieldingInfo\\.SONum").unbind("change");
	$("#i_YieldingInfo\\.SONum").bind("change",function(){
		$(this).val($(this).val().toUpperCase().trim());
		ajaxGetSEIName($(this).val());
	});
	var fdRequire = function(){
		$("#i_AuditInfo\\.FollowPlanBD").parent().children("label").children("b.require").css(
			"display",($("#i_AuditInfo\\.FollowProgress").val()!="")?"inline":"none");
		$("#i_AuditInfo\\.FollowPlanED").parent().children("label").children("b.require").css(
			"display",($("#i_AuditInfo\\.FollowProgress").val()!="")?"inline":"none");
		$("#i_AuditInfo\\.FollowPlanFD").parent().children("label").children("b.require").css(
			"display",($("#i_AuditInfo\\.FollowProgress").val()=="已完成")?"inline":"none");
		$("#i_AuditInfo\\.OrganCfmDate").parent().children("label").children("b.require").css(
			"display",($("#i_AuditInfo\\.OrganAudit").val()=="")?"none":"inline");
	};
	$("#i_AuditInfo\\.FollowPlanFD").unbind("change");
	$("#i_AuditInfo\\.FollowPlanFD").bind("change",function(){
		$("#i_AuditInfo\\.FollowProgress").val("已完成");
		fdRequire();
	});
	$("#i_AuditInfo\\.FollowProgress").unbind("change");
	$("#i_AuditInfo\\.FollowProgress").bind("change",function(){
		fdRequire();
	});
	$("#i_AuditInfo\\.OrganAudit").unbind("change");
	$("#i_AuditInfo\\.OrganAudit").bind("change",function(){
		fdRequire();
	});
	fdRequire();
	var OrganCfmChange = function(){
		$("#i_AuditInfo\\.OrganBonusMonth").val("");
		var ocfmDate = new Date($(this).val().replace(/\-/g,'\/'));
		if (!isNaN(ocfmDate)){
			ocfmDate.setDate(1);
			ocfmDate.setMonth(ocfmDate.getMonth()+1);
			$("#i_AuditInfo\\.OrganBonusMonth").val(ocfmDate.format("yyyy/MM"));
		}
	};
	$("#i_AuditInfo\\.OrganCfmDate").unbind($.getIeVer()>0?"textinput":"input");
	$("#i_AuditInfo\\.OrganCfmDate").bind($.getIeVer()>0?"textinput":"input",OrganCfmChange);
}

function initDatas(){
	pushProcQueue("正在加載：搜寻条件數據...",ajaxLoadFilterData);
	pushProcQueue("正在加載：改善提案數據...",ajaxLoadDataList);
	pushProcQueue(null,function(){
		hideLoadingMsg();
		initEventOfButtons();
		setupKeyboardHandler(27,function(){
			if ($("#pCancelBtn").length==1){
				$("#pCancelBtn").click();
			}
			return true;
		});
	});
}
