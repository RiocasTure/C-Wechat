var searchReady=false;
var searchAjax=null;
/***********************************
 Header Functions
 ***********************************/
$(document.getElementsByTagName('head')[0]).append('<link href="./images/favicon.ico" rel="shortcut icon">');
$(document.getElementsByTagName('head')[0]).append('<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">');

/***********************************
 Number Format Functions
 ***********************************/
function calEffAmount(wn,wo,en,eo,oq){
	wn = parseInt(wn);wn = isNaN(wn)?0:wn;
	wo = parseInt(wo);wo = isNaN(wo)?0:wo;
	en = parseInt(en);en = isNaN(en)?0:en;
	eo = parseInt(eo);eo = isNaN(eo)?0:eo;
	oq = parseInt(oq);oq = isNaN(oq)?0:oq;
	return (en>0&&eo>0)?(60*(wn/en-wo/eo)*oq*0.1):0;
}
/***********************************
 Queue Functions
 ***********************************/
var proccessQueue = new Array();
var checkProcInterval;
function pushProcQueue(message,func){
	proccessQueue.push({"msg":message,"action":func});
	if (!checkProcInterval){
		checkProcInterval = setInterval(function(){
			if (proccessQueue.length==0){
				clearInterval(checkProcInterval);
				checkProcInterval = false;
				hideLoadingMsg();
			}else{
				if (processQueueToken==0){
					var proc = proccessQueue.shift();
					if (proc && (typeof proc.action == "function")){
						if (proc.msg && proc.msg!=null){
							showLoadingMsg(proc.msg);
						}else hideLoadingMsg();
						processQueueToken = 1;
						setTimeout(proc.action,10);
					}
				}
			}
		},20);
	}
}

/***********************************
 Page Loading Functions
 ***********************************/
function showLoadingMsg(msg){
	$("#premask").remove();
	$("#loading_mask").remove();
	var showMsg = (msg?msg:"正在加載")+" ...";
	$(document.body).append('<div id="loading_mask"><p><span>'+showMsg+'</span></p></div>');
	$("#loading_mask").fadeIn("fast",function(){});
}

function showAlertMsg(msg){
	$("#premask").remove();
	$("#loading_mask").remove();
	$(document.body).append('<div id="loading_mask" class="alert"><p><span>'+msg+'</span></p></div>');
	$("#loading_mask").fadeIn("fast",function(){});
}

function hideLoadingMsg(){
	$("#premask").remove();
	$("#loading_mask").fadeOut("fast",function(){$("#loading_mask").remove();});
}

function showMasking(msg){
	var mask = document.getElementById("premask");
	if (!mask){
		mask = document.createElement("div");
		mask.id="premask";
		//masking.style.cssText="";
		if (document.body.firstChild){
			document.body.insertBefore(mask, document.body.firstChild);
		} else {
			document.body.appendChild(mask);
		}
	}
	if (mask) mask.innerHTML = msg;
}

/***********************************
 Select Option Functions
 ***********************************/
function setDefaultOption4Select(selectObj,defaultPair){
	var defaultVal = defaultPair&&defaultPair.val?defaultPair.val:DefaultSelect.EmptyValue;
	var defaultTxt = defaultPair&&defaultPair.txt?defaultPair.txt:DefaultSelect.EmptyText;
	if (!selectObj) return;
	var opts = selectObj.prop('options');
	if (!opts) return;
	var selectedOpt = selectObj.find("option[selected=true]");
	/*
	*/
	for (var i=0;i<opts.length;i++){
		if (opts[i].value==defaultVal) return;
	}
	/*
	*/
	opts.add(new Option(defaultTxt,defaultVal),0);
	//alert(selectObj.find("option:selected").text());
	if (selectedOpt.length==0) selectObj.val(defaultVal);
}

/***********************************
 Page Initialization Functions
 ***********************************/
function initDateInput(){
	if (!InputTypes.date){
		var dateInputs = $('input[type="date"]');
		for (var i=0;i<dateInputs.length;i++){
			$(dateInputs[i]).prop("type","text");
			$(dateInputs[i]).removeClass("tcal").addClass("tcal");
		}
		//if (dateInputs.length>0) f_tcalInit();
	}
	f_tcalInit();
}
function checkFileInputName(fileInput,exts,extsDesc){
	var fileName = fileInput.val();
	var idx = fileName.lastIndexOf('\\');
	if (idx>=0) fileName = fileName.substr(idx+1);
	idx = fileName.lastIndexOf('/');
	if (idx>=0) fileName = fileName.substr(idx+1);
	if (fileName==""){
		alert("請選擇要上傳的文件！");
		return '';
	}
	if (!exts || exts=='') return fileName;
	idx = fileName.lastIndexOf('.');
	var ext = idx>=0?fileName.substr(idx):'';
	var ext_a = exts.toUpperCase().split('|');
	if ($.inArray(ext.toUpperCase(),ext_a)>=0) return fileName;
	if (extsDesc && extsDesc!='') alert(extsDesc);
	else alert("上傳文件只支持"+exts+"格式！");
	return '';
}

/***********************************
 Initialization
 ***********************************/
function initAll(){
	userChecking();
}
if (window.attachEvent){
	window.attachEvent("onload",initAll);
}else if (window.addEventListener){
	window.addEventListener("load",initAll,false);
}