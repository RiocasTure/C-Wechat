function ajaxLoadFilterData(){
	var TreeSelectArr1 = ["q1_Company","q1_Organ","q1_Division","q1_Depart","q1_Group"];
	var TreeSelectArr2 = ["q2_Company","q2_Organ","q2_Division","q2_Depart","q2_Group"];
	var dataObj = {"Level":TreeSelectArr1.length};
	showLoadingMsg();
	$.ajax({
		type: DataMethod,
		url: noCacheUrl(DataFeederBase+GetOrganTreeData),
		data: convertObj2AjaxData(dataObj),
		dataType: "json",
		contentType: "application/json; charset=utf-8",
		success: function(data){
			if (!data.d || !data.d.IsOK){
				if (data.d && data.d.SysMsg) alert(data.d.SysMsg);
				else alert(MSG_METHOD_RESPONSE_ERR);
				return;
			}
			if (!data.d.ResultObject) return;
			var EmpOrganTree = {"NodeName":"root","Childrens":data.d.ResultObject.Companies};
			TreeSelect(EmpOrganTree,TreeSelectArr1);
			TreeSelect(EmpOrganTree,TreeSelectArr2);
			$("ul#FilterList1 select").each(function(){setDefaultOption4Select($(this));});
			$("ul#FilterList2 select").each(function(){setDefaultOption4Select($(this));});
			processQueueToken = 0;
		},
		error: function (jqXHR, textStatus, errorThrown) {
			alert("抱歉！因"+DataTransError+"的原因，系统未能处理您的數據请求！");
			hideLoadingMsg();
		},
		timeout: 8000
	});

}

function ajaxLoadDataList(pageIdx){
	var pageIndex = pageIdx?parseInt(pageIdx):1;
	if (isNaN(pageIndex)) pageIndex = 1;
	var reportIdx = $("ul#reportTabsUL li.ui-tabs-active").attr("data-rptidx");
	queryFilter = readInputDataToObjectProp($("ul#FilterList"+reportIdx+" input,ul#FilterList"+reportIdx+" select"),"q"+reportIdx+"_");
	replaceObjectStrProp(queryFilter,DefaultSelect.EmptyValue,"");
	queryFilter["PageSize"] = DefaultPageSize;
	queryFilter["PageIndex"] = pageIndex;
	var dataObj = {"dataArr":$.toJSON(queryFilter)};
	showLoadingMsg();
	$.ajax({
		type: DataMethod,
		url: noCacheUrl(DataFeederBase+(reportIdx=="1"?QueryProposalsReport:QueryEmpPropsSumReport)),
		dataType: "json",
		contentType: "application/json; charset=utf-8",
		data: convertObj2AjaxData(dataObj),
		success: function(data){
			if (data && data.d && data.d.IsOK){
				if (data.d.ResultObject){
					renderListData(reportIdx,data.d.ResultObject);
					initEventOfTable(data.d.ResultObject);
				}else{
					alert("抱歉！因系统数据异常，本次查询失败！");
				}
				processQueueToken = 0;
			}else{
				if (data && data.d && data.d.SysMsg) alert(data.d.SysMsg);
				else alert("抱歉！"+DataProcessError+"，请稍候再试！");
			}
			hideLoadingMsg();
		},
		error: function (jqXHR, textStatus, errorThrown) {
			alert("抱歉！因"+DataTransError+"的原因，系统未能处理您的查询请求！");
			hideLoadingMsg();
		},
		timeout: 8000
	});
}

function longDescTDSpan(str){
	return '<td title="'+str+'"><span>'+str+'</span></td>';
}

function renderListData(reportIdx,pageData){
	$("#Pagination").css("display",(!pageData)?"none":"block");
	if (!reportIdx) return;
	var tb = $("#plist"+reportIdx);
	var isAdmin = hasUserRole(SysRole.Admin)||hasUserRole(SysRole.Super);
	if (tb.length<=0) return;
	$("#plist"+reportIdx+" tbody tr").remove();
	var tbodyHtml = '';
	var cols = $("#plist"+reportIdx+" thead:last th").length-1;
	if (!isAdmin) $("#plist"+reportIdx+" thead th.audit_organ").remove();
	if (!pageData){
		for (var i=0;i<DefaultPageSize;i++){
			tbodyHtml += '<tr class="blanktr'+(i%2==0?'':'_even')+'"><th>&nbsp;</th>';
			for (var j=0;j<cols;j++) tbodyHtml += '<td>&nbsp;</td>';
			tbodyHtml += '</tr>';
		}
	}else{
		var baseIdx = (pageData.PageIndex-1)*pageData.PageSize+1;
		for (var i=0;i<pageData.PageData.length;i++){
			var p = pageData.PageData[i];
			if (reportIdx==1){
				var y = p.YieldingInfo;
				var a = p.AuditInfo;
				//var effAmtCal = calEffAmount(y.WorkersNow,y.WorkersOptimized,y.EffNow,y.EffOptimized,y.OrderQty);//(effAmtCal>0?accounting.formatNumber(effAmtCal):'')
				tbodyHtml += 
					'<tr'+(i%2==0?'':' class="even"')+' data-idx="'+i+'"><th>'+(baseIdx+i)+'</th>'+'<td>'+p.Submitters[0].FullName+'</td><td>'+
					p.Submitters[0].JobNumber+'</td><td>'+p.Submitters[0].ProposalWeight+'</td><td>'+p.Submitters[0].Company+'</td><td>'+
					p.Submitters[0].Organ+'</td><td>'+p.Submitters[0].Depart+'</td><td>'+nullStr(p.Submitters[0].SectionChiefName)+'</td><td>'+
					p.Submitters[0].Category+'</td><td>'+nullStr(p.Submitters[0].Mobile)+'</td><td>'+p.Number+'</td><td>'+
					dotNetDateConvert(p.FormDate).format("yyyy-MM-dd")+'</td><td>'+p.Status+'</td><td>'+p.Category+'</td>'+
					longDescTDSpan(p.Title)+longDescTDSpan(p.Description)+longDescTDSpan(p.Advice)+'<td>'+y.SONum+'</td><td>'+
					nullStr(y.ItemName)+'</td><td>'+y.OrderQty+'</td><td>'+y.EQID+'</td><td>'+y.EQName+'</td><td>'+a.MajorCfm+'</td><td>'+
					a.MajorCfmDate+'</td><td>'+a.MajorAudit+'</td><td>'+a.MajorAuditDesc+'</td><td>'+a.FollowCharger+'</td><td>'+
					a.FollowProgress+'</td><td>'+a.FollowPlanBD+'</td><td>'+a.FollowPlanED+'</td><td>'+a.FollowPlanFD+'</td>'+
					longDescTDSpan(a.FollowPlan)+longDescTDSpan(a.FollowDesc)+'<td>'+y.WorkersNow+'</td><td>'+y.WorkersOptimized+'</td><td>'+
					y.EffNow+'</td><td>'+y.EffOptimized+'</td><td>'+y.DPRateNow+'</td><td>'+y.DPRateOptimized+'</td><td>'+nullStr(y.OtherResult)+'</td>'+
					(isAdmin?('<td>'+a.OrganAudit+'</td><td>'+a.OrganAuditDesc+'</td><td>'+a.OrganCfmDate+'</td><td>'+a.OrganBonusMonth+'</td><td>'+
					y.CalEffAmount+'</td><td>'+a.OrganEffAmount+'</td><td>'+a.OrganEffDesc+'</td>'):'')+'</tr>';
			}else{
				tbodyHtml += 
					'<tr'+(i%2==0?'':' class="even"')+' data-idx="'+i+'"><th>'+(baseIdx+i)+'</th>'+'<td>'+p.FullName+'</td><td>'+p.JobNumber+'</td><td>'+
					p.Mobile+'</td><td>'+p.Company+'</td><td>'+p.Organ+'</td><td>'+p.Depart+'</td><td>'+p.EmpCategory+'</td><td>'+p.ReceivedCount+'</td><td>'+
					p.ReceivedNums+'</td><td>'+p.AuditedCount+'</td><td>'+p.AuditedNums+'</td><td>'+p.AcceptCount+'</td><td>'+p.AcceptNums+'</td><td>'+
					p.RejectCount+'</td><td>'+p.RejectNums+'</td><td>'+p.SumTotal+'</td></tr>';//p.Total
			}
		}
		for (var i=pageData.PageData.length;i<DefaultPageSize;i++){
			tbodyHtml += '<tr class="blanktr'+(i%2==0?'':'_even')+'"><th>&nbsp;</th>';
			for (var j=0;j<cols;j++) tbodyHtml += '<td>&nbsp;</td>';
			tbodyHtml += '</tr>';
		}
		initObjectProp2Input(pageData,"",true);
		$("#PageNaviBtns").css("display",pageData.PageCount>1?"table-cell":"none");
		$("#PageNaviSum").css("display",pageData.PageCount>1?"table-cell":"none");
		$("#PageNaviRowCount").css("display",pageData.RowsCount>1?"inline":"none");
		$("#spanFirst").attr("pageVal",1);
		$("#spanPre").attr("pageVal",pageData.PageIndex-1);
		$("#spanNext").attr("pageVal",pageData.PageIndex+1);
		$("#spanLast").attr("pageVal",pageData.PageCount);
		$("#spanFirst").removeClass("pageClick");
		$("#spanPre").removeClass("pageClick");
		if (pageData.PageCount>1 && pageData.PageIndex>1){
			$("#spanFirst").addClass("pageClick");
			$("#spanPre").addClass("pageClick");
		}
		$("#spanNext").removeClass("pageClick");
		$("#spanLast").removeClass("pageClick");
		if (pageData.PageCount>1 && pageData.PageIndex<pageData.PageCount){
			$("#spanNext").addClass("pageClick");
			$("#spanLast").addClass("pageClick");
		}
	}
	$("#plist"+reportIdx).children("tbody").html(tbodyHtml);
}

function initEventOfTable(pageData){
	$("td#PageNaviBtns span").unbind("click");
	$("td#PageNaviBtns span").bind("click",function(){
		var pI = parseInt($(this).attr("pageVal"));
		if (isNaN(pI)||pI>pageData.PageCount||pI<1)
			return;
		else{
			if (pI!=pageData.PageIndex) ajaxLoadDataList(pI);
		}
	});
	$("#PageIndex").unbind("blur");
	$("#PageIndex").bind("blur",function(){
		var pI = parseInt($(this).val());
		if (isNaN(pI)||pI>pageData.PageCount||pI<1)
			$(this).val(pageData.PageIndex);
		else{
			if (pI!=pageData.PageIndex) ajaxLoadDataList(pI);
		}
	});
}
function initEventOfButtons(){
	$("#qSubmitBtn").unbind("click");
	$("#qSubmitBtn").bind("click",function(){
		var reportIdx = $("ul#reportTabsUL li.ui-tabs-active").attr("data-rptidx");
		ajaxLoadDataList(1);
	});
	$("#pExportBtn").unbind("click");
	$("#pExportBtn").bind("click",function(){
		var reportIdx = $("ul#reportTabsUL li.ui-tabs-active").attr("data-rptidx");
		queryFilter = readInputDataToObjectProp($("ul#FilterList"+reportIdx+" input,ul#FilterList"+reportIdx+" select"),"q"+reportIdx+"_");
		replaceObjectStrProp(queryFilter,DefaultSelect.EmptyValue,"");
		queryFilter["PageSize"] = 0;
		queryFilter["PageIndex"] = 1;
		var url = ExportExcel[reportIdx];
		if (url && url !=null && url!=""){
			$.download(url,"filterArr",$.toJSON(queryFilter));
		}else alert("請指定報表！");
	});
}


function initDatas(){
	pushProcQueue("正在加載：搜寻条件數據...",ajaxLoadFilterData);
	pushProcQueue("正在初始化報表...",function(){renderListData("plist1");renderListData("plist2");processQueueToken = 0;});
	pushProcQueue(null,function(){
		$("#reportTabs").tabs();
		$("#reportTabs").css("display","block");
		var isAdmin = hasUserRole(SysRole.Admin)||hasUserRole(SysRole.Super);
		if (!isAdmin) $("#plist1 thead th.audit_organ").remove();
		hideLoadingMsg();
		initEventOfButtons();
	});
}
