function ajaxLoadFilterData(){
    var TreeSelectArr = ["q_Company", "q_Organ", "q_Division", "q_Depart", "q_Group", "q_JobTitle"];
	var dataObj = {"Level":TreeSelectArr.length};
	showLoadingMsg();
	$.ajax({
		type: DataMethod,
		url: noCacheUrl(DataFeederBase+GetOrganTreeData),
		data: convertObj2AjaxData(dataObj),
		dataType: "json",
		contentType: "application/json; charset=utf-8",
		success: function(data){
			if (!data.d || !data.d.IsOK){
				if (data.d && data.d.SysMsg) alert(data.d.SysMsg);
				else alert(MSG_METHOD_RESPONSE_ERR);
				return;
			}
			if (!data.d.ResultObject) return;
			var EmpOrganTree = {"NodeName":"root","Childrens":data.d.ResultObject.Companies};
			TreeSelect(EmpOrganTree,TreeSelectArr,TreeSelectArr[TreeSelectArr.length-1]);
			$("ul#FilterList select").each(function(){setDefaultOption4Select($(this));});
			processQueueToken = 0;
		},
		error: function (jqXHR, textStatus, errorThrown) {
			alert("加載搜寻条件數據失敗("+DataTransError+")!");
			hideLoadingMsg();
		},
		timeout: 8000
	});
}
function ajaxLoadDataList(pageIdx){
	var pageIndex = pageIdx?parseInt(pageIdx):1;
	if (isNaN(pageIndex)) pageIndex = 1;
	queryFilter = readInputDataToObjectProp($("ul#FilterList input,ul#FilterList select"),"q_");
	replaceObjectStrProp(queryFilter,DefaultSelect.EmptyValue,"");
	queryFilter["PageSize"] = DefaultPageSize;
	queryFilter["PageIndex"] = pageIndex;
	var dataObj = {"dataArr":$.toJSON(queryFilter)};
	showLoadingMsg();
	$.ajax({
		type: DataMethod,
		url: noCacheUrl(DataFeederBase+QueryEmployees),
		dataType: "json",
		contentType: "application/json; charset=utf-8",
		data: convertObj2AjaxData(dataObj),
		success: function(data){
			if (data && data.d && data.d.IsOK){
				if (data.d.ResultObject){
					renderListData(data.d.ResultObject);
					initEventOfTable(data.d.ResultObject);
				}else{
					alert("抱歉！因系统数据异常，本次查询失败！");
				}
				processQueueToken = 0;
			}else{
				if (data && data.d && data.d.SysMsg) alert(data.d.SysMsg);
				else alert("抱歉！"+DataProcessError+"，请稍候再试！");
			}
			hideLoadingMsg();
		},
		error: function (jqXHR, textStatus, errorThrown) {
			alert("抱歉！因"+DataTransError+"的原因，系统未能处理您的查询请求！");
			hideLoadingMsg();
		},
		timeout: 8000
	});
}
function ajaxADSyn(pass){
	var dataObj = {"password":pass};
	showLoadingMsg("後台數據同步中，請耐心等待 ...");
	$.ajax({
		type: DataMethod,
		url: noCacheUrl(DataFeederBase+SynAD),
		dataType: "json",
		contentType: "application/json; charset=utf-8",
		data: convertObj2AjaxData(dataObj),
		success: function(data){
			if (data && data.d && data.d.IsOK){
				alert(data.d.SysMsg);
				processQueueToken = 0;
			}else{
				if (data && data.d && data.d.SysMsg) alert(data.d.SysMsg);
				else alert("抱歉！"+DataProcessError+"，请稍候再试！");
			}
			hideLoadingMsg();
		},
		error: function (jqXHR, textStatus, errorThrown) {
			alert("AD帳號同步失敗("+DataTransError+")!");
			hideLoadingMsg();
		},
		timeout: 120000
	});
}
function submitExcelUpload(pass){
	var options = {
		beforeSend: function(){showLoadingMsg("資料上傳中，請耐心等待 ...");},
		uploadProgress: function(event, position, total, percentComplete){},
		success: function(){},
		complete: function(response){
			hideLoadingMsg();
			$("#UploadExcelForm").trigger("reset");
			$("#UploadExcelForm").css("display","none");
			if (response && response.responseText ){
					var msgObj = $.secureEvalJSON(response.responseText);
					if (msgObj){
						if (msgObj.IsOK){
							alert((msgObj.SysMsg?msgObj.SysMsg:"上傳成功！")+"\n\n將重新加載主檔數據。");
							$("#qSubmitBtn").trigger('click');
						}else{
							alert((msgObj.SysMsg?msgObj.SysMsg:"上傳失敗！")+"\n\n請檢查網絡連接或聯繫開發人員！");
						}
					}else{
						alert("服務器響應信息錯誤！");
					}
			}else alert("服務器響應未完成！");
		}
	};
	$("#iUploadCode").val(pass);
	$('#UploadExcelForm').ajaxForm(options);
	$("#UploadExcelForm").prop("action",UploadEmpExcel);
	$("#UploadExcelForm").submit();
}

function renderListData(pageData){
	if (!pageData) return;
	$("#elist tbody tr").remove();
	var tbodyHtml = '';
	var baseIdx = (pageData.PageIndex-1)*pageData.PageSize+1;
	for (var i=0;i<pageData.PageData.length;i++){
		var e = pageData.PageData[i];
		tbodyHtml += 
		'<tr'+(i%2==0?'':' class="even"')+' data-idx="'+i+'"><th>'+(baseIdx+i)+'</th><td>'+e.JobNumber+
		'</td><td>'+e.FullName+'</td><td>'+e.IDNumSuffix+'</td><td>'+e.Gender+'</td><td>'+
		(e.Status==1?"在職":e.Status==2?"離職":"無效")+'</td><td>'+e.EntryDate+'</td><td>'+
		e.Category+'</td><td>'+e.JobTitle+'</td><td>'+e.Company+'</td><td>'+e.Organ+'</td><td>'+
		e.Division+'</td><td>'+e.Depart+'</td><td>'+e.Group+'</td><td>'+
		dotNetDateConvert(e.LastUpdate).format("yyyy-MM-dd hh:mm")+'</td></tr>';
	}
	var cols = $("#elist thead:last th").length-1;
	for (var i=pageData.PageData.length;i<DefaultPageSize;i++){
		tbodyHtml += '<tr class="blanktr'+(i%2==0?'':'_even')+'"><th>&nbsp;</th>';
		for (var j=0;j<cols;j++) tbodyHtml += '<td>&nbsp;</td>';
		tbodyHtml += '</tr>';
	}
	$("#elist").children("tbody").html(tbodyHtml);
	initObjectProp2Input(pageData,"",true);
	$("#PageNaviBtns").css("display",pageData.PageCount>1?"table-cell":"none");
	$("#PageNaviSum").css("display",pageData.PageCount>1?"table-cell":"none");
	$("#PageNaviRowCount").css("display",pageData.RowsCount>1?"inline":"none");
	$("#spanFirst").attr("pageVal",1);
	$("#spanPre").attr("pageVal",pageData.PageIndex-1);
	$("#spanNext").attr("pageVal",pageData.PageIndex+1);
	$("#spanLast").attr("pageVal",pageData.PageCount);
	$("#spanFirst").removeClass("pageClick");
	$("#spanPre").removeClass("pageClick");
	if (pageData.PageCount>1 && pageData.PageIndex>1){
		$("#spanFirst").addClass("pageClick");
		$("#spanPre").addClass("pageClick");
	}
	$("#spanNext").removeClass("pageClick");
	$("#spanLast").removeClass("pageClick");
	if (pageData.PageCount>1 && pageData.PageIndex<pageData.PageCount){
		$("#spanNext").addClass("pageClick");
		$("#spanLast").addClass("pageClick");
	}
}

function initEventOfTable(pageData){
	$("td#PageNaviBtns span").unbind("click");
	$("#PageIndex").unbind("blur");
	if (pageData){
		$("td#PageNaviBtns span").bind("click",function(){
			var pI = parseInt($(this).attr("pageVal"));
			if (isNaN(pI)||pI>pageData.PageCount||pI<1)
				return;
			else{
				if (pI!=pageData.PageIndex) ajaxLoadDataList(pI);
			}
		});
		$("#PageIndex").bind("blur",function(){
			var pI = parseInt($(this).val());
			if (isNaN(pI)||pI>pageData.PageCount||pI<1)
				$(this).val(pageData.PageIndex);
			else{
				if (pI!=pageData.PageIndex) ajaxLoadDataList(pI);
			}
		});
	}
}
var excelFileUploadInterval;
function initEventOfButtons(){
	$("#qSubmitBtn").unbind("click");
	$("#qSubmitBtn").bind("click",function(){
		ajaxLoadDataList(1);
	});
	$("#eSynADBtn").css("display",hasUserRole("Super")?"inline-block":"none");
	$("#eSynADBtn").unbind("click");
	$("#eSynADBtn").click(function(){
		if (confirm("同步AD帳號需要花費較長等待時間！\n\n您確認要進行同步操作嗎？")){
			popSecureWin(ajaxADSyn);
		}
	});
	$("#eUploadBtn").unbind("click");
	if (hasUserRole("DBA")||hasUserRole("Super")){
		$("#eUploadBtn").css("display","inline-block");
		$("#eUploadBtn").click(function(){
			if ($("#UploadExcelForm").css("display")=="none"){
				$("#UploadExcelForm").css("display","inline");
			}else{
				var fileName = checkFileInputName($("#iUploadFile"),'.xls|.xlsx','上傳文件只支持Excel 2003/2007/2010格式！');
				if (fileName!=''){
					if (confirm("資料上傳成功後即更新替換原有的職員工主檔資料！\n\n確定要上傳以下職員工主檔資料：\n\n『"+fileName+"』？")){
						popSecureWin(submitExcelUpload,function(){
							$("#UploadExcelForm").trigger("reset");
							$("#UploadExcelForm").css("display","none");
						});
					}
				}else $("#UploadExcelForm").trigger("reset");
			}
		});
	}else $("#eUploadBtn").css("display","none");
}

function initDatas(){
	pushProcQueue("正在加載：搜寻条件數據...",ajaxLoadFilterData);
	pushProcQueue("正在加載：職員工主檔數據...",ajaxLoadDataList);
	pushProcQueue(null,function(){
		hideLoadingMsg();
		initEventOfButtons();
		setupKeyboardHandler(27,function(){
			if ($("#UploadExcelForm").css("display")!="none"){
				$("#UploadExcelForm").trigger("reset");
				$("#UploadExcelForm").css("display","none");
			}
			return true;
		});
	});
}
