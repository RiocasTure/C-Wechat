/***********************************
 jQuery Functions
 ***********************************/
jQuery.download = function(url, key, data){
    // Build a form
    var form = $('<form></form>').attr('action', url).attr('method', 'post').attr('target', '_blank');
    // Add the one key/value
    form.append($("<input></input>").attr('type', 'hidden').attr('name', key).attr('value', data));
    //send request
    form.appendTo('body').submit().remove();
};
function checkJQ(){
	if (!(window.jq||window.jQuery)){
		alert("未能加載腳本，請進行刷新！");
		window.location.reload(true);
	}
}

jQuery.getIeVer = function() {
  var sAgent = window.navigator.userAgent;
  var Idx = sAgent.indexOf("MSIE");
  // If IE, return version number.
  if (Idx > 0) 
    return parseInt(sAgent.substring(Idx+ 5, sAgent.indexOf(".", Idx)));
  // If IE 11 then look for Updated user agent string.
  else if (!!navigator.userAgent.match(/Trident\/7\./)) 
    return 11;
  else
    return 0; //It is not IE
}
/***********************************
 Number Format Functions
 ***********************************/
/*
function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
*/
function numberWithCommas(x) {
    var parts = x.toString().split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return parts.join(".");
}
/***********************************
 Basic Functions
 ***********************************/
function getScrollY(){
	var doc = document.documentElement, body = document.body;
	var top1 = (doc && doc.scrollTop  || body && body.scrollTop  || 0);
	//var top2 = window.pageYOffset || document.documentElement.scrollTop;
	return top1;
}
if (!Array.prototype.indexOf) {
    Array.prototype.indexOf = function(obj, start) {
         for (var i = (start || 0), j = this.length; i < j; i++) {
             if (this[i] === obj) { return i; }
         }
         return -1;
    }
}
function convertFileSize(bytes) {
    var thresh = 1024;
    if(Math.abs(bytes) < thresh) {
        return bytes + ' B';
    }
    var units = ['KB','MB','GB','TB','PB','EB','ZB','YB'];
    var u = -1;
    do {
        bytes /= thresh;
        ++u;
    } while(Math.abs(bytes) >= thresh && u < units.length - 1);
    return bytes.toFixed(1)+' '+units[u];
}
/***********************************
 String Functions
 ***********************************/
function getSubStr(str,maxlen){
	if (str&&str.length&&str.length>maxlen)
		return str.substr(0,maxlen);
	return str;
}
function ellipsStr(str,maxlen){
	var ellips = "..";
	if (str.length>=(maxlen+ellips.length)){
		return str.substr(0,maxlen)+ellips;
	}
	return str;
}
function connectStrWithMinus(str1,str2){
	var prx = (str1!=''&&str1!=null);
	var sfx = (str2!=''&&str2!=null);
	if (prx && sfx){
		if (str1.indexOf(str2)>=0) return str1;
		if (str2.indexOf(str1)>=0) return str2;
	}
	return (prx?str1:'')+(sfx?((prx?' - ':'')+str2):'');
}
function hasQuoteChar(str){
	return (str && str!=null && str.length>0 && (str.indexOf("\'")>=0||str.indexOf("\"")>=0));
}
function escapeQuotation(str){
	var q = hasQuoteChar(str);
	var r = str.replaceAll("\"","&quot;").replaceAll("\'","&apos;");
	//var r = str.replaceAll("\"","\\\"").replaceAll("\'","&apos;");
	if (q) return r;
	return str;
}
function escapeRegExp(str) {
  return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}
if (!String.prototype.trim) {
	String.prototype.trim = function () {
		return this.replace(/^\s+|\s+$/g, '');
	};
}
if (!String.prototype.endWith) {
	String.prototype.endWith=function(s){
		var i=this.indexOf(s);
		return (i>=0)&&(this.length-s.length)==i;
	}
}
if (!String.prototype.startWith) {
	String.prototype.startWith=function(s){
		return this.indexOf(s)==0;
	}
}
if (!String.prototype.replaceAll){
	String.prototype.replaceAll=function(find,replace){
		return this.replace(new RegExp(escapeRegExp(find), 'g'), replace);
	}
}
function nullStr(str){
	if (str==null) return "";
	return str;
}

/***********************************
 DateTime Functions
 ***********************************/
var DateTimeTReg = /^((?:19|20)\d\d)-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])T(0\d{1}|1\d{1}|2[0-3]):[0-5]\d{1}:([0-5]\d{1})/;
var DateTimeReg = /^((?:19|20)\d\d)-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])\s(0\d{1}|1\d{1}|2[0-3]):[0-5]\d{1}:([0-5]\d{1})/;
function parseToDate(datestr){
	var arr = splitDate(datestr);
	if (arr.length==3){
		var date = new Date(arr[2],arr[1]-1,arr[0]);
		if (isFinite(date)&&(date.getFullYear()==arr[2])&&(date.getMonth()+1==arr[1])&&(date.getDate()==arr[0]))
			return date;
	}
	return false;
}
function parseDateTime(yyyyMMddHHmm){
	if (DateTimeTReg.test(yyyyMMddHHmm)||DateTimeReg.test(yyyyMMddHHmm)){
		var dt = yyyyMMddHHmm.substr(0,19).replace('T',' ');
		var a=dt.split(" ");
		var d=a[0].split("-");
		var t=a[1].split(":");
		return new Date(d[0],(d[1]-1),d[2],t[0],t[1],t[2]);
	}
	return false;
}
function parseTimeToDate(dateobj,timestr){
	if (!dateobj) return false;
	var arr = splitTime(timestr);
	if (arr.length==2){
		dateobj.setHours(arr[0]);
		dateobj.setMinutes(arr[1]);
		if (isFinite(dateobj)&&(dateobj.getHours()==arr[0])&&(dateobj.getMinutes()==arr[1]))
			return dateobj;
	}
	return false;
}
function splitDate(date){
	var result = new Array();
	try{
		var i = date.indexOf("/");
		if (i>-1){
			result[0] = date.substr(0,i);
			result[1] = date.substr(i+1);
			i = result[1].indexOf("/");
			if (i>-1){
				result[2] = result[1].substr(i+1);
				result[1] = result[1].substr(0,i);
				i = result[2].indexOf(" ");
				if (i>-1){
					result[3] = result[2].substr(i+1);
					result[2] = result[2].substr(0,i);
				}
			}
		}
	}catch(err){
	}
	return result;
}
function isDateInPeriod(d,begindate,days){
	var date = isFinite(d)?d:parseToDate(d);
	var startdate = isFinite(begindate)?begindate:parseToDate(begindate);
	var day = isNaN(parseInt(days))?0:parseInt(days);
	if (!isFinite(date) || !isFinite(startdate) || day==0) return false;
	var enddate = new Date(startdate);
	enddate.setDate(enddate.getDate()+days-1);
	return date>=startdate && date<=enddate;
}
function isDateAfter(d,begindate,days){
	var date = isFinite(d)?d:parseToDate(d);
	var startdate = isFinite(begindate)?begindate:parseToDate(begindate);
	var day = isNaN(parseInt(days))?0:parseInt(days);
	if (!isFinite(date) || !isFinite(startdate) || day==0) return false;
	var enddate = new Date(startdate);
	enddate.setDate(enddate.getDate()+days-1);
	return date>enddate;
}
function getDateAfterStr(begindate,days){
	var date = isFinite(begindate)?d:parseToDate(begindate);
	var day = isNaN(parseInt(days))?0:parseInt(days);
	if (!isFinite(date)|| day==0) return begindate;
	var enddate = new Date(date);
	enddate.setDate(enddate.getDate()+days);
	var res = dateStr(enddate);
	return res;
}
function splitTime(time){
	var result = new Array();
	try{
		var i = time.indexOf(":");
		if (i>-1){
			result[0] = time.substr(0,i);
			result[1] = time.substr(i+1);
			i = result[1].indexOf(":");
			if (i>-1){
				result[2] = result[1].substr(i+1);
				result[1] = result[1].substr(0,i);
			}
		}
	}catch(err){
	}
	return result;
}
function shortDateTime(date){
	if (isFinite(date)){
		return 
			((date.getDate()<10?'0':'')+date.getDate())+'/'+
			((date.getMonth()<9?'0':'')+(date.getMonth()+1))+'/'+date.getFullYear()+' '+
			((date.getHours()<10?'0':'')+date.getHours())+':'+
			((dateobj.getMinutes()<10?'0':'')+dateobj.getMinutes());
	}
	var arr = splitDate(date);
	if (arr.length<3) return date;
	var dt = arr[0]+'/'+arr[1]+'/'+arr[2];
	if (arr.length>3){
		var tar = splitTime(arr[3]);
		if (tar.length>0) dt = dt+' '+tar[0];
		if (tar.length>1) dt = dt+':'+tar[1];
		else dt = dt+':00';
	}
	return dt;
}
function dateStr(date){
	if (isFinite(date)){
		var dt = ((date.getDate()<10?'0':'')+date.getDate())+'/'+
			((date.getMonth()<9?'0':'')+(date.getMonth()+1))+'/'+date.getFullYear();
		return dt;
	}
	var arr = splitDate(date);
	if (arr.length<3) return date;
	var dt = arr[0]+'/'+arr[1]+'/'+arr[2];
	return dt;
}
function dateStrDDMM(date){
	if (isFinite(date)){
		var dt = 
			(date.getDate()<10?'0':'')+date.getDate()+'/'+
			(date.getMonth()<9?'0':'')+(date.getMonth()+1);
		return dt;
	}
	var arr = splitDate(date);
	if (arr.length<3) return date;
	var dt = arr[0]+'/'+arr[1];
	return dt;
}
function fillPreZero(val,len){
	var str = ''+val;
	var l = str.length;
	if (l<len){
		for (var i=l;i<len;i++){
			str = '0'+str;
		}
	}
	return str;
}
function dotNetDateConvert(str){
	var pref = "/Date(";
	var suff = ")/";
	var i=str.indexOf(pref);
	var j=str.indexOf(suff);
	var utctime = i>=0?((j>(i+pref.length))?str.substr(i+pref.length,(j-i-pref.length)):str.substr(i+pref.length)):"";
	if (utctime!=""){
		var d = new Date();
		//d.setUTCMilliseconds(utctime);
		d.setTime(utctime);
		return d;
	}
	return str;
}
if (!Date.prototype.format) {
	Date.prototype.format = function(fmt)
	{  
		var o = {
			"M+" : this.getMonth()+1,                 //月份
			"d+" : this.getDate(),                    //日
			"h+" : this.getHours(),                   //小时
			"m+" : this.getMinutes(),                 //分
			"s+" : this.getSeconds(),                 //秒
			"q+" : Math.floor((this.getMonth()+3)/3), //季度
			"S"  : this.getMilliseconds()             //毫秒
		};
		if(/(y+)/.test(fmt)) fmt=fmt.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length));
		for(var k in o)
			if(new RegExp("("+ k +")").test(fmt))
				fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));
		return fmt;
	}
}

var InputTypes = new Array();
if (InputTypes){
	var iptTest = document.createElement("input");
	iptTest.setAttribute("type", "date");
	InputTypes["date"] = (iptTest.type !== "text");
}

function getDateInputValue(inputObj){
	var dateStr = "";
	if (!InputTypes.date){
		dateStr = inputObj.val();
	}else{
		dateStr = inputObj.get(0).valueAsDate;
		dateStr = (!dateStr||dateStr==null)?"":dateStr.format("yyyy-MM-dd");
	}
	return dateStr;
}

function nowUTC(){
	var date = new Date();
	return Date.UTC(date.getFullYear(),date.getMonth() + 1,date.getDate(),date.getHours(),date.getMinutes(),date.getSeconds(),date.getMilliseconds()); 
}

/***********************************
 Url Functions
 ***********************************/
function noCacheUrl(url){
	var rad = Math.floor(Math.random() * ( 1000 + 1));
	/*
	if (url.indexOf("?")>=0) return url+"&utc="+nowUTC();
	return url+"?utc="+nowUTC();
	*/
	if (url.indexOf("?")>=0) return url+"&random="+rad;
	return url+"?random="+rad;
}

function convertObj2UrlParams(obj){
	var params="";
	for (var param in obj){
		if (params=="") params+="?";
		else params+="&";
		params+=param+"="+obj[param];
	}
	return params;
}

function convertObj2AjaxData(obj){
	var data="{";
	for (var param in obj){
		if (data!="{") data+=",";
		data+="'"+param+"':'"+obj[param]+"'";
	}
	data+="}";
	return data;
}

/***********************************
 Object Functions
 ***********************************/
/*
 * 检测对象是否是空对象(不包含任何可读属性)。
 * 方法既检测对象本身的属性，也检测从原型继承的属性(因此没有使hasOwnProperty)。
 */
function isEmpty(obj){
    for (var name in obj){
        return false;
    }
	if (!isNaN(parseInt(obj))) return false;
    return true;
}

function getInputValueArrayByName(iptName,prefx,suffx){
	var selectStr = '[name="'+iptName+'"]';
	if (prefx) selectStr = prefx+selectStr;
	if (suffx) selectStr = selectStr+suffx;
	var ipts = $(selectStr);
	var arr = new Array();
	for (var i=0;i<ipts.length;i++){
		arr.push($(ipts[i]).val());
	}
	return arr;
}

function clearObjectProp(obj){
    for (var prop in obj){
        if (typeof obj[prop] == 'object') clearObjectProp(obj[prop]);
		else if (typeof obj[prop] == 'string') obj[prop] = "";
		else if (typeof obj[prop] == 'number') obj[prop] = 0;
		else if (typeof obj[prop] == 'boolean') obj[prop] = false;
    }
}

function replaceObjectStrProp(obj, srcstr, newstr){
    for (var prop in obj){
        if (typeof obj[prop] == 'object') replaceObjectStrProp(obj[prop], srcstr, newstr);
		else if (typeof obj[prop] == 'string'){
			//obj[prop] = obj[prop].replaceAll(srcstr,newstr);
			if (obj[prop]==srcstr) obj[prop]=newstr;
		}
    }
}

function initObjectPropInput(parentStr,obj,prefx,nochild,clear){
	var prfx = prefx?prefx:"";
    for (var prop in obj){
		if (obj[prop]==null || typeof obj[prop] == 'string' || typeof obj[prop] == 'number' || typeof obj[prop] == 'boolean'){
			if (clear){
				if (typeof obj[prop] == 'string') obj[prop] = "";
				else if (typeof obj[prop] == 'number') obj[prop] = 0;
				else if (typeof obj[prop] == 'boolean') obj[prop] = false;
				else obj[prop] = "";
			}
			var propVal = obj[prop];
			if (typeof propVal == 'string' && propVal.startWith("\/Date(") && propVal.endWith(")\/")){
				var dd=dotNetDateConvert(propVal);
				if (!isNaN(dd)) propVal = dd;//dd.format("yyyy-MM-dd hh:mm");
			}
			var el = $("#"+prfx+parentStr+prop);
			if (el.length==1){
				var nodeType = el.prop('nodeName').toLowerCase();
				if (nodeType=="input"||nodeType=="select"||nodeType=="textarea"){
					propVal = (propVal instanceof Date)?propVal.format("yyyy-MM-dd"):propVal;
					//var eltype = el.prop('type');
					if (nodeType=="select" && !clear){
						var opts = el.prop('options'),hasOpt = false;
						if (opts){
							for (var i=0;i<opts.length;i++){
								if (opts[i].value==propVal){
									hasOpt = true;
									break;
								}
							}
							if (!hasOpt) opts.add(new Option(propVal,propVal));
						}
					}
					el.val(propVal);
				}else if (nodeType=="span"){
					propVal = (propVal instanceof Date)?propVal.format("yyyy-MM-dd hh:mm"):propVal;
					var dfval = el.attr("data-default");
					if (typeof(dfval)!="undefined" && propVal=="") el.html(dfval==""?"&nbsp;":dfval);
					else el.html(propVal==""?"&nbsp;":propVal);
					el.attr("data-val",propVal);
				}
			}
		}else if (typeof obj[prop] == 'object' && !nochild) {
			initObjectPropInput(parentStr+prop+'\\.',obj[prop],prefx,nochild,clear);
		}
    }
}

function clearObjectProp2Input(obj,prefx){
	initObjectPropInput("",obj,prefx,false,true);
}

function initObjectProp2Input(obj,prefx,nochild){
	initObjectPropInput("",obj,prefx,nochild?true:false,false);
}

function convertKeyValuePairToObjProp(dataObj,eid,val){
	var arr = eid.split('.');
	var obj = dataObj;
	for (var i=0;i<arr.length;i++){
		if (i<arr.length-1){
			if (typeof obj[arr[i]]!="object") obj[arr[i]] = {};
			obj = obj[arr[i]];
		}else{
			obj[arr[i]] = val;//hasQuoteChar(val)?val.replaceAll("\"","\\\"").replaceAll("\'","&apos;"):val;//escapeQuotation(val);
		}
	}
}

function readInputDataToObjectProp(inputObjList,prefx){
	if (inputObjList==null || inputObjList.length==0) return null;
	var dataArr = {};
	inputObjList.each(function(){
		var eid = $(this).attr("id"),val = "";
		var nodeType = $(this).prop('nodeName').toLowerCase();
		if (nodeType=="input"||nodeType=="select"||nodeType=="textarea"){
			var iptType = $(this).attr("type");
			if (iptType=="date") val=getDateInputValue($(this));
			else val = $(this).val();
		}else if (nodeType=="span"){
			val = $(this).attr("data-val");
		}
		if (eid){
			if (eid.startWith(prefx)) eid=eid.substring(prefx.length,eid.length);
			if (eid!="") convertKeyValuePairToObjProp(dataArr,eid,val!=null?val.trim():'');
		}
	});
	return dataArr;
}

function escapeObj(obj){
    for (var prop in obj){
        if (typeof obj[prop] == 'object') escapeObj(obj[prop]);
		else if (typeof obj[prop] == 'string'){
			if (obj[prop].indexOf('\\')>=0) obj[prop] = obj[prop].replaceAll('\\','\\\\');
			if (hasQuoteChar(obj[prop])) obj[prop] = obj[prop].replaceAll("\"","\\\"").replaceAll("\'","&apos;");
		}
    }
	return obj;
}

function toJSONStr(obj){
	return $.toJSON(escapeObj(obj));
}

/***********************************
 Cookie Functions
 ***********************************/
/**
 * 設置cookie名称、值以及过期天数
 *  - 我们首先将天数转换为有效的日期，然后，我们将 cookie 名称、值及其过期日期存入 document.cookie 对象。
 */
function setCookie(c_name,value,expiredays){
	var exdate=new Date();
	exdate.setDate(exdate.getDate()+expiredays);
	document.cookie=c_name+ "=" +escape(value)+((expiredays==null) ? "" : ";expires="+exdate.toGMTString());
}
function setPageCookie(c_name,value){
	document.cookie=c_name+ "=" +escape(value)+";";
}

/**
 * 检查是否已设置 cookie
 * - 检查 document.cookie 对象中是否存有 cookie。
 * - 假如 document.cookie 对象存有某些 cookie，那么会继续检查我们指定的 cookie 是否已储存。
 * - 如果找到了所要的 cookie，就返回值，否则返回空字符串。
 */
function getCookie(c_name){
	if (document.cookie.length>0){
		c_start=document.cookie.indexOf(c_name + "=");
		if (c_start!=-1){
			c_start=c_start + c_name.length+1;
			c_end=document.cookie.indexOf(";",c_start);
			if (c_end==-1) c_end=document.cookie.length;
			return unescape(document.cookie.substring(c_start,c_end))
		}
	}
	return "";
}

/***********************************
 Keyboard Functions
 ***********************************/
var lastKeyDown = -1;
function setupKeyboardHandler(keycode,func) {
	$(document).keydown(function(e){
		lastKeyDown = e.keyCode;
	});
	$(document).keyup(function(e){
		var key = e.keyCode;
		if (key == keycode && lastKeyDown == keycode){
			e.preventDefault();
			lastKeyDown = -1;
			func();
		}
	});
}

/*
function disableKeyPress() {
    if (window.removeEventListener) {
        window.removeEventListener('keypress', setupKeyboardHandler);
    }
    window.onkeypress = document.onkeypress = null;
}
*/
