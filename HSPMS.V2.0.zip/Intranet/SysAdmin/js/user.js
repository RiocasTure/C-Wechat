var userRoleCookieName = "userrole";
/*
var rolePageData = {
	"Admin":[
		["summary.html","系统概要"],
		["proposal.html","提案管理"],
		["reports.html","提案報表"],
		["employee.html","職員工主檔"],
		["wxuser.html","微信帳號主檔"]
	]
};
*/
var SysRole = {"Super":"Super","DBA":"DBA","Admin":"Admin","Operator":"Operator"};
var rolePageList = [
	{"url":"summary.html","name":"系统概要","roles":[SysRole.Super,SysRole.Admin,SysRole.Operator]},
	{"url":"proposal.html","name":"提案管理","roles":[SysRole.Super,SysRole.Admin,SysRole.Operator]},
	{"url":"reports.html","name":"提案報表","roles":[SysRole.Super,SysRole.Admin,SysRole.Operator]},
	{"url":"employee.html","name":"職員工主檔","roles":[SysRole.Super,SysRole.Admin]},
	{"url":"wxuser.html","name":"微信帳號主檔","roles":[SysRole.Super,SysRole.Admin]}
];
/** Messages **/
var MSG_CHECK_USER_RIGHT_ERR = "抱歉，您的系統權限未設置！如需繼續訪問，請聯繫系統管理員！";
var MSG_ROLE_PAGE_ERR = "抱歉，您无权限访问当前页面！";

function hasUserRole(role){
	var userRole=getCookie(userRoleCookieName);
	if (userRole==null || userRole=="" || userRole=="None") return false;
	var ura = unescape(userRole).split('|');
	return $.inArray(role, ura)>=0;
}

function userChecking(){
	showMasking("正在檢查用戶權限 ...");
	setTimeout("checkJQ()",800);
	var interId = setInterval(function(){
		if (window.jq||window.jQuery){
			clearInterval(interId);
			var userRole=getCookie(userRoleCookieName);
			if (userRole!=null && userRole!=""){
				if (userRole=="None"){
					showMasking(MSG_CHECK_USER_RIGHT_ERR);
					return;
				}
				var ura = unescape(userRole).split('|');
				var curl = document.location.pathname,durl="";
				if (typeof rolePageList != "undefined" && rolePageList.length>0){
					for (var i=0;i<rolePageList.length;i++){
						for (var x=0;x<ura.length;x++){
							if ($.inArray(ura[x], rolePageList[i]["roles"])>=0){
								if (curl.endWith(rolePageList[i]["url"])){
									$("#premask").remove();
									showLoadingMsg("正在初始化...");
									if (typeof initDateInput == "function") initDateInput();
									if (typeof initDatas == "function") setTimeout(function(){initDatas()},100);
									initHeaderBar(ura);
									return;
								}else if (durl=="") durl = rolePageList[i]["url"];
							}
						}
					}
				}
				if (durl!="") window.location=durl;
				else showMasking(MSG_ROLE_PAGE_ERR);
			}else{
				initUserChecking();
			}
		}
	},100);
}
function initHeaderBar(ura){
	var curl = document.location.pathname;
	if (typeof rolePageList != "undefined" && rolePageList.length>0){
		var pageList = new Array();
		for (var i=0;i<rolePageList.length;i++){
			for (var x=0;x<ura.length;x++){
				if ($.inArray(ura[x], rolePageList[i]["roles"])>=0){
					pageList.push({"url":rolePageList[i]["url"],"title":rolePageList[i]["name"]});
					break;
				}
			}
		}
		var headMenuBar = '<div class="HeadMenuBar"><ul>';
		for (var i=0;i<pageList.length;i++){
			headMenuBar += '<li'+(curl.endWith(pageList[i]["url"])?' class="MenuSelected"':'')+'><a href="'+pageList[i]["url"]+'">'+pageList[i]["title"]+'</a></li>';
		}
		headMenuBar += '</ul></div>';
		$("div.HeaderBar div.HeadMenuBar").remove();
		$("div.HeaderBar").append(headMenuBar);
	}
}
function initUserChecking(){
	$.ajax({
	    type: DataMethod,
	    url: DataFeederBase+GetPlatformUserRoleByNT,
	    data: "",
		dataType: "json",
		contentType: "application/json; charset=utf-8",
		success: function(data) {
			var roles = (data.d!=null && data.d!="")?data.d:"None";
			setPageCookie(userRoleCookieName,roles);
			userChecking();
		},
		error: function(jqXHR, textStatus, errorThrown) {
			if (textStatus!="abort"){
				alert("檢查用戶權限出錯:" + textStatus + " " + errorThrown);
			}
		}
	});
}

function ajaxCheckPassCode(pass,succFun){
	var dataObj = {"code":pass};
	showLoadingMsg();
	$.ajax({
		type: DataMethod,
		url: noCacheUrl(DataFeederBase+CheckSecurityCode),
		data: convertObj2AjaxData(dataObj),
		dataType: "json",
		contentType: "application/json; charset=utf-8",
		success: function(data){
			if (!data.d || !data.d.IsOK){
				if (data.d && data.d.SysMsg) alert(data.d.SysMsg);
				else alert("安全密碼錯誤！");
				$("#emp_opt_pass_code").focus();
				hideLoadingMsg();
				return;
			}
			if (typeof succFun == "function") succFun(pass);
			else hideLoadingMsg();
			setTimeout(function(){
				$("#LoginPromptWin").fadeOut("fast",function(){$("#emp_opt_pass_code").val("");});
			},100);
		},
		error: function (jqXHR, textStatus, errorThrown) {
			alert("安全密碼檢查失敗("+DataTransError+")!");
			hideLoadingMsg();
		},
		timeout: 8000
	});
}

function popSecureWin(succHandleFun,cancelHandleFun){
	$("#LoginPromptWin").remove();
	var popHtml = 
		'<div class="PopupWindow" id="LoginPromptWin">'+
		'<div class="PopupMask"></div>'+
		'<div class="Content">'+
		'<div class="PromptHeader">輸入安全密碼</div>'+
		'<p class="PromptBody"><input type="password" name="emp_opt_pass_code" id="emp_opt_pass_code"/></p>'+
		'<div class="PromptBtmBar"><span class="CntSpanRight"><input type="button" name="ePassSmtBtn" id="ePassSmtBtn" value=" 確認 "/>'+
		'<input type="button" name="eCancelBtn" id="eCancelBtn" value=" 取消 "/></span></div>'+
		'</div>'+
		'</div>';
	$(document.body).append(popHtml);
	$("#LoginPromptWin").fadeIn("fast",function(){
		$("#emp_opt_pass_code").focus();
		$("#ePassSmtBtn").unbind("click");
		$("#ePassSmtBtn").bind("click",function(){
			var passCode = $("#emp_opt_pass_code").val().trim();
			if (passCode==""){
				alert("請輸入安全密碼！");
				$("#emp_opt_pass_code").focus();
			}else ajaxCheckPassCode(passCode,succHandleFun);
		});
		$('#emp_opt_pass_code').unbind("keypress");
		$('#emp_opt_pass_code').unbind("keyup");
		$('#emp_opt_pass_code').bind('keyup',function(event){
            if(event.keyCode == "27") $("#eCancelBtn").trigger("click");
        });
		$('#emp_opt_pass_code').bind('keypress',function(event){
            if(event.keyCode == "13") $("#ePassSmtBtn").trigger("click");
        });
		$("#eCancelBtn").unbind("click");
		$("#eCancelBtn").bind("click",function(){
			$("#LoginPromptWin").fadeOut("fast",function(){
				$("#emp_opt_pass_code").val("");
				if (typeof cancelHandleFun == "function") cancelHandleFun();
			});
		});
	});

}
