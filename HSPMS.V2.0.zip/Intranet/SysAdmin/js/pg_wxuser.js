function ajaxLoadDataList(pageIdx){
	var pageIndex = pageIdx?parseInt(pageIdx):1;
	if (isNaN(pageIndex)) pageIndex = 1;
	queryFilter = readInputDataToObjectProp($("ul#FilterList input,ul#FilterList select"),"q_");
	//replaceObjectStrProp(queryFilter,DefaultSelect.EmptyValue,"");
	queryFilter["PageSize"] = DefaultPageSize;
	queryFilter["PageIndex"] = pageIndex;
	var dataObj = {"dataArr":$.toJSON(queryFilter)};
	showLoadingMsg();
	$.ajax({
		type: DataMethod,
		url: noCacheUrl(DataFeederBase+QueryWXUsers),
		dataType: "json",
		contentType: "application/json; charset=utf-8",
		data: convertObj2AjaxData(dataObj),
		success: function(data){
			if (data && data.d && data.d.IsOK){
				if (data.d.ResultObject){
					renderListData(data.d.ResultObject);
					initEventOfTable(data.d.ResultObject);
				}else{
					alert("抱歉！因系统数据异常，本次查询失败！");
				}
				processQueueToken = 0;
			}else{
				if (data && data.d && data.d.SysMsg) alert(data.d.SysMsg);
				else alert("抱歉！"+DataProcessError+"，请稍候再试！");
			}
			hideLoadingMsg();
		},
		error: function (jqXHR, textStatus, errorThrown) {
			alert("抱歉！因"+DataTransError+"的原因，系统未能处理您的查询请求！");
			hideLoadingMsg();
		},
		timeout: 8000
	});
}
function ajaxDelWXUsers(wxuArr,passCode){
	if (!wxuArr || !wxuArr.length || wxuArr.length<=0) return;
	var dataObj = {"dataArr":$.toJSON(wxuArr),"password":passCode};
	showLoadingMsg();
	$.ajax({
		type: DataMethod,
		url: noCacheUrl(DataFeederBase+DelWXUsers),
		dataType: "json",
		contentType: "application/json; charset=utf-8",
		data: convertObj2AjaxData(dataObj),
		success: function(data){
			if (data && data.d && data.d.IsOK){
				alert(data.d.SysMsg);
				ajaxLoadDataList($("#PageIndex").val());
				processQueueToken = 0;
			}else{
				if (data && data.d && data.d.SysMsg) alert(data.d.SysMsg);
				else alert("抱歉！"+DataProcessError+"，请稍候再试！");
			}
			hideLoadingMsg();
		},
		error: function (jqXHR, textStatus, errorThrown) {
			alert("抱歉！因"+DataTransError+"的原因，系统未能处理您的數據请求！");
			hideLoadingMsg();
		},
		timeout: 8000
	});
}

function renderListData(pageData){
	if (!pageData) return;
	$("#elist tbody tr").remove();
	var tbodyHtml = '';
	var baseIdx = (pageData.PageIndex-1)*pageData.PageSize+1;
	var canDel = hasUserRole("DBA")||hasUserRole("Super");
	for (var i=0;i<pageData.PageData.length;i++){
		var d = pageData.PageData[i];
		tbodyHtml += '<tr'+(i%2==0?'':' class="even"')+' data-idx="'+i+'"><th>'+(canDel?('<input type="checkbox" name="wxopenId" value="'+d.OpenID+'"/> '):'')+(baseIdx+i)+'</th><td>'+d.JobNumber+'</td><td>'+d.FullName+'</td><td>'+d.NickName+'</td><td>'+d.Mobile+'</td><td>'+d.Region +'</td><td>'+d.LastUpdate+'</td><td>'+d.ProposalCount+'</td></tr>';
	}
	for (var i=pageData.PageData.length;i<DefaultPageSize;i++){
		tbodyHtml += '<tr class="blanktr'+(i%2==0?'':'_even')+'"><th>&nbsp;</th><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>';
	}
	$("#elist").children("tbody").html(tbodyHtml);
	initObjectProp2Input(pageData,"",true);
	$("#PageNaviBtns").css("display",pageData.PageCount>1?"table-cell":"none");
	$("#PageNaviSum").css("display",pageData.PageCount>1?"table-cell":"none");
	$("#PageNaviRowCount").css("display",pageData.RowsCount>1?"inline":"none");
	$("#spanFirst").attr("pageVal",1);
	$("#spanPre").attr("pageVal",pageData.PageIndex-1);
	$("#spanNext").attr("pageVal",pageData.PageIndex+1);
	$("#spanLast").attr("pageVal",pageData.PageCount);
	$("#spanFirst").removeClass("pageClick");
	$("#spanPre").removeClass("pageClick");
	if (pageData.PageCount>1 && pageData.PageIndex>1){
		$("#spanFirst").addClass("pageClick");
		$("#spanPre").addClass("pageClick");
	}
	$("#spanNext").removeClass("pageClick");
	$("#spanLast").removeClass("pageClick");
	if (pageData.PageCount>1 && pageData.PageIndex<pageData.PageCount){
		$("#spanNext").addClass("pageClick");
		$("#spanLast").addClass("pageClick");
	}
}

function initEventOfTable(pageData){
	$("td#PageNaviBtns span").unbind("click");
	$("#PageIndex").unbind("blur");
	if (pageData){
		$("td#PageNaviBtns span").bind("click",function(){
			var pI = parseInt($(this).attr("pageVal"));
			if (isNaN(pI)||pI>pageData.PageCount||pI<1)
				return;
			else{
				if (pI!=pageData.PageIndex) ajaxLoadDataList(pI);
			}
		});
		$("#PageIndex").bind("blur",function(){
			var pI = parseInt($(this).val());
			if (isNaN(pI)||pI>pageData.PageCount||pI<1)
				$(this).val(pageData.PageIndex);
			else{
				if (pI!=pageData.PageIndex) ajaxLoadDataList(pI);
			}
		});
	}
}
function initEventOfButtons(){
	$("#qSubmitBtn").unbind("click");
	$("#qSubmitBtn").bind("click",function(){
		ajaxLoadDataList(1);
	});
	
	$("#wDelBtn").unbind("click");
	if (hasUserRole("DBA")||hasUserRole("Super")){
		$("#wDelBtn").css("display","inline-block");
		$("#wDelBtn").bind("click",function(){
			var selectedIds = getInputValueArrayByName("wxopenId","#elist ",":checked");
			if (selectedIds.length>0){
				if (confirm("您確認要刪除所選的微信帳號記錄嗎？")){
					popSecureWin(function(pass){ajaxDelWXUsers(selectedIds,pass)});
				}
			}else{
				alert("請選擇相應記錄！");
			}
		});
	}else $("#wDelBtn").css("display","none");
}

function initDatas(){
	pushProcQueue("正在加載：註冊微信帳號主檔數據...",ajaxLoadDataList);
	pushProcQueue(null,function(){
		hideLoadingMsg();
		initEventOfButtons();
	});
}
