function TreeSelect(RootTree,TreeSelectArr,RangeSelect){
	var node = RootTree;
	for (var s=0;s<TreeSelectArr.length-1;s++){
		var opts = $("#"+TreeSelectArr[s]).prop('options');
		opts.length=0;
		$("#"+TreeSelectArr[s]).attr("dataTreeLevel",s);
		if (s==0){
			for (var i=0;i<node.Childrens.length;i++){
				var newopt = new Option(node.Childrens[i].NodeName, node.Childrens[i].NodeName);
				opts[opts.length] = newopt;
			}
		}
		$("#"+TreeSelectArr[s]).change(function(){
			var lev = parseInt($(this).attr("dataTreeLevel"));
			if (lev>=TreeSelectArr.length-1) return;
			var treeNode = RootTree;
			for (var i=0;i<=lev;i++){
				if (isEmpty(treeNode) || isEmpty(treeNode.Childrens)) break;
				var levVal = $("#"+TreeSelectArr[i]).get(0).value;
				if (levVal!=""&&levVal!=DefaultSelect.EmptyValue){
					var match = false;
					for (var n=0;n<treeNode.Childrens.length;n++){
						if (treeNode.Childrens[n].NodeName == levVal){
							treeNode = treeNode.Childrens[n];
							match = true;
							break;
						}
					}
					if (!match){
						treeNode = null;
						break;
					}
				}else lev = lev-1;
			}
			if (!isEmpty(treeNode) && !isEmpty(treeNode.Childrens)){
				var _opts = $("#"+TreeSelectArr[lev+1]).prop('options');
				_opts.length=0;
				for (var i=0;i<treeNode.Childrens.length;i++){
					var newopt = new Option(treeNode.Childrens[i].NodeName, treeNode.Childrens[i].NodeName);
					_opts[_opts.length] = newopt;
				}
				setDefaultOption4Select($("#"+TreeSelectArr[lev+1]));
				lev ++;
			}
			for (var i=lev+1;i<TreeSelectArr.length;i++){
				var _opts = $("#"+TreeSelectArr[i]).prop('options');
				_opts.length=0;
				if (RangeSelect && RangeSelect==TreeSelectArr[i]){
					var rOpts = new Array();
					TreeIteratorArrayPush(treeNode,rOpts,lev-1,i);
					rOpts = rOpts.sort();//quickSort(rOpts);//
					for (var j=0;j<rOpts.length;j++)
						_opts[_opts.length] = new Option(rOpts[j], rOpts[j]);;
				}
				setDefaultOption4Select($("#"+TreeSelectArr[i]));
			}
		});
		setDefaultOption4Select($("#"+TreeSelectArr[s]));
		if (TreeSelectArr!=null&&TreeSelectArr.length>0)
			$("#"+TreeSelectArr[0]).trigger("change");
	}
}
function TreeIteratorArrayPush(node,arr,lev,pushLev){
	if (lev>pushLev) return;
	if (lev==pushLev){
		if ($.inArray(node.NodeName, arr)<0) arr.push(node.NodeName);
	}
	if (node!=null && node.Childrens!=null&&node.Childrens.length>0){
		for (var i=0;i<node.Childrens.length;i++){
			TreeIteratorArrayPush(node.Childrens[i],arr,lev+1,pushLev);
		}
	}
}
/*
function quickSort(arr){
	if(arr.length <= 1) return arr;//判断是否有效数组
	var cut = Math.floor(arr.length/2);//取中间下标
	var left = [],right = [];
	var num = arr.splice(cut,1)[0];//取基准值
	for(var i = 0;i < arr.length;i ++){
		if(arr[i] < num){
			left.push(arr[i]);//小的放左边
		}else {
			right.push(arr[i]);//大的放右边
		}
	}
	return quickSort(left).concat(num,quickSort(right));//递归
}*/