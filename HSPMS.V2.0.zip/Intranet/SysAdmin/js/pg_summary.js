function ajaxLoadDataList(){
	showLoadingMsg();
	$.ajax({
		type: DataMethod,
		url: noCacheUrl(DataFeederBase+GetSummary),
		dataType: "json",
		contentType: "application/json; charset=utf-8",
		//data: "",
		success: function(data){
			if (data && data.d && data.d.IsOK){
				if (data.d.ResultObject){
					renderListData(data.d.ResultObject);
				}else{
					alert("抱歉！因系统数据异常，本次請求失败！");
				}
				processQueueToken = 0;
			}else{
				if (data && data.d && data.d.SysMsg) alert(data.d.SysMsg);
				else alert("抱歉！"+DataProcessError+"，请稍候再试！");
			}
			hideLoadingMsg();
		},
		error: function (jqXHR, textStatus, errorThrown) {
			alert("抱歉！因"+DataTransError+"的原因，系统未能处理您的數據请求！");
			hideLoadingMsg();
		},
		timeout: 8000
	});
}

function renderListData(summary){
	$("#AdminSummary").css("display","none");
	$("#OperatorSummary").css("display","none");
	if (!summary) return;
	if (summary["SumType"]==SysRole.Admin){
		$("#AdminSummary").css("display","block");
	}else if (summary["SumType"]==SysRole.Operator){
		var html = '';
		for (var i=0;i<summary["organ_count"];i++){
			html += 
				'<div class="CntBlock"><div class="CntBlockHead"><p class="i_sum_co">[<span id="p_sum_company_'+i+'" class="i_sum gray"></span>]<span id="p_sum_organ_'+i+'" class="i_sum bold"></span></p> - 提案概要</div><ul>'+
				'<li>今日新增提案<span id="p_count_today_'+i+'" class="i_sum">-</span>條</li>'+
				'<li>總提案記錄數<span id="p_count_total_'+i+'" class="i_sum">-</span>條</li>'+
				'<li>目前共有<span id="p_count_received_'+i+'" class="i_sum">-</span>條審核中 /<span id="p_count_audited_'+i+'" class="i_sum">-</span>條已審核 /<span id="p_count_accept_'+i+'" class="i_sum">-</span>條被採納 /<span id="p_count_reject_'+i+'" class="i_sum">-</span>條不被採納</li>'+
				'</ul></div>';
		}
		$("#OperatorSummary").html(html);
		$("#OperatorSummary").css("display","block");
	}
	initObjectProp2Input(summary,"");
}

function initDatas(){
	pushProcQueue("正在加載：系統概要匯總統計數據...",ajaxLoadDataList);
	pushProcQueue(null,function(){
		hideLoadingMsg();
	});
}
