﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using LEO.Project.WXProposal.Data.Imports;
using LEO.Project.WXProposal.Control;
using System.IO;
using LEO.Project.Tools;

namespace Internal
{
    public partial class _Default : System.Web.UI.Page
    {
        protected virtual bool IsFileLocked(FileInfo file)
        {
            FileStream stream = null;

            try
            {
                stream = file.Open(FileMode.Open, FileAccess.Read, FileShare.None);
            }
            catch (IOException)
            {
                //the file is unavailable because it is:
                //still being written to
                //or being processed by another thread
                //or does not exist (has already been processed)
                return true;
            }
            finally
            {
                if (stream != null)
                    stream.Close();
            }

            //file is not locked
            return false;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            //string action = Request.Form["action"]; //post
            //string action = Request.QueryString["action"]; //get
            /*
            string action = Request.Params["action"];
            if (!string.IsNullOrEmpty(action))
            {
                if (action == "excelimport")
                {
                    //DataImporter.ImportEmployeeData(null);
                }
                else if (action == "ldapimport")
                {
                    //DataImporter.ImportADUserData();
                }
                else if (action == "ntlogin")
                {
                    string cUserLoginNT = HttpContext.Current.User.Identity.Name;
                    string cGroup = "", cUserName = "";
                    int idx = cUserLoginNT.LastIndexOf('\\');
                    if (idx > 0)
                    {
                        cGroup = cUserLoginNT.Substring(0, idx);
                        cUserName = cUserLoginNT.Substring(idx + 1);
                    }
                    //string UserLoginNT = cUserLoginNT.Substring(cUserLoginNT.LastIndexOf('\\') + 1);
                    //Response.Write("當前用戶：" + cUserName + "；" + "所在組：" + cGroup);
                }
            }
            //else
            //{
            */
            /*
            Response.Write("<ul><li>Request.UserHostAddress=");
            Response.Write(Request.UserHostAddress);
            Response.Write("</li><li>HttpUtil.GetRequestIPAddress=");
            Response.Write(HttpUtil.GetRequestIPAddress(Request));
            Response.Write("</li><li>HttpUtil.GetRemoteIPAddress=");
            Response.Write(HttpUtil.GetRemoteIPAddress(Request));
            Response.Write("</li><li>HttpUtil.GetClientIPAddress=");
            Response.Write(HttpUtil.GetClientIPAddress(Request));
            Response.Write("</li></ul>");
            */
            string action = Request.Params["action"];
            if (!string.IsNullOrEmpty(action))
            {
                if (action == "user")
                {
                    if (HttpContext.Current.User != null && HttpContext.Current.User.Identity != null)
                        Response.Write("當前NT用户：" + HttpContext.Current.User.Identity.Name);
                    else
                        Response.Write("NT域用户未登录！");
                }
                else if (action == "download")
                {
                    string path = Request["path"];
                    string filePath = (path.IndexOf(":") > 0) ? path : HttpContext.Current.Server.MapPath(path);
                    FileInfo fi = new FileInfo(filePath);
                    if (IsFileLocked(fi))
                    {
                        DirectoryInfo di = new DirectoryInfo(Path.Combine(fi.Directory.FullName, "tmp"));
                        if (di.Exists)
                        {
                            FileInfo cp = new FileInfo(Path.Combine(di.FullName, fi.Name));
                            File.Copy(fi.FullName, cp.FullName, true);
                            if (cp.Exists)
                            {
                                try
                                {
                                    Response.AddHeader("Content-Disposition", "attachment; filename=" + Server.UrlPathEncode(cp.Name));
                                    Response.AddHeader("Content-Length", cp.Length.ToString());
                                    Response.ContentType = "application/octet-stream";
                                    Response.TransmitFile(cp.FullName);
                                    Response.Flush();
                                }
                                finally
                                {
                                    //cp.Delete();
                                    File.Delete(cp.FullName);
                                }
                            }
                        }
                    }
                    else
                    {
                        Response.AddHeader("Content-Disposition", "attachment; filename=" + Server.UrlPathEncode(fi.Name));
                        Response.AddHeader("Content-Length", fi.Length.ToString());
                        Response.ContentType = "application/octet-stream";
                        Response.TransmitFile(fi.FullName);
                    }
                }
                else Response.Write("No Action Parameter!");
            }
            else Response.Redirect("SysAdmin/index.html");
            Response.End();
        }
    }
}
