﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Timers;

using LEO.Project.WXProposal.Control;
using LEO.Project.WXProposal.Data.Imports;
using LEO.Project.Tools;
using LEO.Project.WXProposal.Data.DAO;
using System.IO;
using System.Web;

namespace LEO.Message.Control.Timer
{
    public class StaffImportTimer : System.Timers.Timer
    {
        private static StaffImportTimer HSPPWStaffSynTimer = null;
        private static int TimerHour = -1, TimerMinute = -1;

        public StaffImportTimer(double interval)
            : base(interval)
        {
        }

        public static void StartTimers()
        {
            if (HSPPWStaffSynTimer == null)
            {
                //解析配置時間
                int hour = -1, minute = -1;
                string[] ts = SysConfig.HSPPW_Staff_Syn_ScheduleTime.Split(':');
                if (ts != null && ts.Length >= 2)
                {
                    if (!int.TryParse(ts[0], out hour) || !int.TryParse(ts[1], out minute) ||
                        (hour < 0 || hour >= 24 || minute < 0 || minute >= 60))
                    {
                        WriteLog.Error("Invalid SysConfig.HSPPW_Staff_Syn_ScheduleTime Value:" + SysConfig.HSPPW_Staff_Syn_ScheduleTime, null);
                    }
                }
                else
                {
                    WriteLog.Error("Invalid SysConfig.HSPPW_Staff_Syn_ScheduleTime Setting:" + SysConfig.HSPPW_Staff_Syn_ScheduleTime, null);
                }
                TimerHour = (hour < 0 || hour >= 24) ? 22 : hour;
                TimerMinute = (minute < 0 || minute >= 60) ? 0 : minute;

                long interval = 20000;//20秒後啟動
                int staffCount = StaffInfoDAO.CountStaffInfoRecords();
                if (staffCount > 0)
                {
                    DateTime now = DateTime.Now;
                    DateTime nexttime = new DateTime(now.Year, now.Month, now.Day, TimerHour, TimerMinute, 0, 0);
                    if (DateTime.Compare(nexttime, now) <= 0) nexttime = nexttime.AddDays(1);
                    interval = (long)((nexttime - now).TotalMilliseconds);
                }
                HSPPWStaffSynTimer = new StaffImportTimer(interval);
                HSPPWStaffSynTimer.AutoReset = false; // fire only once
                //QueryBalanceTimer.Elapsed += (sender, args) => SynHSPPWStaff(sender, args);
                HSPPWStaffSynTimer.Elapsed += new ElapsedEventHandler(SynHSPPWStaff);
                HSPPWStaffSynTimer.Enabled = true;
                HSPPWStaffSynTimer.Start();
                WriteLog.Info("StaffImportTimer schedule:" + SysConfig.HSPPW_Staff_Syn_ScheduleTime);
            }
        }

        public static void StopTimers()
        {
            if (HSPPWStaffSynTimer != null) HSPPWStaffSynTimer.Stop();
        }

        public static void ClearTmpFolder()
        {
            try
            {
                System.IO.DirectoryInfo di = new DirectoryInfo(HttpContext.Current.Server.MapPath("~/SysAdmin/data/upload/tmp/"));
                foreach (FileInfo file in di.GetFiles())
                {
                    file.Delete();
                }
                foreach (DirectoryInfo dir in di.GetDirectories())
                {
                    dir.Delete(true);
                }
            }
            catch (Exception ex)
            {
                WriteLog.Error("ClearTmpFolder Exception", ex);
            }
        }

        private static void SynHSPPWStaff(object sender, System.Timers.ElapsedEventArgs args)
        {
            if (HSPPWStaffSynTimer != null)
            {
                if (!HSPPWStaffSynTimer.AutoReset)
                {
                    /*
                    DateTime now = DateTime.Now;
                    DateTime nexttime = DateTime.Now.AddDays(1);
                    long interval = (long)((nexttime - now).TotalMilliseconds);
                    */
                    DateTime now = DateTime.Now;
                    DateTime nexttime = new DateTime(now.Year, now.Month, now.Day, TimerHour, TimerMinute, 0, 0);
                    if (DateTime.Compare(nexttime, now) <= 0) nexttime = nexttime.AddDays(1);
                    long interval = (long)((nexttime - now).TotalMilliseconds);

                    HSPPWStaffSynTimer.AutoReset = true;
                    HSPPWStaffSynTimer.Enabled = true;
                    HSPPWStaffSynTimer.Interval = interval;
                    HSPPWStaffSynTimer.Start();
                }
                if (HSPPWStaffSynTimer.Enabled)
                {
                    //Syn
                    int synCount = DataImporter.ImportStaffInfoData();
                    WriteLog.Info((synCount > 0? (""+synCount):"No") + " StaffInfo syn from HSPPW!");
                    //Clear Tmp Folder
                    ClearTmpFolder();
                }
            }
        }

    }

}
