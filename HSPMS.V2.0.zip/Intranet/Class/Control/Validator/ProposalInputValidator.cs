﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using LEO.Project.WXProposal.Validator;
using LEO.Project.WXProposal.Model.Session;
using LEO.Project.WXProposal.Data.Entity;
using LEO.Project.WXProposal.Data.DAO;
using LEO.Project.Tools;

namespace LEO.Project.WXProposal.Control.Validator
{
    /*
    public class ProposalInputValidator
    {
        /// <summary>
        /// 後台管理端的提案錄入數據檢查
        /// </summary>
        /// <param name="pi">輸入的提案數據對象</param>
        /// <param name="empArr">提案人員工號數組</param>
        /// <param name="fileArr">上傳的附件ID數組</param>
        /// <returns>檢查結果對象</returns>
        public static ValidateResult ValidateInputData(UserRole ur, ProposalInfo pi, string empArr, string fileArr)
        {
            if (ur==null || !UserRole.CheckRoleIntersection(ur.RoleName, AdminControl.ValidUserRoles))
                return ValidateResult.Result(false, -1, "無操作權限！");
            if (pi == null) return ValidateResult.Result(false, 1, "輸入的提案信息有誤！");
            string[] emps = JsonUtil<string[]>.JsonDeserializeObject(empArr);
            if (emps == null || emps.Length == 0) return ValidateResult.Result(false, 1, "您未設定提案的職員工工號！");
            if (!ProposalCategory.CategoryExist(pi.Category))
                return ValidateResult.Result(false, 3, "未指定正确的改善类别！");
            if (!pi.FormDate.HasValue)
                return ValidateResult.Result(false, 3, "未指定提案日期！");
            if (string.IsNullOrEmpty(pi.Title) || pi.Title.Length < 1 || pi.Title.Length > 20)
                return ValidateResult.Result(false, 3, "提案名称输入內容長度不符合要求！");
            if (string.IsNullOrEmpty(pi.Description) || pi.Description.Length < 1 || pi.Description.Length > 200)
                return ValidateResult.Result(false, 3, "问题描述输入內容長度不符合要求！");
            if (string.IsNullOrEmpty(pi.Advice) || pi.Advice.Length < 1 || pi.Advice.Length > 200)
                return ValidateResult.Result(false, 3, "改善建议输入內容長度不符合要求！");
            if (!string.IsNullOrEmpty(pi.AuditInfo.FollowDesc) && pi.AuditInfo.FollowDesc.Length > 200)
                return ValidateResult.Result(false, 3, "補充描述不能超過200字！");
            if ((!string.IsNullOrEmpty(pi.AuditInfo.MajorAudit) && pi.AuditInfo.MajorAudit == ProposalStatus.Reject && (string.IsNullOrEmpty(pi.AuditInfo.MajorAuditDesc) || pi.AuditInfo.MajorAuditDesc.Trim().Length < 4)) ||
                (!string.IsNullOrEmpty(pi.AuditInfo.MajorAuditDesc) && pi.AuditInfo.MajorAuditDesc.Trim().Length > 60))
                return ValidateResult.Result(false, 3, "審核建議输入內容長度不符合要求！");
            if ((!string.IsNullOrEmpty(pi.AuditInfo.OrganAudit) && pi.AuditInfo.OrganAudit == ProposalStatus.Reject && (string.IsNullOrEmpty(pi.AuditInfo.OrganAuditDesc) || pi.AuditInfo.OrganAuditDesc.Trim().Length < 4)) ||
                (!string.IsNullOrEmpty(pi.AuditInfo.OrganAuditDesc) && pi.AuditInfo.OrganAuditDesc.Trim().Length > 60))
                return ValidateResult.Result(false, 3, "審批建議输入內容長度不符合要求！");
            if (!string.IsNullOrEmpty(pi.AuditInfo.FollowPlan) && pi.AuditInfo.FollowPlan.Length > 200)
                return ValidateResult.Result(false, 3, "後續啟動項目概述不能超過200字！");
            if (!string.IsNullOrEmpty(pi.YieldingInfo.SONum) && string.IsNullOrEmpty(pi.YieldingInfo.ItemName))
                return ValidateResult.Result(false, 3, "未指定產品名稱！");
            if (!string.IsNullOrEmpty(pi.YieldingInfo.OtherResult) && pi.YieldingInfo.OtherResult.Length > 20)
                return ValidateResult.Result(false, 3, "其他改善成效不能超過20字！");
            if (pi.Submitters == null) pi.Submitters = new List<EmployeeView>();
            pi.Submitters.Clear();
            bool isOrganOperator = !UserRole.CheckRoleIntersection(ur.RoleName, AdminControl.ValidAdminRoles);
            foreach (string jobnum in emps)
            {
                EmployeeView emp = EmployeeDAO.GetEmployeeWXUserByJobNumber(jobnum);
                if (emp != null)
                {
                    //检查是否在管辖的事业部下属职员工
                    bool empUnderManage = !isOrganOperator;
                    if (ur.OrganOperators != null && ur.OrganOperators.Count > 0)
                    {
                        for (int i = 0; !empUnderManage && i < ur.OrganOperators.Count; i++)
                            empUnderManage = (emp.Company == ur.OrganOperators[i].Company && emp.Organ == ur.OrganOperators[i].Organ);
                    }
                    if (!empUnderManage) return ValidateResult.Result(false, -1, "提案職員工必須屬於所管轄的事業部！");

                }
                if (emp != null && pi.Submitters.FirstOrDefault(s => s.JobNumber == emp.JobNumber) == null) pi.Submitters.Add(emp);
            }
            if (pi.Submitters.Count == 0) return ValidateResult.Result(false, 4, "輸入的提案者工号有誤！");
            if (pi.Submitters.Count > 2) return ValidateResult.Result(false, 4, "提案者數量不能超過2個！");
            pi.AuthorJobNumber = pi.Submitters[0].JobNumber;//默認提案者為第一個
            if (!string.IsNullOrEmpty(pi.WXOpenID))
            {
                WXUserInfo wui = WXUserInfoDAO.GetWXUserInfoByOpenId(pi.WXOpenID);
                if (wui == null) return ValidateResult.Result(false, 5, "指定的微信帳號不存在！");
                if (emps.Contains(wui.JobNumber))
                {
                    pi.AuthorJobNumber = wui.JobNumber;//如果指定了微信帳號，則提案者為微信帳號對應的工號
                    pi.WXUser = wui;
                }
                else return ValidateResult.Result(false, 5, "指定的微信帳號有誤！");
            }
            string[] files = JsonUtil<string[]>.JsonDeserializeObject(fileArr);
            if (files != null)
            {
                if (pi.Attachments == null) pi.Attachments = new List<AttachmentInfo>();
                foreach (string filePath in files)
                {
                    AttachmentInfo att = ProposalFileDAO.GetByFilePath(filePath);
                    if (att != null && (string.IsNullOrEmpty(att.RelatedKey) || att.RelatedKey == pi.Number)) pi.Attachments.Add(att);
                }
            }
            return ValidateResult.Result(true, 0, null);
        }
    }
    */
}
